#!/usr/bin/env python
# -*- coding:utf-8 -*-


# ////////////////////////////////////////////////////////////////
#                                                                 
#   LINGUAE                                                       
#   Gestionnaire de dictionnaire multiformat multiplateforme      
#                                                                 
#   Module en ligne de commande                                   
#                                                                 
#   sous licence CeCILL : http://www.cecill.info/                 
#                                                                 
#   Auteur   : Billig - 2008-2009                                 
#   Contact  : linguae@stalikez.info                              
#   Site Web : http://linguae.stalikez.info                       
#                                                                 
# ////////////////////////////////////////////////////////////////


u"""
| Module cmdling.py                                                             
|                                                                               
| Corps du programme en mode ligne de commande.                                 
|                                                                               
| Contenu :                                                                     
|   Classe ProgressBarCons : barre de progression.                              
|   Classe LinguaeCons : corps de programme                                     
"""

import sys
import os.path
import lib.mydic                # Classe d'objet Dictionnaire
import lib.mylang               # Gestionnaire du multilinguisme d'interface



class ProgressBarCons():
    
    u"""
    | Emulation de ProgressBar en mode console exposant la même interface       
    | de programmation que la version graphique.                                
    |                                                                           
    | Visuellement, affiche  une suite de points.                               
    """
    
    def __init__(self, min=0, max=100):
        
        self.min = min
        self.max = max
        self.range = max - min
        self.pourcent = -1
      
        if self.range <= 0: self.range = 1
    
    
    
    def setMax(self, newMax):
        u"""
        Modifier la valeur maxi absolue de la barre
        """
        
        self.max = newMax
        self.range = newMax - self.min
        
        if self.range <= 0: self.range = 1


    def setMin(self, newMin):
        u"""
        Modifier la valeur mini absolue de la barre
        """
        
        self.min = newMin
        self.range = self.max - newMin
        
        if self.range <= 0: self.range = 1
    
    
    def setValue(self, newval):
        u"""
        Modifier la valeur du curseur de la barre
        """
        
        if newval < self.min:
            newval = self.min 
        elif newval > self.max:
            newval = self.max
        
        
        # convertir la valeur en pourcentage
        # max - min = 100% donc ( newval / (max-min) ) x 100 = le pourcentage de la largeur maxi
        # ici affichage en 20èmes
        
        pourcent = (newval*20) // self.range
        
        # mise à jour de l'affichage uniquement si le pourcentage arrondi a changé
        if pourcent == self.pourcent:
            return
        
        self.pourcent = pourcent # mémoriser
        
        # Ecrire
        print ".",
        
        return



class LinguaeConsole():
    
    # Chaînes d'aide à afficher dans la console
    
    strminihlp = "\nPour afficher l'aide, tapez : linguae ?"
    
    strhlp = """
    Utilisation en ligne de commande :
    
        - Conversion de format d'un dictionnaire compatible
        
        - Tri alphabétique personnalisé d'un dictionnaire compatible
    
    
    ----------------------------------------------------------------------------
    
    SYNTAXE GENERALE :
    
        linguae -i <inputfile> -o <outputfile> -do <action> -with <param>
    
    
    Un espace doit séparer les commutateurs et les arguments. Attention ! si un
    argument <...> contient des espaces, il doit être entouré de guillemets
    simples ou doubles.
    
    En l'absence du commutateur '-i', Linguae lancé à partir de la ligne de
    commande démarre en mode graphique en chargeant le fichier éventuellement
    passé en premier argument.
    
    
    ----------------------------------------------------------------------------
    
    ARGUMENTS :
    
    <inputfile> : 
        Chemin du fichier dictionnaire à traiter. Obligatoire. Ce dictionnaire
        doit être de l'un des formats supportés par Linguae (*.ling, *.xdxf,
        *.dict, *.csv, *.tab, *.txt, *.ini) 
    
    <outputfile> :
        Chemin du fichier issu du traitement, argument non pris en compte
        en cas de tri. Si cet argument est absent, le fichier de sortie reprend
        le même chemin que le fichier source à l'extension près (l'extension en 
        fonction du format sera déterminée par le choix de l'argument <action>.
    
    <action> : 
        Traitement à appliquer à <inputfile>. Obligatoire.
    
            Valeurs :
                    'toLING'    : conversion au format Ling
                    'toPRELING' : conversion au format Preling
                    'toXDXF'    : conversion au format XDXF
                    'toWB'      : conversion au format WB
                    'toDICTm'   : conversion au format (Star)DICT/m
                    'toDICTx'   : conversion au format (Star)DICT/x
                    
                    'sort'      : tri alphabétique du dictionnaire
    
    <param> : 
        Paramètres facultatifs pour le traitement à appliquer.
            
            Si <action> = sort :
                -with <param> indique le chemin d'un fichier texte contenant
                les paramètres de tri. La syntaxe des paramètres de tri dans ce
                fichier est identique à celle de la version graphique (cf).
            
            Si <action> = to<xxx> :
                -with <param> indique les encodages du fichier source à
                convertir et/ou ceux du fichier cible désiré.
                Syntaxe :
                    codeLgSrc1 + codeLgSrc2 x codeLgCbl1 + codeLgCbl2
                Nb : il n'est pas obligatoire de fournir les 4 valeurs, par ex.
                'xUtf-8' est valide et équivalent à 'xUtf-8+Utf-8'.
                Voir 'Annexes' pour les divers codages de cararactères
                utilisables.
    
    
    ----------------------------------------------------------------------------
    
    LICENCE :
        
        CeCILL v.2 (compatible GNU-GPL)
            http://www.cecill.info/licences/Licence_CeCILL_V2-fr.txt
            http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt
        
        Auteur : Billig 2009
                 linguae@stalikez.info                              
                 http://linguae.stalikez.info         
    
    
    ----------------------------------------------------------------------------
    
    ANNEXES :
    
    # Liste des codages  de caractères utilisables :
        
        ascii
        big5            (chinois)
        big5hkscs       (chinois)
        cp037           (IBM anglais)
        cp424           (IBM hébreu)
        cp437           (IBM anglais) 
        cp500           (IBM W-Europe)
        cp737           (grec)
        cp775           (IBM balte)
        cp850           (IBM W-Europe)
        cp852           (IBM E-Europe)
        cp855           (IBM cyrillique)
        cp856           (hébreu)
        cp857           (IBM turc)
        cp860           (IBM portuguais)
        cp861           (IBM islandais)
        cp862           (IBM hébreu)
        cp863           (IBM canadien)
        cp864           (IBM arabe)
        cp865           (IBM scandinave)
        cp866           (IBM russe)
        cp869           (IBM grec)
        cp874           (thaï)
        cp875           (grec)
        cp932           (japonais)
        cp949           (coréen)
        cp950           (chinois)
        cp1006          (urdu )
        cp1026          (IBM turc)
        cp1140          (IBM W-Europe)
        cp1250          (Win E-Europe)
        cp1251          (Win cyrillique)
        cp1252          (Win W-Europe)
        cp1253          (Win grec)
        cp1254          (Win turc)
        cp1255          (Win hébreu) 
        cp1256          (Win arabe)
        cp1257          (Win balte)
        cp1258          (Win vietnamien)
        euc_jp          (japonais)
        euc_jis_2004    (japonais) 
        euc_jisx0213    (japonais)
        euc_kr euckr    (coréen)
        gb2312          (chinois simplifié)
        gbk 936         (chinois unifié)
        gb18030         (chinois unifié)
        hz hzgb         (chinois simplifié)
        iso2022_jp      (japonais)
        iso2022_jp_1    (japonais)
        iso2022_jp_2    (japonais)
        iso2022_jp_2004 (japonais)
        iso2022_jp_3    (japonais)
        iso2022_jp_ext  (japonais)
        iso2022_kr      (coréen)
        iso-8859-1      (W-Europe)
        iso-8859-2      (E-Europe)
        iso-8859-3      (esperanto, maltais)
        iso-8859-4      (balte)
        iso-8859-5      (cyrillique)
        iso-8859-6      (arabe)
        iso-8859-7      (grec)
        iso-8859-8      (hébreu)
        iso-8859-9      (turc)
        iso-8859-10     (scandinave)
        iso-8859-13     (balte)
        iso-8859-14     (celtique)
        iso-8859-15     (W-Europe)
        johab           (coréen)
        koi8_r          (russe) 
        koi8_u          (ukrainien)
        latin1          (->iso-8859-1)
        latin2          (->iso-8859-2)
        latin3          (->iso-8859-3)
        latin4          (->iso-8859-4)
        latin5          (->iso-8859-9)
        latin6          (->iso-8859-10)
        latin8          (->iso-8859-14)
        mac_cyrillic    (cyrillique)
        mac_greek       (grec)
        mac_iceland     (islandais)
        mac_latin2      (E-Europe)
        mac_roman       (W-Europe)
        mac_turkish     (turc)
        ptcp154         (kazaque)
        shift_jis       (japonais)
        shift_jis_2004  (japonais)
        shift_jisx0213  (japonais)
        utf_16 
        utf_16_be       (BMP)
        utf_16_le       (BMP) 
        utf_7' 
        utf_8' 
        utf_8_sig'
    
    
    # Codes par défaut pour les conversions, en l'absence de leur indication
      dans -with <param> :
        
        Format du fichier source :         
            Ling : utf-8+utf-8 (imposé)
            Dict : utf-8+utf-8 (imposé)
            XDXF : utf-8+utf-8 (imposé)
            WB   : cp1252+cp1252 (modifiable)
            ini  : cp1252+cp1252 (modifiable)
            csv  : (demandé lors de l'éxécution si absent)
            tab  : (demandé lors de l'éxécution si absent)
        
        Format du fichier cible :
            Ling    : xutf-8+utf-8 (imposé)
            Preling : xutf-8+utf-8 (imposé)
            Dict    : xutf-8+utf-8 (imposé)
            XDXF    : xutf-8+utf-8 (imposé)
            WB      : xcp1252+cp1252 (modifiable)
        
    
    
    ----------------------------------------------------------------------------
    
    Pour réafficher la présente aide, tapez :
            linguae ?
        ou
            linguae help
    
    (nb : linguae.pyw sous Windows)
    
    """

    def __init__(self):
        
        # Mémoriser la plateforme d'éxécution
        syspf = sys.platform.lower()
        if syspf[:3] == 'win':      # Windows
            self.pf = "win"
        elif syspf[:5] == 'linux':  # Linux
            self.pf = "linux"
        elif syspf[:6] == 'darwin': # Mac osX
            self.pf = "osx"
        else:                       # autres
            self.pf = syspf
        
        
        # Accès aux chaînes de langue
        self.lgget = lib.mylang.MultiLanguage(lgcode="fr").get
        
        
        argl = sys.argv
        sourcepath = ""
        ciblepath = ""
        param = ""
        action = ""
        
        # ----------------------------------------------------------
        # --- Afficher l'aide de la ligne de commande et quitter    
        # ----------------------------------------------------------
        
        if ("help" in argl) or ("?" in argl) or (len(argl)==1):
            
            
            # --- Récupérer le n° de version du programme       
            infoversion = ""
            try:
                
                f = open(os.path.join(os.path.dirname(argl[0]), "corpus.py"), "r")
                    
                # lire les 30 premières lignes du fichier
                for i in range(30):
                    ligne = f.readline()
                    if ligne.startswith("versionProgr"):
                        infoversion = ligne.split("=")[1].strip(' "\r\n')
                        break
                f.close()
            except:
                pass
            
            txthlp = "\n  LINGUAE " + infoversion + "\n" + LinguaeConsole.strhlp
            
            if self.pf == "win":
                try:
                    txthlp = txthlp.decode('utf-8')
                except:
                    pass
                try:
                    txthlp = txthlp.encode('cp850')
                except:
                    pass
            
            print txthlp
            sys.exit()
        
        
        # ------------------------------------
        # --- Analyser la ligne de commande   
        # ------------------------------------
        
        # nettoyer les éventuels guillemets
        for a in argl:
            a = a.strip("'\"")
        
        for n in range(len(argl)):
            
            a = argl[n]
            
            if a == "-i":
                sourcepath = argl[n+1] 
                
            elif a == "-o" :
                ciblepath = argl[n+1]
                
            elif a == "-do":
                action = argl[n+1].lower()
                
            elif a == "-with":
                param = argl[n+1] 
                
            else:
                pass
        
        
        # Contrôles de validité des commandes > quitter si invalide
        if not os.path.isfile(sourcepath):
            print "Chemin du fichier source invalide !" + LinguaeConsole.strminihlp
            sys.exit()
        
        if action == "":
            print "Paramètre -do absent !" + LinguaeConsole.strminihlp
            sys.exit()
            
        elif action == "sort":
            if (param != "") and (not os.path.isfile(param)):
                print "Chemin du fichier de paramètres invalide !" + LinguaeConsole.strminihlp
                sys.exit()
        
        # Instancier une pseudo-barre de progression en mode texte
        
        self.progr = ProgressBarCons()
        
        
        # ------------------------------------------------------------------
        # --- Instancier un objet dictionnaire à partir du fichier source   
        # ------------------------------------------------------------------
        
        cp1 = ""
        cp2 = ""
        
        # format et encodages du fichier source si conversion
        if action.startswith("to"): 
            
            fmt = os.path.splitext(sourcepath)[1].lower()
            
            if fmt in (".wb", ".tab", ".csv", ".txt", ".ini"):
                cps = param.split("+")
                try   : cp1 = cps[0].strip()
                except: pass
                try   : cp2 = cps[1].strip()
                except: cp2 = cp1
                
            if "fmt" in (".wb", ".ini"):
                if cp1 == "": cp1 = "cp1252"
                if cp2 == "": cp2 = "cp1252"
        
        self.dic = lib.mydic.DicObject( 
                        dicfilepath = sourcepath,
                        lgget = self.lgget,
                        prgbar = self.progr,
                        winparent = None,
                        cp1 = cp1, cp2 = cp2,
                        cachedir = "",
                        )
        
        
        # -------------------------------------------
        # --- Contrôles préalables                   
        # -------------------------------------------
        
        cp1 = ""
        cp2 = ""
        
        if action.startswith("to"):     # Conversions
            
            if ciblepath != "":
                if not os.path.isdir(os.path.dirname(ciblepath)):
                    print "Chemin du fichier cible invalide !" + LinguaeConsole.strminihlp
                    sys.exit()
            # Construire le chemin du fichier cible si absent
            else:
                if action == "toling": fmt = ".ling"
                elif action == "topreling": fmt = ".preling"
                elif action == "towb": fmt = ".wb"
                elif action.startswith("todict"): fmt = ".dict"
                elif action == "toxdxf": fmt = ".xdxf"
                
                ciblepath = os.path.splitext(sourcepath)[0] + fmt  
            
            # encodages du fichier cible
            fmt = os.path.splitext(ciblepath)[1].lower()
            if fmt in (".wb", ".tab", ".csv", ".txt"):
                
                try:
                    cps = param.split("x")[1]
                    cps = cps.split("+")
                    try   : cp1 = cps[0].strip()
                    except: pass
                    try   : cp2 = cps[1].strip()
                    except: cp2 = cp1
                except:
                    pass
        
        
        # -----------------------------------------------------------
        # --- Aiguillage en fonction de l'action et des paramètres   
        # -----------------------------------------------------------
        
        ret = ""
        
        # --- Conversions ------------------------------------------------------
        if action == "towb":
            
            if cp1 == "": cp1 = "cp1252"
            if cp2 == "": cp2 = "cp1252"
            
            ret = ret = self.dic.doExportToWB(fichpath = ciblepath,
                                              cp1 = cp1,
                                              cp2 = cp2,
                                              prgbar = self.progr)
            
        elif action == "toxdxf":
            
            ret = self.dic.doExportToXDXF(fichpath = ciblepath,
                                          flagcleantags = False,
                                          prgbar = self.progr)
            
        elif action == "todict":
            
            ret = self.dic.doExportToXDXF(fichpath = ciblepath,
                                          flagfusion = False,
                                          flagcleantags = False,
                                          flagtransgram = False,
                                          subdict = "m",
                                          prgbar = self.progr)
        
        elif action == "toling":
            
            ret = self.dic.doExportToLing(fichpath = ciblepath,
                                          protected1 = "",
                                          protected2 = "",
                                          flagcleantags = False,
                                          prgbar = self.progr)
            
        elif action == "topreling":
            
            ret = self.dic.doExportToPreling(fichpath = ciblepath,
                                             protected1 = "",
                                             protected2 = "",
                                             flagcleantags = False,
                                             prgbar = self.progr,
                                             br="\r\n")
            
        elif action == "todictm":
            
            ret = self.dic.doExportToDict(fichpath = ciblepath,
                                          flagfusion = False,
                                          flagcleantags = False,
                                          flagtransgram = False,
                                          subdict = "m",
                                          prgbar = self.progr)
            
        elif action == "todictx":
            
            ret = self.dic.doExportToDict(fichpath = ciblepath,
                                          flagfusion = False,
                                          flagcleantags = False,
                                          flagtransgram = False,
                                          subdict = "x",
                                          prgbar = self.progr)
        
        # --- Tri du dictionnaire ----------------------------------------------
        
        elif action == "sort":
            
            equs = None
            
            if param != "":
            
                # Convertir le fichier de paramètres en pyDictionnaire
                ff = open(param,"rU")
                
                equs = {}
                for ligne in ff:
                    if '=' in ligne:
                        try:
                            ligne = ligne.encode('utf-8')
                        except:
                            pass
                        
                        chps = ligne.split('=')
                        
                        chp0 = chps[0].strip()
                        chp0 = chp0.replace("$$", " ")
                        
                        chp1 = chps[1].strip()
                        if chp1 == "%%":
                            chp1 = ""
                        
                        equs[chp0] = chp1
            
            self.dic.sortdic(equs)
        
        
        
        # ---------------------------------------------------------
        # --- Traitement du message de retour                      
        # ---------------------------------------------------------
        
        self.progr.setValue(-1)
        
        if ret == "":
            ret = "Terminé"
        
        if self.pf == "win":
            try:
                ret = ret.encode('cp850')
            except:
                pass
        else:
            try:
                ret = ret.encode('utf-8')
            except:
                pass
        
        print ret
        
        
        return





# //////////////////////////////////////////////////////////////////////////
# /// MAIN : Lancement du corps de l'application ///////////////////////////
# //////////////////////////////////////////////////////////////////////////

app = LinguaeConsole()

sys.exit()
