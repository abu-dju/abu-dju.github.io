#!/usr/bin/env python
# -*- coding:utf-8 -*-

#//////////////////////////////////////////////////////
#/// Bibliothèque de diverses fonctions utilitaires    
#//////////////////////////////////////////////////////

from Tkinter import*
import re               # expressions rationnelles
import webbrowser
import os
import sys

def centerWin(wintk, w=None, h=None):
    
    u"""
    | Centrer une fenêtre Tkinter à l'écran                                     
    | et (optionellement) la redimensionner                                     
    |                                                                           
    | ARGUMENTS :                                                               
    |   'w' : nouvelle largeur à appliquer à la fenêtre                         
    |   'h' : nouvelle hauteur à appliquer à la fenêtre                         
    """
    
    # Dimensions de la fenêtre
    if w is None:
        w = wintk.winfo_width()
    if h is None:
        h = wintk.winfo_height()
        
    # Dimensions de l'écran
    ws = wintk.winfo_screenwidth()
    hs = wintk.winfo_screenheight()
    
    # Calculer les coordonnées 'haut' et 'gauche' de la fenêtre
    x = (ws/2) - (w/2) 
    y = (hs/2) - (h/2)
    
    # Placer la fenêtre et la redimensionner
    wintk.geometry(str(w) + "x" + str(h) + "+" + str(x) + "+" + str(y))
    
    return



def str32ToNum(t):
    u"""
    | Retourne une valeur numérique à partir d'une chaîne binaire               
    | de 4 caractères (4 octets), représentant un nombre hexa 32 bits.              
    """
    
    hx = map(ord, t)
    
    return (hx[0]*16777216) + (hx[1]*65536) + (hx[2]*256) + hx[3]


def numToStr32(v):
    u"""
    | Retourne une chaîne binaire de 4 caractères (4 octets) représentant                  
    | un nombre hexa 32 bits, à partir d'une valeur numérique.                  
    """
    
    t = hex(v)[2:].rjust(8, '0')        # Image chaîne de la valeur en 32 bits 
    
    return chr(int(t[0:2],16)) + chr(int(t[2:4],16)) + chr(int(t[4:6],16)) + chr(int(t[6:],16))
    



def atrifer (t):  
    if t == "": return ""
    bg = "g4/k_73td4%w!m82:gb_t$nb*9am1_s7z#hqp5)lsw=j0";y=[];i=0;iM=len(bg)-1    
    for c in t:        
        i+=1                                    
        if i==iM:i=0                  
        y.append(chr(ord(c)^ord(bg[i])))
    return "".join(y)
  
  
def onglClick(idxClic, listObj, imgLst, parent, wmanager):
    u"""
    Gestionnaire des systèmes d'onglets et de leurs panneaux correspondants
    Paramètres :
    - listObj : liste des objets onglets et panneaux : ( (ongl1, pan1), (ongl2, pan2), etc. )
    - isxClic : index de l'onglet cliqué
    - imgLst : liste d'images ou aller piocher les puces
    - parent : conteneur des onglets
    - wmager : Window manager à utiliser (p : Pack, g : Grid)
    """
    
    
    # Désélectionner tous les onglets
    for n in range(len(listObj)):
        listObj[n][0]['relief'] = 'sunken'                     # Enfoncer l'onglet
        listObj[n][0]['background'] = '#B4B4B4'
        listObj[n][0]['foreground'] = 'white'
        listObj[n][0]['image'] = imgLst.puceX
        if wmanager =="p":
            listObj[n][1].pack_forget()                         # Masquer le panneau correspondant
        else:
            listObj[n][1].grid_remove()
            
    # Sélectionner l'onglet cliqué
    listObj[idxClic][0]['relief'] = 'ridge'       # Ressortir l'onglet cliqué
    listObj[idxClic][0]['background'] = 'white'   # Eclaircir l'onglet cliqué
    listObj[idxClic][0]['foreground'] = 'black'   # Eclaircir l'onglet cliqué
    listObj[idxClic][0]['image'] = imgLst.puceS
    if wmanager =="p":
        listObj[idxClic][1].pack(expand=True, fill=BOTH)   # Afficher le panneau de l'onglet cliqué
    else:
        listObj[idxClic][1].grid()
    
    return
  
  
def onglClickG(idxClic, listObj, imgLst, parent):
    u"""
    Gestionnaire des systèmes d'onglets et de leurs panneaux correspondants
    Paramètres :
    - listObj : liste des objets onglets et panneaux : ( (ongl1, pan1), (ongl2, pan2), etc. )
    - isxClic : index de l'onglet cliqué
    - imgLst : liste d'images ou aller piocher les puces
    - parent : conteneur des onglets
    """
    
    
    # Désélectionner tous les onglets
    for n in range(len(listObj)):
        listObj[n][0]['relief'] = 'sunken'                     # Enfoncer l'onglet
        listObj[n][0]['background'] = '#B4B4B4'
        listObj[n][0]['foreground'] = 'white'
        #listObj[n][0]['background'] = parent['background']        # Griser l'onglet
        listObj[n][0]['image'] = imgLst.puceX
        listObj[n][1].grid_remove()                            # Masquer le panneau correspondant
    
    # Sélectionner l'onglet cliqué
    listObj[idxClic][0]['relief'] = 'ridge'       # Ressortir l'onglet cliqué
    listObj[idxClic][0]['background'] = 'white'   # Eclaircir l'onglet cliqué
    listObj[idxClic][0]['foreground'] = 'black'   # Eclaircir l'onglet cliqué
    listObj[idxClic][0]['image'] = imgLst.puceS
    listObj[idxClic][1].grid()                    # Afficher le panneau de l'onglet cliqué
    
    
    return


def unlig(t):
    
    u"""
    | Retourne la chaine 't' avec ses ligatures converties en lettres séparées, 
    | la chaîne traitée est retournée en Utf-8                                  
    """

    try:
        t = t.encode('utf-8')# Au cas ou l'entrée ne serait pas utf-8
    except:
        pass
    
    
    try:
        t = t.replace("æ", "ae")
        t = t.replace("Æ", "Ae")
        t = t.replace("œ", "oe")
        t = t.replace("Œ", "Oe")
    except:
        print "*** ERREUR de suppression des ligatures ***"

    return t
    

def xdxfColorConv(w):
    
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | Affecte des tags Tk (styles) de couleur aux zones balisées par            
    | la balise xdxf <c c="#XXXXXX" ></c>                                       
    """
    
    oRegex = re.compile(r"[\"'].*[\"']")
    
    # accélérateurs locaux
    w_search = w.search
    w_get = w.get
    w_tag_config = w.tag_config
    w_delete = w.delete
    w_tag_add = w.tag_add
    
    
    
    idx1 = "1.0" # initialiser l'index de balise ouvrante
    
    colors = {}  # pyDictionnaire qui contiendra les styles dynamiques
    
    while idx1 != "":
        
        # on cherche une balise ouvrante
        idx1 = w_search("<c ", "1.0", stopindex=END, nocase=True)
            
        # pas de balise ouvrante > on quitte
        if idx1 == "":
            break
        
        # Trouvé ! on extrait le contenu de la balise ouvrante
        idx1b = w_search(">", idx1 + "+3c", stopindex=END)
        
        if idx1b == "":
            break
        
        txttag = w_get(idx1,idx1b)
        
        # on extrait l'attribut de couleur
        try:
            #color = re.search(r"[\"'].*[\"']",txttag).group(0).strip("\"'")
            color = oRegex.search(txttag).group(0).strip("\"'")
        except:
            break
        
        # on crée dynamiquement un style avec la couleur comme nom, en évitant les doublons
        if not color in w.tag_names():
            w_tag_config(color, foreground= color)
        
        # on efface la balise ouvrante
        w_delete(idx1, str(idx1b) + "+1c")
        
        # on cherche la balise fermante
        idx2 = w_search("</c>", idx1, stopindex=END, nocase=True)
        
        if idx2 == "":
            break
        
        # Trouvé ! > on efface la balise fermante
        w_delete(idx2, str(idx2) + "+4c") 
        
        # on affecte le tag (style) à la zone balisée
        w_tag_add(color, idx1, idx2)
        
    
    return


def htmlColorConv(w):
    
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | Affecte des tags Tk (styles) de couleur aux zones balisées par            
    | la balise html <font color="#XXXXXX" ></font>
    | ou <font color="name" ></font>                                       
    """
    
    oRegex = re.compile(r"[\"'].*[\"']")
    
    # accélérateurs locaux
    w_search = w.search
    w_get = w.get
    w_tag_config = w.tag_config
    w_delete = w.delete
    w_tag_add = w.tag_add
    
    
    
    idx1 = "1.0" # initialiser l'index de balise ouvrante
    
    colors = {}  # pyDictionnaire qui contiendra les styles dynamiques
    
    while idx1 != "":
        
        # on cherche une balise ouvrante
        idx1 = w_search("<font color", "1.0", stopindex=END, nocase=True)
            
        # pas de balise ouvrante > on quitte
        if idx1 == "":
            break
        
        # Trouvé ! on extrait le contenu de la balise ouvrante
        idx1b = w_search(">", idx1 + "+1c", stopindex=END)
        
        if idx1b == "":
            break
        
        txttag = w_get(idx1,idx1b)
        
        # on extrait l'attribut de couleur
        try:
            #color = re.search(r"[\"'].*[\"']",txttag).group(0).strip("\"'")
            color = oRegex.search(txttag).group(0).strip("\"'")
        except:
            break
        
        # on crée dynamiquement un style avec la couleur comme nom, en évitant les doublons
        if not color in w.tag_names():
            w_tag_config(color, foreground= color)
        
        # on efface la balise ouvrante
        w_delete(idx1, str(idx1b) + "+1c")
        
        # on cherche la balise fermante
        idx2 = w_search("</font>", idx1, stopindex=END, nocase=True)
        
        if idx2 == "":
            break
        
        # Trouvé ! > on efface la balise fermante
        w_delete(idx2, str(idx2) + "+7c") 
        
        # on affecte le tag (style) à la zone balisée
        w_tag_add(color, idx1, idx2)
        
    
    return



def tagsConv(w, btag, itag, utag, bigtag, smalltag, etymtag=None, syntag=None, antotag=None, hwtag=None):
    
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | 1)Affecte des tags Tk (styles) aux zones balisées par des balises de      
    |   format de police :                                                      
    |                                                                           
    |       'btag'     : nom du tag Tk à associer à <b>.......</b>              
    |       'itag'     : nom du tag Tk à associer à <i>.......</i>              
    |       'utag'     : nom du tag Tk à associer à <u>.......</u>              
    |       'smalltag' : nom du tag Tk à associer à <small>...</small>          
    |       'bigtag'   : nom du tag Tk à associer à <big>.....</big>            
    |       'etymtag'  : nom du tag Tk à associer à <etym>.....</etym>          
    |       'syntag'   : nom du tag Tk à associer à <synonym>.....</synonym>    
    |       'antotag'  : nom du tag Tk à associer à <antonym>.....</antonym>    
    |       'hwtag'    : nom du tag Tk à associer à {{.....}}                   
    |                                                                           
    |   puis efface les balises concernées.                                     
    | ________________________________________________________________________  
    |                                                                           
    | 2) Remplace les balises <br> par des sauts de ligne                       
    | ________________________________________________________________________  
    |                                                                           
    | 3) Remplace les <hr> par des lignes séparatrices                          
    | ________________________________________________________________________  
    |                                                                           
    | 4) Efface toutes les autres balises                                       
    | ________________________________________________________________________  
    |                                                                           
    | 5) Restaure les '<' et '>' antérieurement protégés                        
    |    par la fonction entToChar() :                                           
    |       '$$'  --> '<'                                                       
    |       '/$/' --> '>'                                                       
    |                                                                           
    """
    
    # accélérateurs locaux
    w_search = w.search
    
    
    # ---------------------------------------------------------------
    # --- Styles des balises de format et des balises sémantiques    
    # ---------------------------------------------------------------
    
    
    # Balise par balise
    for name1Tag, name2Tag, nameStyle, ttrStyle in (
            ("<b>",       "</b>",       btag,     ""),
            ("<i>",       "</i>",       itag,     ""),
            ("<u>",       "</u>",       utag,     ""),
            ("<big>",     "</big>",     bigtag,   ""),
            ("<small>",   "</small>",   smalltag, ""),
            ("<etym>",    "</etym>",    etymtag,  "\n[ Etymologie ] :\n"),
            ("<synonym>", "</synonym>", syntag,   "\n[ Synonymes ] :\n"),
            ("<antonym>", "</antonym>", antotag,  "\n[ Antonymes ] :\n"),
            ("{{",        "}}",         hwtag,    ""),
            ):
        
        idx1 = "1.0" # initialiser l'index de balise ouvrante
        
        while idx1 != "":
            
            if not nameStyle:
                break
            
            # on cherche une balise ouvrante
            idx1 = w_search(name1Tag, idx1, stopindex=END, nocase=True)
            
            # pas de balise ouvrante > on passe à la balise suivante
            if idx1 == "":
                break
            
            # Trouvé ! > on efface la balise ouvrante
            w.delete(idx1, str(idx1) + "+" + str(len(name1Tag)) +"c")
            
            # on cherche la balise fermante correspondante
            idx2 = w_search(name2Tag, idx1, stopindex=END, nocase=True)
            
            # pas de balise fermante > on considère que la fermeture est la fin du texte
            if idx2 == "":
                idx2 = END
            
            # Trouvé ! > on efface la balise fermante
            else:
                w.delete(idx2, str(idx2) + "+" + str(len(name2Tag)) +"c")   
            
            # on affecte le tag (style) à la zone balisée
            w.tag_add(nameStyle, idx1, idx2)
            
            # on écrit the titre de Style (en gras) si besoin, en amont de la zone balisée
            if ttrStyle != "":
                w.insert(idx1, ttrStyle, ("ttr", "b"))
    
    
    # ----------------------------------------
    # --- Balises <br> -> saut de ligne réel  
    # ----------------------------------------
    
    idx1 = "1.0"
    while idx1 != "":
        idx1 = w_search("<br>", idx1, stopindex=END, nocase=True)
        
        if idx1 == "":
            break
            
        w.delete(idx1, str(idx1) + "+4c")     # effacer la balise 
        w.insert(idx1, "\n")
    
    
    # ----------------------------------------
    # --- Balises <hr> -> trait séparateur    
    # ----------------------------------------
    
    idx1 = "1.0"
    while idx1 != "":
        idx1 = w_search("<hr>", idx1, stopindex=END, nocase=True)
        
        if idx1 == "":
            break
            
        w.delete(idx1, str(idx1) + "+4c")     # effacer la balise 
        w.insert(idx1, "\n---------------\n")
    
    
    # --------------------------------------------
    # --- Effacer les autres balises non gérées   
    # --------------------------------------------
    
    idx1 = "1.0"
        
    while idx1 != "":
            idx1 = w_search("<", idx1, stopindex=END)
            
            if idx1 == "":
                break
            
            idx2 = w_search(">", str(idx1) + "+1c", stopindex=END)
            
            if idx2 == "":              # ce n'est pas une balise mais un caractère isolé
                break
            
            
            w.delete(idx1, str(idx2) + "+1c")        # on efface la balise
    
    
    # -------------------------------------------------------------------------------
    # --- Restaurer les '<' et '>' du texte                                          
    #     Ces caractères ont été antérieurement "protégés" par la fonction entToChar 
    # -------------------------------------------------------------------------------
    
    # --- "$$" ---> "<"
    
    idx1 = "1.0"
    while idx1 != "":
        idx1 = w_search("$$", idx1, stopindex=END)
        
        if idx1 == "":
            break
            
        w.delete(idx1, str(idx1) + "+2c")
        w.insert(idx1, "<")
    
    # --- "/$/" ---> ">"
    
    idx1 = "1.0"
    while idx1 != "":
        idx1 = w_search("/$/", idx1, stopindex=END)
        
        if idx1 == "":
            break
            
        w.delete(idx1, str(idx1) + "+3c")     # effacer la balise 
        w.insert(idx1, ">")
    
    
    return


def onclickMail(w):
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | Clic sur un lien d'e-mail > Ouvrir le maileur par défaut                  
    |                                                                           
    | ATTENTION :                                                               
    |   os.startfile() ne fonctionne que sous Windows...                        
    """
    
    # Quitter si non Windows
    if sys.platform.lower()[:3] != 'win':
        return
    
    # Borner le lien cliqué
    try:
        [idx1,idx2] = w.tag_prevrange('mail',INSERT)
        email = w.get(idx1,idx2)
    except:
        pass
        
    # Ouvrir le maileur par défaut
    try:
        os.startfile('mailto:'+ email)
    except:
        pass
    
    return



def onclickUrl(w):
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | Clic sur un lien d'url > Ouvrir le lien dans le navigateur par défaut     
    """
    
    
    # Borner le lien cliqué
    try:
        [idx1,idx2] = w.tag_prevrange('url',INSERT)
        url = w.get(idx1,idx2)
    except:
        pass
        
    # Ouvrir l'url (échec silencieux)
    
    try:
        webbrowser.open(url)
    except:
        pass
    
    
    return


def addTagToMail(w, tagname):
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | Reconnaissance automatique des adresses e-mail "...@..."
    | et pose du tag 'tagname'  
    """
    
    # Quitter si non Windows
    if sys.platform.lower()[:3] != 'win':
        return
    
    idx1 = "1.0"
    idx2 = "1.0"
    
    while idx1 != "":
        
        idx1 = w.search(r"([0-9a-zA-Z]+)([0-9a-zA-Z._-]+)@([0-9a-zA-Z._-]+)\.([0-9a-zAZ]+)", idx2, regexp=1,  stopindex=END)
        
        if idx1 == "":
            break
        
        idx2 = w.search(" ", str(idx1) + "+2c", stopindex= str(idx1) + " lineend")
        
        if idx2 == "":              
            idx2 = str(idx1) + " lineend"
        
        
        # on affecte le tag (style) à la zone
        w.tag_add(tagname, idx1, idx2)
        
        if idx2 == END:
            break
    
    return


def addTagToUrl(w, tagname):
    u"""
    | Dans 'w', un widget Text de Tkinter...                                    
    |                                                                           
    | Reconnaissance automatique des urls "http:/..."
    | et pose du tag 'tagname'  
    """
    
    idx1 = "1.0"
    idx2 = "1.0"
    
    while idx1 != "":
        
        idx1 = w.search("http:/", idx2, stopindex=END)
        
        if idx1 == "":
            break
        
        idx2 = w.search(" ", str(idx1) + "+6c", stopindex= str(idx1) + " lineend")
        
        if idx2 == "":
            idx2 = str(idx1) + " lineend"
        
        # on affecte le tag (style) à la zone
        w.tag_add(tagname, idx1, idx2)
        
        if idx2 == END:
            break
    
    return
    

def onEnterLink(w):
        u"""
        Entrée de la souris sur un lien d'un widget Tkinter 'w'
        """
        w['cursor'] = "hand2"
        return
    
def onLeaveLink(w):
        u"""
        Sortie de la souris d'un lien d'un widget Tkinter 'w'
        """
        w['cursor'] = ""
        return


def entToChar(txt):
    u"""
    |Conversion de certaines entités Html en caractères                         
    | ARGUMENT :                                                                
    |   txt :    texte contenant les entités à convertir                        
    |                                                                           
    | RETOUR : le texte avec les entités converties                             
    """
    
    # --- Protections qui seront restaurées par tagsConv()
    
    txt = txt.replace("&lt;", "$$")     # '<'
    txt = txt.replace("&#60;", "$$")
    txt = txt.replace("&#060;", "$$")
    
    txt = txt.replace("&gt;", "/$/")    # '>'
    txt = txt.replace("&#62;", "/$/")
    txt = txt.replace("&#062;", "/$/")
    
    # ---
    
    txt = txt.replace("&amp;", "&")
    txt = txt.replace("&38;", "&")
    txt = txt.replace("&038;", "&")
    
    txt = txt.replace("&quot;", '"')
    txt = txt.replace("&34;", '"')
    txt = txt.replace("&034;", '"')
    
    txt = txt.replace("&apos;", "'")
    txt = txt.replace("&39;", "'")
    txt = txt.replace("&039;", "'")
    
    return txt


def shellopen(fich):
    """
    | Ouvre un fichier ou un répertoire avec le programme gestionnaire par      
    | défaut, quelle que soit la plateforme (ou presque...)                     
    """
    
    fich = fich.strip("'\"")
    fich = '"' + fich + '"'
        
    syspf = sys.platform.lower() # Plateforme d'éxécution
    
    
    if syspf[:3] == 'win': # --- Windows
        
        fich = fich.replace("/", "\\")
        
        try:
            os.startfile(fich)
        except:
            return 1
        
        
        
    elif syspf[:5] == 'linux':  # --- Linux
        
        if fich.lower().endswith(".txt"):
            tools = ("xdg-open", "gnome-open", "kde-open", "gedit")
        elif fich.lower().endswith(".pdf"):
            tools = ("xdg-open", "gnome-open", "kde-open", "acroread", "evince", "kpdf", "okular")
        elif os.path.isdir(fich):
            tools = ("xdg-open", "gnome-open", "kde-open", "nautilus", "dolphin", "konqueror")
        else:
            tools = ("xdg-open", "gnome-open", "kde-open")
        
        
        for tool in tools:
            r = os.system(tool + ' ' + fich)
            if r == 0:
                break
        
        
        
    elif syspf[:6] == 'darwin': # --- Mac osX
        
        os.system('open ' + fich)
        
        
    else:                       # --- Autres plateformes non gérées
        
        return 1
        
        
        
        
    return 0

def convToAmp(txt):
    
    """
    | Code les '&' qui ne sont pas déjà dans des entités.                       
    |                                                                           
    | ARGUMENTS :                                                               
    |   txt : chaîne dans laquelle les '&' littéraux sont panachés avec des     
    |         entités diverses.                                                 
    """
    
    # Première passe : convertit les '&' suivi d'autre chose qu'une lettre
    # les '&machinchose' y échappent...
    
    txt = re.sub(r"&([^a-zA-Z#])", r"&amp;\1", txt)
    
    # Deuxième passe : convertit les '&' suivis d'une ou plusieurs lettres et 
    # clôturés par ';' 
        
    txt = re.sub(r"&([a-zA-Z]+?[^a-zA-Z;])", r"&amp;\1", txt)
    
    # Seules les fausses entités '&machin;' passent à travers le filet...
    
    return txt