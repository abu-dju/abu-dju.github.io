#!/usr/bin/env python
# -*- coding:utf-8 -*-

#///////////////////////////////////
#/// Widget EncodingSelector ///////
#///////////////////////////////////

from Tkinter import*

class EncodingSelector(Frame):
  
    M_codecs=('ascii', 
          'big5 (chinois)',
          'big5hkscs (chinois)',
          'cp037 (IBM anglais)',
          'cp424 (IBM hébreu)',
          'cp437 (IBM anglais)', 
          'cp500 (IBM W-Europe)', 
          'cp737 (grec)', 
          'cp775 (IBM balte)',
          'cp850 (IBM W-Europe)',
          'cp852 (IBM E-Europe)',
          'cp855 (IBM cyrillique)',
          'cp856 (hébreu)', 
          'cp857 (IBM turc)',
          'cp860 (IBM portuguais)',
          'cp861 (IBM islandais)',
          'cp862 (IBM hébreu)',
          'cp863 (IBM canadien)',
          'cp864 (IBM arabe)',
          'cp865 (IBM scandinave)',
          'cp866 (IBM russe)', 
          'cp869 (IBM grec)', 
          'cp874 (thaï)', 
          'cp875 (grec)',
          'cp932 (japonais)',
          'cp949 (coréen)',
          'cp950 (chinois)',
          'cp1006 (urdu )',
          'cp1026 (IBM turc)',
          'cp1140 (IBM W-Europe)',
          'cp1250 (Win E-Europe)',
          'cp1251 (Win cyrillique)',
          'cp1252 (Win W-Europe)',
          'cp1253 (Win grec)', 
          'cp1254 (Win turc)', 
          'cp1255 (Win hébreu)', 
          'cp1256 (Win arabe)',
          'cp1257 (Win balte)',
          'cp1258 (Win vietnamien)',
          'euc_jp (japonais)', 
          'euc_jis_2004 (japonais)', 
          'euc_jisx0213 (japonais)',
          'euc_kr euckr (coréen)',
          'gb2312 (chinois simplifié)',
          'gbk 936 (chinois unifié)',
          'gb18030 (chinois unifié)',
          'hz hzgb (chinois simplifié)',
          'iso2022_jp (japonais)',
          'iso2022_jp_1 (japonais)',
          'iso2022_jp_2 (japonais)',
          'iso2022_jp_2004 (japonais)', 
          'iso2022_jp_3 (japonais)',
          'iso2022_jp_ext (japonais)',
          'iso2022_kr (coréen)',
          'iso-8859-1 (W-Europe)',
          'iso-8859-2 (E-Europe)',
          'iso-8859-3 (esperanto, maltais)',
          'iso-8859-4 (balte)',
          'iso-8859-5 (cyrillique)',
          'iso-8859-6 (arabe)', 
          'iso-8859-7 (grec)',
          'iso-8859-8 (hébreu)', 
          'iso-8859-9 (turc)', 
          'iso-8859-10 (scandinave)',
          'iso-8859-13 (balte)',
          'iso-8859-14 (celtique)',
          'iso-8859-15 (W-Europe)',
          'johab (coréen)', 
          'koi8_r (russe)', 
          'koi8_u (ukrainien)',
          'latin1 (->iso-8859-1)',
          'latin2 (->iso-8859-2)',
          'latin3 (->iso-8859-3)',
          'latin4 (->iso-8859-4)',
          'latin5 (->iso-8859-9)',
          'latin6 (->iso-8859-10)',
          'latin8 (->iso-8859-14)',
          'mac_cyrillic (cyrillique)',
          'mac_greek (grec)', 
          'mac_iceland (islandais)',
          'mac_latin2 (E-Europe)',
          'mac_roman (W-Europe)', 
          'mac_turkish (turc)', 
          'ptcp154 (kazaque)', 
          'shift_jis (japonais)', 
          'shift_jis_2004 (japonais)', 
          'shift_jisx0213 (japonais)',
          'utf_16', 
          'utf_16_be (BMP)',
          'utf_16_le (BMP)', 
          'utf_7', 
          'utf_8', 
          'utf_8_sig')
  
  
    def __init__(self, root="", text="", title="Encodage :", height=6, width=19): # CONSTRUCTEUR ##############
 
        # Invocation du contructeur du Frame représentant le widget
        # on lui passe certaines options du constructeur du widget
        Frame.__init__(self, root, borderwidth=0, relief='flat')    
        
        # === Mise en place de l'interface
        
        # Titre
        Label(self, text=title).grid(row=0, column=0, columnspan=4, sticky='W')
        
        # Case de texte
        self.txt_cp=Entry(self, width=width, background='white')
        self.txt_cp.insert(END, text)
        self.txt_cp.grid(row=1, column=0, sticky='WE')
        
        # Liste des encodages + scroll
        self.lst_cp=Listbox(self, height=height, width=width)
        self.lst_cp.grid(row=2, column=0, sticky='WE')
        self.lst_cp['font']=self.txt_cp['font']
        self.lst_cp.bind('<ButtonRelease-1>', self.__lstclic)
        
        self.scr=Scrollbar(self, command=self.lst_cp.yview)
        self.scr.grid(row=1, rowspan=2,column=1, sticky='NSW')
        self.lst_cp['yscrollcommand'] = self.scr.set
        
        self.lst_cp.bind('<Up>', self.__lstUpDown)
        self.lst_cp.bind('<Down>', self.__lstUpDown)
        self.lst_cp.bind('<Prior>', self.__lstUpDown)
        self.lst_cp.bind('<Next>', self.__lstUpDown)
        self.lst_cp.bind('<MouseWheel>', self.__scrollWheel)
        
        
        # Remplir la liste
        for t in self.M_codecs: self.lst_cp.insert(END, t)

    def __lstUpDown(self, event):
        u"""
        Action sur les touches haut-bas
        """
      
        if event.keysym == "Up": v = -1
        elif event.keysym == "Down": v = 1
        elif event.keysym == "Prior": v = -4
        elif event.keysym == "Next": v = 4
        else: return
        
        i = int(self.lst_cp.curselection()[0])   # index du mot en sélection
        
        self.lst_cp.selection_clear(0, END)
      
        i +=  int(v)
      
        if i < 0: i = 0
        if i >= self.lst_cp.size(): i = self.lst_cp.size()-1
        
        self.lst_cp.selection_set(i)
        self.lst_cp.see(i)
        
        self.__lstclic(event)       # Affiche la sélection dans la case
        
        return


    def __scrollWheel(self, event):
        u""" Scroll avec la roulette de souris """
      
        if event.delta <0:self.lst_cp.yview_scroll(1, 'units')
        else: self.lst_cp.yview_scroll(-1, 'units')
        
        return

    def get(self):
        """ Retourne la chaîne nommant l'encodage sélectionné """
        
        return self.txt_cp.get().split()[0]

    def __lstclic(self,event):
        """ Clic sur un élément de la liste """
        
        self.txt_cp.delete(0,END)
        try:
            self.txt_cp.insert(END, self.lst_cp.get(self.lst_cp.curselection()[0]))
        except:
            pass
        self.lst_cp.focus_set()
        
        return

    def setText(self, txt):
        self.txt_cp.delete(0,END)
        self.txt_cp.insert(END, txt)


#=== MAIN (widget en mode autonome interactif)
if __name__=='__main__':
    print '# # # MODE TEST INTERACTIF # # #'
    w=EncodingSelector()
    w.pack()
    w.mainloop()