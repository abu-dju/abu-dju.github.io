#!/usr/bin/env python
# -*- coding:utf-8 -*-

from Tkinter import*

# //////////////////////////////////////////////////
# ///   Greffon de démonstration                    
# ///           peut servir trame pour              
# ///           réaliser un greffon personnalisé    
# ///           pour Linguae                        
# //////////////////////////////////////////////////



class Widget(Frame):

    # Inscrire ici le code encodé en base64 d'une image servant d'icône pour le greffon
    # Le code de l'image est indépendant de l'instance du greffon
    # "codeImage = None" si le greffon n'a pas d'image
    # Le code suivant est une image gif 16x16x16  :
    codeImage = """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgMDAwICAgP8AAAD/AP//AAAA//8A/wD/
    /////ywAAAAAEAAQAAAELPDISau9NenNOf5HJ24gxpwHejIpmr4sLMsqLbH4bbd43selzEgUtAyJ
    xUkEADs=
    """

    def __init__(self, root="", borderwidth=1, relief='solid', width=300, height=200,
                    getlist=None, getfile=None, getdata=None, getAppDataPath=None, getlgcode=None):
        u"""
        Constructeur du widget_greffon
        
        - getlist : référence d'une fonction de l'hôte retournant la liste des entrées
         (laisser la valeur par défaut à None dans le greffon)
        
        - getfile : référence d'une fonction de l'hôte retournant l'objet fichier du dictionnaire courant
         (laisser la valeur par défaut à None dans le greffon)
        
        - getdata : fonction de l'hôte retournant les données associées à un mot
         (laisser la valeur par défaut à None dans le greffon)
        
        - getAppDataPath : fonction de l'hôte retournant le répertoire des données de l'application-hôte
         (laisser la valeur par défaut à None dans le greffon)
        
        - getlgcode : fonction de l'hôte retournant le code ISO-639 de la langue de l'interface
         (laisser la valeur par défaut à None dans le greffon)
        
        Le seul paramètre à éventuellement modifier est la valeur du 'relief' de la bordure
        """
        
        # Invocation du contructeur du Frame représentant le widget
        # on lui passe certaines options graphiques du constructeur du widget
        Frame.__init__(self, root, borderwidth=borderwidth, relief=relief, width=width, height=height)     
        
        # Inscrire ici un titre court pour le greffon
        # ce titre sera affiché dans le programme-hôte, dans l'onglet contenant le greffon
        self.title = "Demo" 
        
        
        # =============================================================
        # === Référence à des fonctions du programme-hôte              
        # =============================================================
        # ces références sont passées en arguments facultatifs lors de l'instanciation
        # Linguae les fournit systématiquement, mais ils sont facultatifs si le greffon n'en fait aucun usage
        
        self.getlist = getlist                  # fonction de l'hôte retournant la liste des mots
        self.getfile = getfile                  # fonction de l'hôte retournant l'objet fichier du dictionnaire
        self.getdata = getdata                  # fonction de l'hôte retournant les données associées à un mot
        self.getAppDataPath = getAppDataPath    # fonction de l'hôte retournant le rep des données d'application
        self.getlgcode = getlgcode              # fonction de l'hôte retournant le code de la langue d'interface
        
        
        
        # =============================================================
        # === Mise en place de l'interface graphique du widget         
        # === (ici limitée à des étiquettes, un bouton et une Listbox) 
        # =============================================================
        
        # Langue de l'interface (on appelle la fonction de l'hôte)
        try:
            self.lgcode = self.getlgcode()
        except:
            self.lgcode = "fr"
        
        # Chargement des chaînes de la langue de l'interface
        self.__loadlg()
        
        # On construit un objet PhotoImage de Tkinter
        self.monImage = PhotoImage(data=Widget.codeImage)
        
        # On affiche l'image dans un Label Tkinter
        Label(self, image=self.monImage).pack()
        
        # Texte de présentation
        Label(self, text="\n" + self.__lgget("g", "s1"), justify=LEFT).pack(anchor='w')
        Label(self, text=self.__lgget("g", "s2"), justify=LEFT).pack(anchor='w')
        
        # Etiquette d'affichage des données de sortie
        self.lab_display = Label(self, text="...", fg='red')
        self.lab_display.pack()
        
        # Bouton de récupération de la liste des entrées
        Button(self, text=" " + self.__lgget("g", "s3") + " ", command=self.__getHostList).pack()
        
        # Liste d'affichage du contenu des entrées du programme-hôte
        self.lst_hostlist = Listbox(self, width=50)
        self.lst_hostlist.pack(pady=10)
        
        return



    def display(self, motBrut):
        u"""
        Cette méthode est la méthode principale invoquée par le programme-hôte,
        celui-ci passe en paramètre le mot brut (le libellé d'une entrée de dictionnaire)
        au greffon, lorsque l'utilisateur clique sur une ligne de la liste des entrées.
        Le greffon va alors traîter ce mot.
        Dans ce contexte de démonstration, le traitement est limité à un simple affichage
        """
        
        self.lab_display['text'] = motBrut
        
        return


    def getTitle(self):
        u"""
        Le programme-hôte invoque cette méthode pour obtenir le titre du greffon
        Le programme-hôte utilise ce titre comme libellé de l'onglet hébergeant le greffon
        """
        
        return self.title      


    def __getHostList(self):
        u"""
        Méthode utilisée en interne par le greffon de démonstration pour traiter la liste
        de mots fournie par le programme-hôte
        Dans ce contexte de démonstration, le traitement est limité à un simple affichage
        """
        
        hostlist=()
       
        try:
            hostlist = self.getlist()         # Appel de la fonction de l'hôte
        except:
            self.lst_hostlist.delete(0, END)
            self.lst_hostlist.insert(END, self.__lgget("g", "s4"))
            return
          
        # On affiche la liste transmise
        self.lst_hostlist.delete(0, END)
        for t in hostlist:
            self.lst_hostlist.insert(END, t)
        
        
        return
  
  
    def __lgget(self, section, clef):
        u"""
        Méthode utilisée en interne par le greffon pour le multilinguisme de l'interface
        Appel d'une chaîne
        """
        
        return eval("self.lg_" + section +"['" + clef + "']")
    
    def __loadlg(self):
        u"""
        Méthode utilisée en interne par le greffon pour le multilinguisme de l'interface
        Chargement des chaînes (contenues dans des pyDictionnaires)
        """
        
        if self.lgcode in ("en", "eng"):
            self.lg_g = {
             "s1" : "Hi! I'm a widget for demonstration.\n\nI have no utility, except that to be a template\nfor your own works (see my code).\n\nAs I am, I only display in red the string sent\nby my host-program by invoking my method display()\nand I provide it my caption (Demo), that it displays in the tab inluding me.",
             "s2" : "I can also get a list of words provided by my host\n by invoking a function/method of it whose the reference\nwas transmitted at the time of my instantiation.",
             "s3" : "Get the list of headwords",
             "s4" : "(no list to get in this contect)",
            }
        
        else:   # français par défaut
            self.lg_g = {
             "s1"   : "Bonjour ! Je suis un greffon/widget de démonstration.\n\nJe n'ai aucune utilité, hormis celle de servir de modèle\nà vos propres réalisations (voir mon code).\n\nEn l'état, je me contente d'afficher en rouge la chaîne que me transmet\nmon programme-hôte en invoquant ma méthode display()\net je lui fournis mon titre (Démo), qu'il affiche dans l'onglet me contenant.",
             "s2"   : "Je peux également récupérer une liste de mots fournie par mon hôte\nen invoquant une fonction/méthode de celui-ci dont la référence\nm'a été transmise lors de mon instanciation.",
             "s3"   : "Récupérer la liste des entrées",
             "s4"   : "(pas de liste à récupérer dans ce contexte)",
            }
        
        return
    

# === MAIN (widget en mode autonome)
if __name__=='__main__':
    app=Tk()
    w=Widget(app)
    w.pack()
    app.mainloop() 