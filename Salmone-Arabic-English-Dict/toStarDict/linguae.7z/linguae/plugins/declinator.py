#!/usr/bin/env python
# -*- coding:utf-8 -*-


# ////////////////////////////////////////////////////////////////////////////
#                                                                             
#   Widget DECLINATOR                                                         
#   Déclinaison, conjugaison, traduction de mots latins                       
#                                                                             
#   sous licence CeCILL : http://www.cecill.info/                             
#                                                                             
#   Auteur   : Billig - 2008                                                  
#   Contact  : linguae@stalikez.info                                          
#   Site Web : http://linguae.stalikez.info                                   
#                                                                             
#   Nb : pour fonctionner de manière fiable et correcte,                      
#        Declinator doit recevoir comme entrée un mot latin possédant         
#        un codage grammatical bien précis (voir le fichier d'aide)           
#                                                                             
# ////////////////////////////////////////////////////////////////////////////



from Tkinter import*
from ScrolledText import*
import tkMessageBox
import tkFileDialog
import os.path
import time
import hashlib
import shutil

# NB : l'import de modules non standard dans un plugin n'est possible
# que s'ils sont présents dans le package de l'hôte (donc utilisés par ce dernier)
# le 'try' est nécessaire car ils ne sont pas chargeables en mode autonome (chemin incorrect dans ce cas)
try:
    import lib.mytools
    import lib.myscrlst                   # Widget perso : liste à barre de progression
except:
    pass


class AppData():
    u"""
    Classe de gestion du répertoire des données d'application (emplacement variable suivant la plateforme)
    et de son contenu
    
    On l'initialise avec le nom interne de l'application servant de libellé à ce répertoire
    
    On peut ensuite invoquer son attribut .path
    
    """
    
    def __init__(self, appname):
        
        self.path = ""      # Chemin complet du répertoire d'application
        
        
        # ---------------------------------------------------------------------
        # --- Déterminer le chemin du répertoire en fonction de la plateforme  
        # ---------------------------------------------------------------------
        
        pf = sys.platform.lower()
        
        # --- Windows
        if pf[:3] == 'win':
            
            repAppData = os.path.join(os.path.expanduser('~'), "Application Data", appname)
        
        # --- Unix (MacosX, Linux, )
        elif pf[:6] == 'darwin' or pf[:5] == 'linux':
            
            repAppData = os.path.join(os.path.expanduser('~'), "." + appname)
            
        # --- (autres plateformes)
        else:
            # Pour les autres plateformes, on utilise le répertoire de l'application,
            # en attente de documentation sur les chemins précis pour ces plateformes
            # (autres valeurs possibles : 'mac', 'sunos5', 'PalmOS3', 'hp-ux11')
            repAppData = os.path.dirname(os.path.realpath(sys.argv[0]))
        
        
        if not os.path.isdir(repAppData): os.mkdir(repAppData)  # Si ce répertoire n'existe pas > le créer
        
        
        # ---
        
        self.path = repAppData      # Chemin complet du répertoire d'application
        
        
        return
    



class Widget(Frame): # interface graphique de Declinator
      
    u"""
    Classe dessinant le widget et gérant son affichage interne
    """
        
    # image/icône du widget
    codeImage = """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgMDAwP8AAAD/AP//AAAA//8A//H/
    /////ywAAAAAEAAQAAAERBDISSsCL+utwX0SSCUkeGAhipGJiYpp2wInZ2e0CkusK4K/Xg5IAcl8
    N84wNSotXyFhTRV7zGrJTa7CnRwQh7B4TI4AADs=
    """



    def __init__(self, root="", borderwidth=0, relief='solid',
                    getlist=None, getfile=None, getdata=None, getAppDataPath=None, getlgcode=None):
        
        u"""
        Constructeur du widget-Declinator
        L'instanciation met en place l'interface graphique
        """
        
        # Invocation du contructeur du Frame représentant le widget
        # on lui passe les options du constructeur du widget
        Frame.__init__(self, root, borderwidth=borderwidth, relief=relief)
        
        # référence à des fonctions de l'hôte
        self.getlist = getlist
        self.getlist = getlist                  # fonction de l'hôte retournant la liste des mots
        self.getfile = getfile                  # fonction de l'hôte retournant l'objet fichier du dictionnaire
        self.getdata = getdata                  # fonction de l'hôte retournant les données associées à un mot
        self.getAppDataPath = getAppDataPath    # fonction de l'hôte retournant le rep des données d'application
        self.getlgcode = getlgcode              # fonction de l'hôte retournant le code de la langue d'interface
        
        # ---
        
        
         # Langue de l'interface (on appelle la fonction de l'hôte)
        try:
            self.lgcode = self.getlgcode()
        except:
            self.lgcode = "fr"
        
        # Chargement des chaînes de la langue de l'interface
        self.__loadlg()
        
        
        
        self.title = self.__lgget("g", "title") # Titre du greffon        
        self.flagChangeModeTemps = False        # flag de gestion des clics de changement de mode/temps
        
        
        self.oLatin = ""
        
        
        # ========================================================
        # === Construction des objets PhotoImage pour l'interface 
        # ========================================================
        
        self.monImage = PhotoImage(data=Widget.codeImage) # Logo du widget
        
        # gif 16x16x16 : compiler la liste des flexions
        self.img_mkflex = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgP/A/4CAgP8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAAcALAAAAAAQABAAAARF8BwmJa0X17mz7SDGXCM5imYafpoEvHAsH8Bj3/gN0Dbh
        /4RH8AFA1HJIorEXBPpsxWMSF2U+gdDllGqUeWGIA2JMLpsjADs=""")
        
        # gif 16x16x16 : aide (logo aide style Xp)
        self.img_hlp = PhotoImage(data="""R0lGODlhEAAQALMAAEA/PUJBPldWVAExvRlOuShfy095zWqT4YB+eaKgnZis1K3M68C9tf/A/+Dj
        6BQHqCH5BAEAAA0ALAAAAAAQABAAAAR1sMnmqp2Y2l0Z5ku4WMlkHcp5kJpzrM7oGEWVMNVRrMaw
        6qsFolIoFgkjWs0hIBoLqQOhWAk4iwaHYkp1WB3PlZGQXXy3Rt1xlBBoDARCNJ7yIiQVtKIgrwgE
        Hg04eQoyDggCJRIMCYYdf4oYbQEAlQGJExEAADs=""")
        
        # gif 16x16x16 : info sur fond noir
        self.img_info = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgMDAwICAgP8AAAD/AP//wAAA//8A/wD/
        /////ywAAAAAEAAQAAAEOxDISau9GJzH38EbxzDc8VGhSG7mlHYde77j6rUa/IzsLb07m+mUK/Fu
        xJ+pxhiChs4MaiOtUKsobCUCADs=""")
        
        # gif 16x16x16 : traduction
        self.img_traduc = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAAAAgAAA/4AAAP//AMDAwP///9E7S4CAgAAAAOnp6RLrlBQAAP/A/wAA
        BhQHqCH5BAEAAA0ALAAAAAAQABAAAAQvsMlJqxVC4mwb517nbZoYhmD3jakpAnAsy27dHIeE5x3P
        36KdzzT89XQ3nG1ZiwAAOw==""")
        
        # gif 16x16x16 : coller
        self.img_paste = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgMDAwP8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAA0ALAAAAAAQABAAAARRsEkJKpi42brWvtRwDIBXAuMBoirivigZql91qFQq7vrK
        D4SgkLDSHQiPZDI42yGVDyRBY5QGo0LA7wldxlLWYVSz4XanmbBwnO4q0ZihnBABADs=""")
        
        # gif 16x16x16 : ouvrir un fichier
        self.img_open= PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAAgALAAAAAAQABAAAAQ4EMlJq6Ug3wpm7xsHZqBFIsDyLGTLrbCqllIaxzSKt3wm
        A4OgUPhZAYfDEQuZ9ByZA1qPF6paLxEAOw==""")
        
        # gif 16x16x16 : contrôle alphabétique
        self.img_chkspel= PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAADAAMD/wIAAgACAgICAgMDAwP8AAAD/AP//AAAA//8A/wDA
        wP///yH5BAEAAA0ALAAAAAAQABAAAAQ6sMlJq3TMNZYbZhUobpsWchtIToI0vqbwuCSnfbKl53rF
        96yZ5dcQDHYCXlI4XC6BxSSxJ2VCp1BoBAA7""")
        
        
        # /////////////////////////////////////////////
        # /// INTERFACE GRAPHIQUE DU WIDGET ///////////
        # /////////////////////////////////////////////
        
        
        r=0 # n° du rang
        
        # ================================
        # === Barre d'outils              
        # ================================
        
        self.pan_tool = Frame(self, borderwidth=2, relief="groove")
        self.pan_tool.grid(row=0, column=0, sticky='WES', ipady=3)
        
        self.bt_flexlist = Button(self.pan_tool, image=self.img_mkflex, borderwidth=1, relief=FLAT, command=self.exportListFlex)
        self.bt_flexlist.bind('<Enter>', self.enterButton)
        self.bt_flexlist.bind('<Leave>', self.leaveButton)
        self.bt_flexlist.pack(side=LEFT, padx=10)
        
        self.bt_traduc = Button(self.pan_tool, image=self.img_traduc, borderwidth=1, relief=FLAT, command=self.showTraduc)
        self.bt_traduc.bind('<Enter>', self.enterButton)
        self.bt_traduc.bind('<Leave>', self.leaveButton)
        self.bt_traduc.pack(side=LEFT, padx=10)
        
        self.bt_hlp=Button(self.pan_tool, image=self.img_hlp, borderwidth=1, relief=FLAT, command=self.showHelp)
        self.bt_hlp.bind('<Enter>', self.enterButton)
        self.bt_hlp.bind('<Leave>', self.leaveButton)
        self.bt_hlp.pack(side=LEFT, padx=10)
        
        self.lab_progr = Label(self.pan_tool, text="")
        self.lab_progr.pack(side=RIGHT, padx=3)
        
        r=1
        # --- pseudo-étiquette du mot brut
        self.lab_motBrut=Entry(self,text="", borderwidth=1, relief='solid', bg='black', fg='white')
        self.lab_motBrut.bind('<FocusIn>',self.IntercatifActivate)
        self.lab_motBrut.bind('<FocusOut>',self.IntercatifDeactivate)
        self.lab_motBrut.bind('<Return>',self.IntercatifDo)
        self.lab_motBrut.bind('<Enter>', self.seeCtx)
        self.lab_motBrut.bind('<Leave>', self.seeCtxNone)
        self.lab_motBrut.grid(row=r, column=0, padx=4, pady=4, ipadx=2, ipady=2, sticky="WE")
        
        # --- pseudo-étiquette d'info grammaticales
        self.lab_infoGram=Entry(self,text="", borderwidth=1, relief='solid', bg='black', fg='white')
        self.lab_infoGram.bind('<Enter>', self.seeCtx)
        self.lab_infoGram.bind('<Leave>', self.seeCtxNone)
        self.lab_infoGram.grid(row=r+1, column=0, padx=4, pady=2, ipadx=2, ipady=2, sticky="WE")
        
        
        # ================================
        # === Panneau de la déclinaison   
        # ================================
        
        self.pan_decl = Frame(self, borderwidth=0)
        self.pan_decl.grid(row=r+2, column=0, sticky='WENS')
        
        
        # --- Charger les étiquettes de légende
        
        r=0
        Label(self.pan_decl,text="Singul.", font=("Helvetica", 10, "bold")).grid(row=r, column=0, sticky="w")
        self.lab_MS = Label(self.pan_decl,text="Mascul.")
        self.lab_MS.grid(row=r, column=1)
        self.lab_FS = Label(self.pan_decl,text="Femin.")
        self.lab_FS.grid(row=r, column=2)
        self.lab_NS = Label(self.pan_decl,text="Neutr.")
        self.lab_NS.grid(row=r, column=3)
        r=7
        Label(self.pan_decl,text="Plur.", font=("Helvetica", 10, "bold")).grid(row=r, column=0, sticky="w")
        self.lab_MP = Label(self.pan_decl,text="Mascul.")
        self.lab_MP.grid(row=r, column=1)
        self.lab_FP = Label(self.pan_decl,text="Femin.")
        self.lab_FP.grid(row=r, column=2)
        self.lab_NP = Label(self.pan_decl,text="Neutr.")
        self.lab_NP.grid(row=r, column=3)
        r=1
        Label(self.pan_decl,text="Nom.").grid(row=r, column=0)
        Label(self.pan_decl,text="Voc.").grid(row=r+1, column=0)
        Label(self.pan_decl,text="Acc.").grid(row=r+2, column=0)
        Label(self.pan_decl,text="Gen.").grid(row=r+3, column=0)
        Label(self.pan_decl,text="Dat.").grid(row=r+4, column=0)
        Label(self.pan_decl,text="Abl.").grid(row=r+5, column=0)
        r=8
        Label(self.pan_decl,text="Nom.").grid(row=r, column=0)
        Label(self.pan_decl,text="Voc.").grid(row=r+1, column=0)
        Label(self.pan_decl,text="Acc.").grid(row=r+2, column=0)
        Label(self.pan_decl,text="Gen.").grid(row=r+3, column=0)
        Label(self.pan_decl,text="Dat.").grid(row=r+4, column=0)
        Label(self.pan_decl,text="Abl.").grid(row=r+5, column=0)
        
        
        # --- Charger les cases de texte
        
        for n in range(36):
            # Créer la case
            exec("self.txt_decl" + str(n) + "=Text(self.pan_decl, width=20, height=1, borderwidth=1, relief='solid', bg='white')")
            
            # Créér un style de tag pour la désinence
            exec("self.txt_decl" + str(n) +".tag_config('desinence', foreground='red')")
            
            # Placer la case
            r=1
            if n<6:           #Masculin singulier
                exec("self.txt_decl" + str(n) + ".grid(padx =1, pady =1, column=1,row=" + str(n+r) + ")")
            elif n<12:        #Masculin pluriel
                exec("self.txt_decl" + str(n) + ".grid(padx =1, pady =1, column=1, row=" + str(n+1+r) + ")")
            elif n<18:        #Féminin singulier
                exec("self.txt_decl" + str(n) + ".grid(padx =1, pady =1, column=2, row=" + str(n-12+r) + ")")
            elif n<24:        #Féminin pluriel
                exec("self.txt_decl" + str(n) + ".grid(padx =1, pady =1, column=2, row=" + str(n-11+r) + ")")
            elif n<30:        #Neutre singulier
                exec("self.txt_decl" + str(n) + ".grid(padx =1, pady =1, column=3, row=" + str(n-24+r) + ")")
            else:             #Neutre pluriel
                exec("self.txt_decl" + str(n) + ".grid(padx =1, pady =1, column=3, row=" + str(n-23+r) + ")")
          
            exec("self.txt_decl" + str(n) + "['font']=('courier',9,'normal')")
            exec("self.txt_decl" + str(n) + ".bind('<Enter>', self.seeCtx)")
            exec("self.txt_decl" + str(n) + ".bind('<Leave>', self.seeCtxNone)")
        
        
        
        # ================================
        # === Panneau de la conjugaison   
        # ================================
        
        self.pan_conj = Frame(self, borderwidth=0, pady=3)
        self.pan_conj.bind('<Enter>', self.ModeTempsValidate)
        self.pan_conj.grid(row=r+2, column=0, sticky='WENS')
        
        # --- Frame des options
        self.fr_opt = Frame(self.pan_conj, borderwidth=0)
        self.fr_opt.grid(row=0, sticky='WENS')
        
        Label(self.fr_opt, width=80).grid(row=0, column=0, columnspan=5, sticky='W')# dimensionneur
        
        # --- Liste d'Options des modes
        Label(self.fr_opt, text=self.__lgget("g", "s9"), anchor=E).grid(row=0, column=0, sticky=E) # Mode
        
        optionLst = (
            "1. " + self.__lgget("g", "s1"),
            "2. " + self.__lgget("g", "s2")
            ) # ("1. Indicatif", "2. Subjonctif/Conditionnel")
        self.vMode = StringVar(self.fr_opt)
        self.vMode.set(optionLst[0]) # Indicatif par défaut
        self.opt_mode = OptionMenu(self.fr_opt, self.vMode, *optionLst)
        self.opt_mode.bind('<Button-1>', self.ModeTempsOpen)
        self.opt_mode.grid(row=0, column=1, padx=3, pady=2)
        
        # --- Liste d'Options des temps
        Label(self.fr_opt, text='     ').grid(row=0, column=2)
        Label(self.fr_opt, text=self.__lgget("g", "s10"), anchor=E).grid(row=0, column=3, sticky=E) # Temps
        
        optionLst = (
            "1. " + self.__lgget("g", "s3"),
            "2. " + self.__lgget("g", "s4"),
            "3. " + self.__lgget("g", "s5"),
            "4. " + self.__lgget("g", "s6"),
            "5. " + self.__lgget("g", "s7"),
            "6. " + self.__lgget("g", "s8")
            ) # ("1. Present", "2. Imparfait", "3. Futur", "4. Parfait", "5. Plus-que-parfait", "6. Futur anterieur")
        self.vTemps = StringVar(self.pan_conj)
        self.vTemps.set(optionLst[0]) # Present par défaut
        self.opt_temps = OptionMenu(self.fr_opt, self.vTemps, *optionLst)
        self.opt_temps.bind('<Button-1>', self.ModeTempsOpen)
        self.opt_temps.grid(row=0, column=4, padx=3, pady=2)
        
        # --- Frame des conjugaisons
        self.fr_conj = Frame(self.pan_conj, borderwidth=0)
        self.fr_conj.grid(row=1, sticky='WENS')
        
        Label(self.fr_conj, width=80).grid(row=0, column=0, columnspan=3, sticky='W')# dimensionneur
        
        # --- Charger les étiquettes de légendes
        r=0
        Label(self.fr_conj,text=self.__lgget("g", "s11"), font=("Helvetica", 10, "bold")).grid(row=r, column=1) # Actif
        Label(self.fr_conj,text="            " + self.__lgget("g", "s12"), font=("Helvetica", 10, "bold")).grid(row=r, column=2, sticky='W') # Passif
        r=1
        Label(self.fr_conj,text=self.__lgget("g", "s13"), anchor=E).grid(row=r, column=0, sticky=E)     #  "1ère pers. sing."
        Label(self.fr_conj,text=self.__lgget("g", "s14"), anchor=E).grid(row=r+1, column=0, sticky=E)   #  "2ème pers. sing."
        Label(self.fr_conj,text=self.__lgget("g", "s15"), anchor=E).grid(row=r+2, column=0, sticky=E)   #  "3ème pers. sing."
        Label(self.fr_conj,text=self.__lgget("g", "s16"), anchor=E).grid(row=r+3, column=0, sticky=E)   #  "1ère pers. plur."
        Label(self.fr_conj,text=self.__lgget("g", "s17"), anchor=E).grid(row=r+4, column=0, sticky=E)   #  "2ème pers. plur."
        Label(self.fr_conj,text=self.__lgget("g", "s18"), anchor=E).grid(row=r+5, column=0, sticky=E)   #  "3ème pers. plur."
        
        
        # --- Charger les cases de texte
        for n in range(12):
            #créer la case
            exec("self.txt_conj" + str(n) + "=Text(self.fr_conj, width=20, height=1, borderwidth=1, relief='solid', bg='white')")
            
            #Créér un style de tag pour la désinence
            exec("self.txt_conj" + str(n) +".tag_config('desinence', foreground='red')")
            
            
            #placer la case
            r=1
            if n<6:           # Actif
                exec("self.txt_conj" + str(n) + ".grid(padx =1, pady =1, column=1,row=" + str(n+r) + ")")
            else:             # Passif
                exec("self.txt_conj" + str(n) + ".grid(padx =1, pady =1, column=2, row=" + str(n-6+r) + ", sticky='W')")
                
            exec("self.txt_conj" + str(n) + "['font']=('courier',9,'normal')")
        
        # --- Frame des notes (radicaux + exemples)
        self.fr_nb = Frame(self.pan_conj, borderwidth=0, pady=5)
        self.fr_nb.grid(row=2, sticky='WENS')
        
        Label(self.fr_nb, width=80).grid(row=0, column=0, columnspan=2, sticky='W')# dimensionneur
        
        # --- Frame des radicaux
        self.fr_radic=Frame(self.fr_nb, borderwidth=1, relief='solid')
        self.fr_radic.grid(row=0, column=0, padx=2, pady=4, sticky='ENS')
        
        Label(self.fr_radic, text=self.__lgget("g", "s19"), anchor='w').grid(row=0, column=0, sticky='W')   # INfinitif
        Label(self.fr_radic, text=self.__lgget("g", "s20"), anchor='w').grid(row=1, column=0, sticky='W')   # Radic présent
        Label(self.fr_radic, text=self.__lgget("g", "s21"), anchor='w').grid(row=2, column=0, sticky='W')   # Radic parfait
        Label(self.fr_radic, text=self.__lgget("g", "s22"), anchor='w').grid(row=3, column=0, sticky='W')   # Radic supin
        
        self.lab_Vinfinitif=Label(self.fr_radic,text="...")
        self.lab_Vinfinitif.grid(row=0, column=1, sticky='W', ipady=0, pady=0)
        self.lab_Vradic1=Label(self.fr_radic,text="...")
        self.lab_Vradic1.grid(row=1, column=1, sticky='W', ipady=0, pady=0)
        self.lab_Vradic2=Label(self.fr_radic,text="...")
        self.lab_Vradic2.grid(row=2, column=1, sticky='W', ipady=0, pady=0)
        self.lab_Vradic3=Label(self.fr_radic,text="...")
        self.lab_Vradic3.grid(row=3, column=1, sticky='W', ipady=0, pady=0)
        
        # --- Frame des exemples
        self.fr_exConj=Frame(self.fr_nb, borderwidth=1, relief='solid')
        self.fr_exConj.grid(row=0, column=1, padx=2, pady=4, sticky='WNS')
        
        self.lab_exConj=Label(self.fr_exConj, text="...", anchor='w', justify=LEFT)
        self.lab_exConj.grid(sticky='W')
        
        
        # ================================
        # === Panneau du traducteur       
        # ================================
        
        self.pan_trad = Frame(self, borderwidth=0)
        self.pan_trad.grid(row=r, rowspan=3, column=0, sticky='WENS')
        
        # Boutons
        Label(self.pan_trad, text=self.__lgget("g", "s23")).grid(row=0, column=0, sticky='W') # "Tapez ou collez ici le texte"
        self.bt_copy=Button(self.pan_trad, image=self.img_paste, borderwidth=1, relief=FLAT, command=self.copyToTransl)
        self.bt_copy.grid(row=0, column=1, pady=2)
        self.bt_copy.bind('<Enter>', self.enterButton)
        self.bt_copy.bind('<Leave>', self.leaveButton)
        self.bt_open=Button(self.pan_trad, image=self.img_open, borderwidth=1, relief=FLAT, command=self.openToTransl)
        self.bt_open.grid(row=0, column=2, pady=2)
        self.bt_open.bind('<Enter>', self.enterButton)
        self.bt_open.bind('<Leave>', self.leaveButton)
        self.bt_chk=Button(self.pan_trad, image=self.img_chkspel, borderwidth=1, relief=FLAT, command=self.checkSpelling)
        self.bt_chk.grid(row=0, column=3, pady=2)
        self.bt_chk.bind('<Enter>', self.enterButton)
        self.bt_chk.bind('<Leave>', self.leaveButton)
        
        self.txt_source=ScrolledText(self.pan_trad,width=70,height=10, wrap=WORD, background='white')
        self.txt_source['font']=("Helvetica", 9, "normal")
        self.txt_source.grid(row=2, column=0, columnspan=10)
        self.txt_source.bind("<Double-ButtonRelease-1>", self.dbClicOnWord)
        self.txt_source.bind('<Enter>', self.seeCtx)
        self.txt_source.bind('<Leave>', self.seeCtxNone)
        self.txt_source.tag_config("chknot", foreground="red")
        
        self.txt_match=ScrolledText(self.pan_trad, width=70, height=10, wrap=WORD, font=("Helvetica", 9, "normal"), background='#ffffee')
        self.txt_match.tag_config("trad", foreground='red', font=("Helvetica", 9, "bold"))
        self.txt_match.tag_config("cas", foreground='grey', font=("Helvetica", 8, "italic"))
        self.txt_match.grid(row=4, column=0, columnspan=10)
        self.txt_match.bind('<Enter>', self.seeCtx)
        self.txt_match.bind('<Leave>', self.seeCtxNone)
        
        
        self.pan_trad.grid_remove()
        
        
        # ================================
        # === Panneau d'info              
        # ================================
        
        self.pan_info = Frame(self, borderwidth=2, relief=GROOVE, padx=10)
        self.pan_info.grid(row=r+2, column=0, sticky='WENS')
        
        Label(self.pan_info, width=80, height=8).grid(row=0, column=0, sticky='W')# dimensionneur
        
        # --- Nom du Widget
        Label(self.pan_info, compound=LEFT, image=self.monImage, text="  DECLINATOR 2.1", font=("Helvetica", 13, "bold")).grid(row=0, column=0, pady=20)
        
        # --- Etiquette d'info
        self.lab_infoFailure = Label(self.pan_info, background="yellow", text=self.__lgget("g", "s24"), pady=5, padx=5)
        self.lab_infoFailure.grid(row=1, column=0, pady=20)
        
        
        # ==================================
        # === Panneau contextuel (en bas)   
        # ==================================
        
        self.pan_ctx = Frame(self, borderwidth=2, relief='sunken', background='black')
        self.pan_ctx.grid(row=r+3, column=0, pady=6, sticky='WENS')
        
        Label(self.pan_ctx, image=self.img_info, background='black').grid(row=0, column=0, sticky='WN')
        
        Label(self.pan_ctx, width=80, height=2, bg='black').grid(row=0, column=1, ipady=3, sticky='W')# dimensionneur
        
        self.lab_ctx = Label(self.pan_ctx, text=self.__lgget("g", "s25"), width=68, anchor='w', justify=LEFT, foreground='white', background='black', font=("Helvetica", 9, "normal"))
        self.lab_ctx.grid(row=0, column=1, sticky='W')
        
        self.seeCtxNone(None) # affiche l'info par défaut
        
        return


    def openToTransl(self):
        u"""
        Ouvrir un fichier texte latin à traduire,
        et coller son contenu dans la case du texte source
        """
        
        fichpath = tkFileDialog.askopenfilename(parent=self,
                                title = self.__lgget("g", "msg1"),
                                filetypes=(
                                (self.__lgget("g", "ftxt"),'*.txt'),
                                (self.__lgget("g", "fall"),'*.*'))
                                )
            
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        ff = open(fichpath,"rU")
        t = ff.read()
        ff.close()
        
        try:
            t = t.decode('cp1252')
        except:
            pass
        
        self.txt_source.delete("1.0", END)
        self.txt_source.insert(END, t)
        
        
        return


    def copyToTransl(self):
        u"""
        Copie le contenu du presse-papier dans le panneau de traduction,
        (remplace la sélection dans la case du texte source)
        """
        
        try:    self.txt_source.delete(SEL_FIRST, SEL_LAST)
        except: pass
        self.txt_source.insert(INSERT, self.clipboard_get())
            
        return



    def checkSpelling(self):
        u"""
        Controle orthographique et traduction compléte du texte latin
        """
        
        self['cursor']="watch"
        self.update()
        
        absindex = self.txt_source.index
        
        # Supprimer les tags si présents
        self.txt_source.tag_remove("chknot", "1.0", END)
        
        
        # scanner le texte du widget, mot par mot
        p1 = "1.0"
        p2 = absindex("1.0wordend")
        
        self.txt_match.delete("0.0", END)
        
        while 1:
            
            mot = self.txt_source.get(p1, p2)
             
            # "æ" et "œ" dans un mot arrète 'wordend' (bogue Tk) : ajouter la suite du mot                
            if self.txt_source.get(p2) in ( u'\xe6', u'\u0153') :
                
                p2 = absindex(absindex(p2 + "+1c") + "wordend")
                mot = self.txt_source.get(p1, p2)
                
                # si ce décalage absorbe un trait d'union > revenir en arrière
                if mot.endswith("-"):
                    p2 = absindex(p2 + "-1c")
                    mot = self.txt_source.get(p1, p2)
            
            if len(mot) > 1:
                ret = self.translateWord(wd=mot, flagdisplay=True, flagcumul=True)
                #print lib.mytools.unlig(mot) + " > " + str(ret) # (ligne de débogage)
                if ret < 1:
                    self.txt_source.tag_add("chknot", p1, p2)
            
            # ---
            p1 = absindex(p2)
            p2 = absindex(p1 + "wordend")
            
            # --- fin du texte atteinte
            if p2 == absindex(END):
                break 
        
        self['cursor']=""
        
        return

    
    def dbClicOnWord(self, event):
        u"""
        Double-Clic sur un mot latin à traduire
        > affiche les correspondances
        """
        
        self['cursor']="watch"
        self.update()
        
        
        # ----------------------------------------------
        # --- Extraire le mot double-cliqué (= motif)   
        # ----------------------------------------------
        try:
            wd = self.txt_source.get(SEL_FIRST, SEL_LAST)
        except:
            self['cursor']=""
            return
        
        
        self.translateWord(wd=wd, flagdisplay=True)
        
        # --------------
        
        self['cursor']=""
        
        return
    
    

    def translateWord(self, wd, flagdisplay, flagcumul=False):
        u"""
        Traduire le mot wd
        Retourne :  1 = correspondance parfaite
                    0 = correspondance partielle ou absente
        
        Affichage si flagdisplay est True
        L'affichage remplace le précédent si flaccumul est False
        """
        
        listflexpath = os.path.join(self.getAppDataPath(), "declinator_listflex")
        
        
        # --- Liste des correspondances des abréviations utilisées dans la liste des flexions
        
        caspers = self.__lgget("g", "caspers") # (pyDictionnaire) 
        
        
        # ----------------------------------
        # --- Formattage du mot à traduire  
        # ----------------------------------
        
        wd = wd.lower().strip(" ,;:!?.()[]{}'\"")
        
        # Extraction des composants des mots composés
        # on place le mot ou ses composants dans une liste
        
        motifs = wd.split("-")
        
        if len(motifs) >1 :     # Mot composé
            motifs[0] = lib.mytools.unlig(motifs[0]) + "-|"    # motif préfixe
            for n in range(1, len(motifs)):                    # motifs suffixes
                motifs[n] = "-" + lib.mytools.unlig(motifs[n]) # on défait les ligatures
                motifs[n] += "|"                               # on ajoute un pipe final (syntaxe liste des flexions)
        else:                   # Mot simple
            motifs[0] = lib.mytools.unlig(motifs[0]) + "|" 
        
        
        # --- Vider la case de la liste des correspondances
        
        if flagdisplay and not flagcumul:
            self.txt_match.delete(1.0, END)
        
        
        # ===================================================
        # === Boucle de parcours des motifs                  
        # ===================================================
        
        ff = open(listflexpath,"rU")   # ouvrir la liste des flexions
        
        retour = 1
        
        for motif in motifs: 
        
            
            # ------------------------------------------
            # --- Chercher la flexion correspondante    
            # ------------------------------------------
            
            ff.seek(0)
            
            flagque = False                     # flag de gestion du "que" postposé
            flagve = False                      # flag de gestion du "ve" postposé
            flagsub = False                     # flag de gestion du "sub" préposé
            flagsemi = False                    # flag de gestion du "semi" préposé
            flaghemi = False                    # flag de gestion du "hemi" préposé
            
            while 1:    # Boucle permettant de reprendre la recherche après éventuelle modification du motif
                
                # Boucle de recherche du motif dans la liste des flexions
                flagtrouve = False
                for ligne in ff:
                    if ligne.startswith(motif):
                        flagtrouve = True       # Trouvé ! on quitte la boucle
                        break
                
                
                # Rien n'a été trouvé : que faire ?
                if not flagtrouve :
                    
                    if motif.endswith("que|"):
                        motif = motif[:-4] + "|" # on supprime le 'que' et on recommence la recherche
                        flagque = True
                        ff.seek(0)
                    elif motif.endswith("ve|"):
                        motif = motif[:-3] + "|" # on supprime le 've' et on recommence la recherche
                        flagve = True
                        ff.seek(0)
                    elif motif.endswith("-|"):
                        motif = motif[:-2] + "|" # on supprime le '-' et on recommence la recherche
                        ff.seek(0)
                    elif motif.startswith("sub"):
                        motif = motif[3:]       # on supprime le "sub" et on recommence la recherche
                        flagsub = True
                        ff.seek(0)
                    elif motif.startswith("semi"):
                        motif = motif[4:]       # on supprime le "semi" et on recommence la recherche
                        flagsemi = True
                        ff.seek(0)
                    elif motif.startswith("hemi"):
                        motif = motif[4:]       # on supprime le "hemi" et on recommence la recherche
                        flaghemi = True
                        ff.seek(0)
                    elif motif.startswith("-"):
                        motif = motif[1:]        # on supprime le '-' et on recommence la recherche
                        ff.seek(0)
                    else:
                        if flagdisplay:
                            self.txt_match.insert(END, motif + " " + self.__lgget("g", "s49") + "\n\n")
                        ligne = ""
                        retour = 0
                        break   # on quitte la boucle while
                
                # Le motif a été trouvé, on quitte la boucle while
                else:
                    break
            
            
            # -------------------------------------------------------------------
            # --- Compléter la liste des correspondances (affichage résultats)   
            # -------------------------------------------------------------------
            
            if flagdisplay:
                
                if flagsub:     # un "sub" est préposé
                    self.txt_match.insert(END, "sub-... " + self.__lgget("g", "s51") + "\n")
                    self.txt_match.insert(END, " "*6 + self.__lgget("g", "s54") + "\n\n", "trad")
                elif flagsemi:  # un "semi" est préposé
                    self.txt_match.insert(END, "semi-... " + self.__lgget("g", "s51") + "\n")
                    self.txt_match.insert(END, " "*6 + self.__lgget("g", "s55") + "\n\n", "trad")
                elif flaghemi:  # un "hemi" est préposé
                    self.txt_match.insert(END, "hemi-... " + self.__lgget("g", "s51") + "\n")
                    self.txt_match.insert(END, " "*6 + self.__lgget("g", "s55") + "\n\n", "trad")
                
                
                words = ligne.split("|")[1:]
                
                wc = 1
                for word in words:
                    idx = int(word.split(":")[0])          # index du mot
                    cass = word.split(":")[1].split("-")   # liste des cas/genre ou mode/temps/personnes
                    
                    data = self.getdata(idx)
                    
                    if len(words) > 1:
                        num = str(wc) + ") "
                        wc += 1
                    else:
                        num = ""
                    
                    self.txt_match.insert(END, num + data['mot'] + "\n")
                    self.txt_match.insert(END, " "*6 + data['short'] + "\n", "trad")
                    
                    for cas in cass:
                        t = ""
                        for c in cas: # Scanner les caractères/tokens pour les transcrire en clair
                            try:
                                t += caspers[c] + " "
                            except:
                                t += c + " "
                        
                        self.txt_match.insert(END, " "*8 + " - " + t + "\n", "cas")
                
                if flagque:     # un "que" est postposé
                    self.txt_match.insert(END, '"...-que" ' + self.__lgget("g", "s50") + "\n")
                    self.txt_match.insert(END, " "*6 + self.__lgget("g", "s52") + "\n\n", "trad")
                elif flagve:    # un "ve" est postposé
                    self.txt_match.insert(END, '"...-ve" ' + self.__lgget("g", "s50") + "\n")
                    self.txt_match.insert(END, " "*6 + self.__lgget("g", "s53") + "\n\n", "trad")
        
        
        # === (fin de la boucle de parcours des motifs) ===
        
        ff.close()
        
        return retour


    def showTraduc(self):
        u"""
        - Affiche le panneau du traducteur de latin
        - Crée une liste de flexion si absente ou obsolète
        """
        
        listflexpath = os.path.join(self.getAppDataPath(), "declinator_listflex")
        
        
        # -------------------------------------------------------
        # --- Vérifier que le dico est ouvert                    
        # --------------------------------------------------------
        
        flagdico = True
        
        if self.getfile is None:
            flagdico = False
        elif self.getfile() is None:
            flagdico = False
        
        if not flagdico:
            tkMessageBox.showwarning(parent=self,
                    title = self.__lgget("g", "msg2"),
                    message = self.__lgget("g", "msg3") )
            return
        
        # --- OK
        self.pan_trad.grid()
        self.pan_info.grid_remove()
        self.pan_conj.grid_remove()
        
        self.update()
        
        
        # --------------------------------------------------------
        # --- Contrôler la mise à jour de la liste des flexions   
        # --------------------------------------------------------
        
        isobsolete = True
        
        if os.path.isfile(listflexpath): # Une liste de flexions existe
            
            # md5 du fichier du dico courant
            dicfile = self.getfile()
            dicfile.seek(0)
            md5dico = hashlib.md5(dicfile.read()).hexdigest()
            #md5dico = md5.md5(dicfile.read()).hexdigest()
            
            # md5 du dico ayant servit à confectionner la liste de flexions
            #(sa valeur est inscrite dans la première ligne de la liste)
            lstfile = open(listflexpath, 'rU')
            md5lst = lstfile.readline().strip("\r\n")
            lstfile.close()
            
            # Comparer les md5
            if md5dico == md5lst:
                isobsolete = False
            
            
        if isobsolete: # La liste est obsolète, inexistante ou ne correspond pas au dico utilisé
            
            # Fenêtre de message d'attente
            wmsg = Toplevel(self, padx=15, pady=10)
            wmsg.title(self.__lgget("g", "msg2"))
            
            Label(wmsg,text="\n" + self.__lgget("g", "s26") + "\n", font=("Helvetica",9,"bold")).pack()
            
            self.buildListFlex() # Reconstruire la liste des flexions
            
            wmsg.destroy()
        
        return



    def enterButton(self, event):
        u"""
        Survol d'un boutton de la barre d'outil (entrée de la souris)
        """
        
        event.widget['relief'] = RAISED
        self.seeCtx(event)
        
        return

    def leaveButton(self, event):
        u"""
        Survol d'un boutton de la barre d'outil (sortie de la souris)
        """
        
        event.widget['relief'] = FLAT
        self.seeCtxNone(event)
        
        return

    def ModeTempsOpen(self, event):
        u"""
        Suite à Clic sur un bouton d'option Mode/Temps
        - Mise de 'flagChangeModeTemps' à True
        """
        self.flagChangeModeTemps = True
        return

    def ModeTempsValidate(self, event):
        u"""
        - Mise à jour de la conjugaison avec le nouveau Mode/temps
        - Mise de 'flagChangeModeTemps' à False
        """
        
        if self.flagChangeModeTemps:
            self.flagChangeModeTemps = False
            self.opt_mode.update()
            self.opt_temps.update()
            
            # Mettre à jour la conjugaison dans l'objet
            m = self.vMode.get()[0]
            if   m == "1": m = 'indicatif'
            elif m == "2": m = 'subjonctif/conditionnel'
            
            t = self.vTemps.get()[0]
            if   t == "1": t = 'present'
            elif t == "2": t = 'imparfait'
            elif t == "3": t = 'futur'
            elif t == "4": t = 'parfait'
            elif t == "5": t = 'plus-que-parfait'
            elif t == "6": t = 'futur anterieur'
            
            self.oLatin.ConjUpdate(m, t)
            
            # Afficher les données dans les cases
            self.AfficherVerbe()
        
        return

    def IntercatifActivate(self,event):
        u"""
        La souris passe sur la case d'entrée du mot latin
        """
        self.lab_motBrut["bg"]= 'white'
        self.lab_motBrut["fg"]= 'black'
        return

    def IntercatifDeactivate(self,event):
        u"""
        La souris quitte la case d'entrée du mot latin
        """
        self.lab_motBrut["bg"]= 'black'
        self.lab_motBrut["fg"]= 'white'
        return

    def IntercatifDo(self, event):
        u"""
        Valider une entrée en mode interactif
        """
        self.display(self.lab_motBrut.get())
        return

  
    def seeCtx(self, event):
        """
        Affichage de l'info contextuelle
        en fonction de l'id du widget survolé par la souris
        """
        
        idw = id(event.widget) # ID du widget survolé
        
        # --- Cases de déclinaison
        if idw in [id(eval("self.txt_decl" + str(i) ) )  for i in range(0,31,6) ]:
            self.lab_ctx['text'] = self.__lgget("g", "s27")
        elif idw in [id(eval("self.txt_decl" + str(i) ) )  for i in range(1,32,6) ]:
            self.lab_ctx['text'] = self.__lgget("g", "s28")
        elif idw in [id(eval("self.txt_decl" + str(i) ) )  for i in range(2,33,6) ]:
            self.lab_ctx['text'] = self.__lgget("g", "s29")
        elif idw in [id(eval("self.txt_decl" + str(i) ) )  for i in range(3,34,6) ]:
            self.lab_ctx['text'] = self.__lgget("g", "s30")
        elif idw in [id(eval("self.txt_decl" + str(i) ) )  for i in range(4,35,6) ]:
            self.lab_ctx['text'] = self.__lgget("g", "s31")
        elif idw in [id(eval("self.txt_decl" + str(i) ) )  for i in range(5,36,6) ]:
            self.lab_ctx['text'] = self.__lgget("g", "s32")  
        # ---
        
        elif idw == id(self.lab_motBrut):
            self.lab_ctx['text'] = self.__lgget("g", "s33")
          
        elif idw == id(self.lab_infoGram):
            self.lab_ctx['text'] = self.__lgget("g", "s34")
      
        elif idw == id(self.bt_hlp):
            self.lab_ctx['text'] = self.__lgget("g", "s35")
          
        elif idw == id(self.bt_flexlist):
            self.lab_ctx['text'] = self.__lgget("g", "s36")
        
        elif idw == id(self.bt_traduc):
            self.lab_ctx['text'] = self.__lgget("g", "s37")
        
        elif idw == id(self.bt_copy):
            self.lab_ctx['text'] = self.__lgget("g", "s38")
        
        elif idw == id(self.bt_chk):
            self.lab_ctx['text'] = self.__lgget("g", "s39")
        
        elif idw == id(self.bt_open):
            self.lab_ctx['text'] = self.__lgget("g", "s40")
        
        elif idw == id(self.txt_source):
            self.lab_ctx['text'] = self.__lgget("g", "s41")
        
        elif idw == id(self.txt_match):
            self.lab_ctx['text'] = self.__lgget("g", "s42")
        
        return


    def seeCtxNone(self,event):
        self.lab_ctx['text']= self.__lgget("g", "s43")
       
       


    def getTitle(self):
        u"""
        Retourne le titre du greffon (pour utilisation dans le programme-hôte)
        """
        
        return self.title


    def showHelp(self):
        u"""
        Affiche la fenêtre d'aide
        """
        
        self.f_hlp = Toplevel(self)
        self.f_hlp.title(self.__lgget("g", "s44"))
        
        self.txt_hlp = ScrolledText(self.f_hlp, width=130, height=50)
        self.txt_hlp.tag_config("normal", wrap=WORD, foreground="black", background="white", lmargin1=5, lmargin2=5, spacing1=5) 
        
        #fichpath = os.path.join(os.path.abspath(os.path.dirname(__file__)),"declinator.txt")
        #f = open(fichpath,'rU')# Fichier texte
        #lignes = f.readlines()  
        #f.close()
        
        #for ligne in lignes:
        #    try:
        #        ligne = ligne.decode('cp1252')
        #    except:
        #        pass
        #    self.txt_hlp.insert(END, ligne + "\n", "normal")
        
        self.txt_hlp.insert(END, """
Le Widget DECLINATOR pour Python
=================================


Sommaire :

  1. FORMAT DES ENTREES DE DICTIONNAIRE
  2. CODAGE GRAMMATICAL
  3. UTILISATION DU WIDGET DANS UN PROGRAMME PYTHON

 
 
1. FORMAT DES ENTREES DE DICTIONNAIRE
--------------------------------------

Pour être déclinées/conjuguées par Declinator, les entrées du dictionnaire doivent :

  - être munies d'un code grammatical entre crochets
  - avoir leurs désinences séparées par des barres obliques
  
    exemple : rosa/ae [s f 1]

Declinator tentera néanmoins d'analyser tout mot démuni de code grammatical mais avec nécessairement un risque supérieur d'échec ou de résultat incorrect




2. CODAGE GRAMMATICAL
----------------------

 [abr]		abréviation
 [adj]		adjectif ou participe
 [adv]		adverbe
 [cmp]		comparatif
 [conj]		conjonction
 [num]		numéral
 [prf]		préfixe ou racine préfixée
 [prf-L]	préf./rac. de composé Latin
 [prf-G]	préf./rac. de composé Grec
 [prep]		préposition
 [dem]		démonstratif (pronom-adjectif)
 [rel]      relatif (pronom adjectif)
 [s]		substantif
 [s-adj]	substantif utilisé adjectivement
 [s m]		substantif masculin
 [s f]		substantif féminin
 [s n]		substantif neutre
 [suf]		suffixe ou racine suffixée
 [suf-L]	suf./rac. de composé Latin
 [suf-G]	suf./rac. de composé Grec
 [sup]		superlatif
 [v...]		verbe ( ... = type de conjug., voir plus bas)
 [v... t]	verbe transitif
 [v... i]	verbe intransitif
 [sg]		employé uniquement au singulier
 [pl]		employé uniquement au pluriel
 [indecl]	indéclinable

-----------------------------------------------------------------------

 [s 1]		1ERE DECLINAISON (/æ)

 [s 1]		subst. en -a/æ
 [s 1e]		subst. en -e/es
 [s 1ae]	subst. en -a/æ et abl. parfois en e

-----------------------------------------------------------------------

 [s 2]		2EME DECLINAISON (/i)

 [s m 2][s f 2]	subst. masc. & fem. en -us/i
 [s n 2]	subst. neutre en -um/i
 [s 2r1]	subst. en -er/...ri
 [s 2r2]	subst. en -er/eri
 [s 2on]	subst. en -on/i

-----------------------------------------------------------------------

 [s 3]		3EME DECLINAISON (/is)

 [s m 3p][s f 3p]  parisyllabiques m&f en -is/is et -es/is
 [s f 3pg]	   parisyllabiques fem. à déclinaison grécisante
 [s n 3p]	   parisyllabiques neutres en -e/is

 [s 3a]		imparisyl. en -a/atis
 [s 3ar]	imparisyl. en -ar/aris
 [s 3as]	imparisyl. en -as/atis
 [s 3ax]	imparisyl. en -ax/acis & -x/cis
 [s 3en]	imparisyl. en -en/inis
 [s 3er1]	imparisyl. en -er/eris (nomin. pl. en -era)
 [s 3er2]	imparisyl. en -er/eris (nomin. pl. en -eres)
 [s 3es1]	imparisyl. en -es/etis & -es/edis
 [s 3es2]	imparisyl. en -es/itis
 [s 3ex]	imparisyl. en -ex/icis
 [s 3is]	imparisyl. en -is/idis
 [s 3isg]	imparisyl. en -is/idis à déclinaison grécisante
 [s 3ix]	imparisyl. en -ix/icis, -yx/ycis & ux/ucis
 [s 3ns1]	imparisyl. en -ns/...ntis
 [s 3ns2]	imparisyl. en -ns/...ndis
 [s 3o1]	imparisyl. en -o/onis
 [s 3o2]	imparisyl. en -o/inis
 [s 3on]	imparisyl. en -on/onis
 [s 3or]	imparisyl. en -or/oris
 [s 3os]	imparisyl. en -os/oris
 [s 3s]		imparisyl. en -s/tis
 [s 3us1]	imparisyl. en -us/eris
 [s 3us2]	imparisyl. en -us/oris
 [s 3-] ...	(divers)

-----------------------------------------------------------------------

 [s 4]		4EME DECLINAISON (/us)

 [s m 4][s f 4]	subst. masc. & fem. en -us/us
 [s n 4]	subst. neutre en -u/ua
 [s 4a]		subst. en -us/us à Dat. et Abl. pl en -ubus

-----------------------------------------------------------------------

 [s 5]		5EME DECLINAISON (/ei)

 [s 5] 		subst. en -es/ei

-----------------------------------------------------------------------

 [adj A]	ADJECTIFS du GROUPE A

 [adj A]	adj en -us/a/um
 [adj Aa]	adj en -er/era/erum
 [adj Ab]	adj en -...er/...ra/...rum

-----------------------------------------------------------------------

 [adj B]	ADJECTIFS du GROUPE B

 [adj Bp]	adj parisyllabiques en -is/is/e
 [adj Ber]	adj parisyllabiques en -er/is/e
 [adj Bns]	adj imparisyl. en -ns/...ntis
 [adj Bex]	adj imparisyl. en -ex/icis
 [adj Bx]	adj imparisyl. en -ax/acis & -ox/ocis
 [adj Bor]	adj imparisyl. en -or/oris
 [adj Bus]	adj imparisyl. en -us/eris
 [adj B-]	(adj imparisyl. divers non encore gérés)

 [adj C] -oides & -odes	 ADJECTIFS du GROUPE "C" (rattaché au groupe B)

 [adj Ci]	adj en -oides/oidis
 [adj Co]	adj en -odes/odis

-----------------------------------------------------------------------

 [cmp]		ADJECTIFS AU COMPARATIF DE SUPERIORITE

 [cmp]		-ior/ior/ius (... quam)

 [cmp-i]	comparatif régulier à génitif pluriel en -ium (type plures)

-----------------------------------------------------------------------

 [num]		NUMERAUX

 [num1]		unus et dérivés, unus/a/um
 [num2]		duo et dérivés, duo/duæ/duo
 [num3]		tres et dérivés, tres/tres/tria

-----------------------------------------------------------------------

 [v1]		1ère CONJUGAISON

 [v1]		-o/as/are/avi/atum	

-----------------------------------------------------------------------

 [v2]		2ème CONJUGAISON

 [v2]		-eo/es/ere/...i/...um

-----------------------------------------------------------------------

 [v3]		3ème CONJUGAISON

 [v3]		-o/is/ere/...i/...um

-----------------------------------------------------------------------

 [v4]		4ème CONJUGAISON

 [v4]		-io/is/ire/...i/...um

-----------------------------------------------------------------------

 [vm]		CONJUGAISON MIXTE

 [vm]		-io/is/ere/...i/...um

-----------------------------------------------------------------------

 [vs]		(sum/esse et dérivés)

 [vs]		-sum/es/esse/fui/-

-----------------------------------------------------------------------

 [vf]		(fero/ferre et dérivés)

 [vf]		-fero/fers/ferre/tuli/latum





3. UTILISATION DE DECLINATOR DANS UN PROGRAMME PYTHON
----------------------------------------------------

Declinator est un widget basé sur TKinter (bibliothèque graphique fournie en standard avec Python). Declinator peut également être utilisé sans son interface graphique comme un module Python ordinaire.

Fichier :
  declinator.py (le module Python)


3.1 Utilisation de Declinator en tant que widget :
  
  import declinator_widget
  
  # Intancier/afficher le widget dans l'interface du programme-hôte
  
  wD = declinator.Widget()
  wD.pack()
  
  # On peut ensuite afficher dans le widget
  # ('motBrut' est une entrée de dictionnaire correctement formatée)
  
  wD.Display(motBrut)
  


3.2 Utilisation de Declinator sans interface graphique :
 

  import declinator
  
  # on instancie la classe cl_LatinWord

  monMotLatin = declinator.cl_LatinWord(motBrut)
  
  # on récupère alors deux listes, Déclinaison et Conjugaison,
  # dans lesquelles les radicaux sont séparés des désinences
  
  monMotlatin.Decl[i].Rac # contient la racine (ex. : 'ros')
  monMotlatin.Decl[i].Des # contient la désinence (ex. : 'a')



Cartographie des index de la liste Decl (0-35) :

  (0-5) : Masculin singulier
	0 : Nominatif
	1 : Vocatif
	2 : Accusatif
	3 : Génitif
	4 : Datif
	5 : Ablatif

  (6-11) : Masculin pluriel
	6 : Nominatif
	7 : Vocatif
	8 : Accusatif
	9 : Génitif
	10 : Datif
	11 : Ablatif

  (12-17) : Féminin singulier
	12 : Nominatif
	13 : Vocatif
	14 : Accusatif
	15 : Génitif
	16 : Datif
	17 : Ablatif

  (18-23) : Féminin pluriel
	18 : Nominatif
	19 : Vocatif
	20 : Accusatif
	21 : Génitif
	22 : Datif
	23 : Ablatif

  (24-29) : Neutre singulier
	24 : Nominatif
	25 : Vocatif
	26 : Accusatif
	27 : Génitif
	28 : Datif
	29 : Ablatif

  (30-35) : Neutre pluriel
	30 : Nominatif
	31 : Vocatif
	32 : Accusatif
	33 : Génitif
	34 : Datif
	35 : Ablatif


Cartographie des index de la liste Conj (0-11) :

  (0-5) : Voix active
	0 : 1ère personne du singulier
	1 : 2ème personne du singulier
	2 : 3ème personne du singulier
	3 : 1ère personne du pluriel
	4 : 2ème personne du pluriel
	5 : 3ème personne du pluriel

  (6-11) : Voix passive
	6 : 1ère personne du singulier
	7 : 2ème personne du singulier
	8 : 3ème personne du singulier
	9 : 1ère personne du pluriel
	10 : 2ème personne du pluriel
	11 : 3ème personne du pluriel

L'instanciation de la classe génère une conjugaison à l'indicatif présent, pour générer ensuite d'autres modes et temps il faut appliquer à l'instance la méthode ConjUpdate(mode, temps) puis relire la liste Conj.

___



        """, "normal")
        
        
        
        
        self.txt_hlp.grid(row=0, column=0, sticky='WENS')
        
        return



    def display(self, motBrut):
        u"""
        1) Charge le mot brut dans un objet "Mot Latin Declinator"
        2) Récupère les données fournies en retour par celui-ci dans ses propriétés (attributs et pylistes)
        3) Affiche les données de retour dans l'interface du widget
        """
        
        
        i = 0
        tBox=""
        
        # ------------------------------------------------
        # --- Instancier l'objet "Mot décliné/conjugué"   
        # ------------------------------------------------
        
        self.oLatin = cl_LatinWord(motBrut)
        
        # --- Afficher le mot brut dans la case du widget
        self.lab_motBrut.delete(0, END)
        self.lab_motBrut.insert(0, motBrut)
        
        # --- Afficher les infos grammaticales conviviales
        self.lab_infoGram.delete(0, END)
        self.lab_infoGram.insert(0, self.oLatin.GramInfo)
        
        
        
        # ==========================================================================
        if self.oLatin.isDeclined:       # le mot a été effectivement décliné       
        # ==========================================================================
            
            # --- Afficher le panneau correspondant
            
            self.pan_info.grid_remove()
            self.pan_conj.grid_remove()
            self.pan_trad.grid_remove()
              
            # ----------------------------------------
            # --- Affichage des étiquettes de genre   
            # ----------------------------------------
            
            if self.oLatin.isMasculine:  # --- Masculin
                
                if self.oLatin.isSingular:   # singulier
                    self.lab_MS.grid()
                else:
                    self.lab_MS.grid_remove()
                
                
                if self.oLatin.isPlural:     #pluriel
                    self.lab_MP.grid()
                else:
                    self.lab_MP.grid_remove()
            
            else:
                
                self.lab_MS.grid_remove()
                self.lab_MP.grid_remove()
            
            
            
            if self.oLatin.isFeminine:   # --- Féminin
                
                if self.oLatin.isSingular:   #singulier
                    self.lab_FS.grid()
                else:
                    self.lab_FS.grid_remove()
                
                
                if self.oLatin.isPlural:     #pluriel
                    self.lab_FP.grid()
                else:
                    self.lab_FP.grid_remove()
            
            
            else:
                
                self.lab_FS.grid_remove()
                self.lab_FP.grid_remove()
            
            
            
            if self.oLatin.isNeutral:    # --- Neutre
                
                if self.oLatin.isSingular:
                    self.lab_NS.grid()
                else:
                    self.lab_NS.grid_remove()
                
                
                if self.oLatin.isPlural:
                    self.lab_NP.grid()
                else:
                    self.lab_NP.grid_remove()
            
            
            else:
                
                self.lab_NS.grid_remove()
                self.lab_NP.grid_remove()
            
            
            
            
            
            # ---------------------------------------------------
            # --- Remplissage des cellules de déclinaison        
            # ---------------------------------------------------
            
            for i in range(36): # (0 To 35)
                
                tBox = "self.txt_decl" + str(i) # nom de la richTextBox
                
                # effacer contenu antérieur
                exec(tBox +".delete(1.0, END)")
                
                if self.oLatin.Decl[i].Rac <> "":
                
                    # Insérer le texte dans la richTextBox
                    exec(tBox +".insert(END,self.oLatin.Decl[" + str(i) + "].Rac)")
                    exec(tBox +".insert(END, self.oLatin.Decl[" + str(i) + "].Des, 'desinence')")
                    
                    exec(tBox +"['bg']='white'")
                
                else:
                    exec(tBox +"['bg']=self['bg']") # griser la case vide
        
        
        
        
        # =============================================================================
        elif self.oLatin.isConjugated:     # === Le mot a été effectivement conjugué   
        # =============================================================================
            
            # --- Afficher le panneau correspondant
            self.pan_info.grid_remove()
            self.pan_conj.grid()
            self.pan_trad.grid_remove()
            
            # Réinitialiser les boutons d'options
            self.vMode.set("1. " + self.__lgget("g", "s1"))       # Indicatif par défaut
            self.vTemps.set("1. " + self.__lgget("g", "s3"))      # Present par défaut
            
            # --- Remplir le panneau
            self.AfficherVerbe()
        
        
        
        # ==============================================================
        else: # === Pas de décinaison ni conjugaison effective          
        # ==============================================================
            
            # --- Afficher le panneau correspondant
            
            self.pan_conj.grid_remove()
            self.pan_info.grid()
            self.pan_trad.grid_remove()
            
            # --- Message
            if motBrut == "":
                self.lab_infoFailure["text"] = self.__lgget("g", "s45") # "(sélectionnez ou tapez un mot)"
            elif self.oLatin.isDeclNone:
                self.lab_infoFailure["text"] = self.__lgget("g", "s46") # "(cette expression n'est pas déclinable/conjugable)"
            elif self.oLatin.isDeclUnknown:
                self.lab_infoFailure["text"] = self.__lgget("g", "s47") # "(la déclinaison/conjugaison de cette expression n'est pas affichable)"
            else:
                self.lab_infoFailure["text"] = self.__lgget("g", "s48") # "(impossible d'afficher une déclinaison/conjugaison)"
        
        
        
        self.update()
        
        return


    def AfficherVerbe(self):
        u"""
        Affiche les données de verbe de l'objet dans les cases ad hoc
        """
        
        tBox = ""
        t = ""
        
        
        # -------------------------------------------------------
        # --- Remplissage des cellules de conjugaison            
        # -------------------------------------------------------
        
        for i in range(12):
            
            tBox = "self.txt_conj" + str(i)
                
            # effacer contenu antérieur
            exec(tBox +".delete(1.0, END)")
            
            if self.oLatin.Conj[i].Des <> "":
                
                # Insérer le texte dans la richTextBox
                exec(tBox +".insert(END,self.oLatin.Conj[" + str(i) + "].Rac)")
                exec(tBox +".insert(END, self.oLatin.Conj[" + str(i) + "].Des, 'desinence')")
                
                exec(tBox +"['bg']='white'")
            
            else:
                
                exec(tBox +"['bg']=self['bg']") # griser la case vide
        
        
        # ----------------------------------------------------------------
        # --- remplissage de la case des étiquettes des radicaux du verbe 
        # ----------------------------------------------------------------
        
        self.lab_Vinfinitif["text"] = self.oLatin.Vinfinitif
        self.lab_Vradic1["text"] = self.oLatin.Vradic1 + "-"
        self.lab_Vradic2["text"] = self.oLatin.Vradic2 + "-"
        self.lab_Vradic3["text"] = self.oLatin.Vradic3 + "-"
        
        
        # ---------------------------------------------
        # --- Affichage de la case de l'exemple        
        # ---------------------------------------------
        
        mode = self.vMode.get()[0]
        temps = self.vTemps.get()[0]
        
        t = "Exemple basé sur 'aimer' :"
        
        if mode == "1":     # Indicatif
            
            if temps == "1":    # Present
                t += "\nIndicatif Présent\nActif   : J'aime\nPassif : Je suis aimé"
            
            elif temps == "2":  # Imparfait
                t += "\nIndicatif Imparfait\nActif   : J'aimais\nPassif : J'étais aimé"
            
            elif temps == "3":  # Futur
                t += "\nIndicatif Futur\nActif   : J'aimerai\nPassif : Je serai aimé"
            
            elif temps == "4":  # Parfait
                t += "\nIndicatif Parfait\nActif   : J'ai aimé, j'aimai\nPassif : J'ai été aimé, je fus aimé"
            
            elif temps == "5":  # Plus-que-parfait
                t += "\nIndicatif plus-que-parfait\nActif   : J'avais aimé\nPassif : J'avais été aimé"
            
            elif temps == "6":  # Futur anterieur
                t += "\nIndicatif Futur antérieur\nActif   : J'aurai aimé\nPassif : J'aurai été aimé"
        
        
        elif mode == "2":   # Subjonctif/conditionnel
            
            if temps == "1":    # Present
                t += "\nSubjonctif / Conditionnel Présent\nActif   : Que j'aime / J'aimerais\nPassif : Que je sois aimé / Je serais aimé"
            
            elif temps == "2":  # Imparfait
                t += "\nSubjonctif / Conditionnel Imparfait\nActif   : Que j'aimasse / J'aimerais\nPassif : Que je fusse aimé / Je serais aimé"
            
            elif temps == "3":  # Futur
                t = "Ce temps n'existe pas au subjonctif"
            
            elif temps == "4":  # Parfait
                t += "\nSubjonctif / Conditionnel Parfait\nActif   : Que j'aie aimé\nPassif : Que j'aie été aimé"
            
            elif temps == "5":  # Plus-que-parfait
                t += "\nSubjonctif / Conditionnel plus-que-parfait\nActif   : Que j'eusse aimé / J'aurais aimé\nPassif : Que j'eusse été aimé / J'aurais été aimé"
            
            elif temps == "6":  # Futur anterieur
                t = "Ce temps n'existe pas au subjonctif"
        
        self.lab_exConj["text"] = t
        
        return



    def buildListFlex(self):
        u"""
        Construire ou mettre à jour la liste des formes fléchies et conjuguées
        """
        
        try:
            hostlist = self.getlist()   # Appel de la fonction de l'hôte pour récupérer la liste de mots à décliner
        except:
            print "! ! ! Echec de la récupération de la liste fournie par l'hôte ! ! !"
            return
        
        self['cursor']='watch'
        
        dicfile = self.getfile()        # Appel de la fonction de l'hôte pour récupérer l'objet fichier du dico
        
        # Initialiser un objet liste de flexion (l'initialisation crée et complète le fichier des flexions)
        ListFlex(lstsource=hostlist,
                 dicfile=dicfile,
                 lstflxpath=os.path.join(self.getAppDataPath(), "declinator_listflex"),
                 labprogr=self.lab_progr)
        
        self['cursor']=''
        
        return


    def exportListFlex(self):
        u"""
        Construire la liste des formes fléchies et conjuguées
        et l'exporter dans un fichier texte
        """
        
        
        # --- Demander le chemin
        fichpath = tkFileDialog.asksaveasfilename(parent=self,
                                title = self.__lgget("g", "msg4"),
                                filetypes = ((self.__lgget("g", "ftxt"),'*.txt'),),
                                initialfile = "flexions.txt"
                                )
        if not fichpath: return
    
        # --- Reconstruire la liste
        
        wmsg=Toplevel(self, padx=15, pady=10)
        wmsg.title("Exporter la liste des flexions")
        
        Label(wmsg,text="\n" + "Declinator doit d'abord reconstruire sa base des flexions.\n\nCela peut nécessiter quelques minutes\n\n\nMerci de patienter..." + "\n", font=("Helvetica",9,"bold")).pack()
        
        self.buildListFlex() # Reconstruire la liste des flexions
        
        wmsg.destroy()
        
        # --- Recopier la liste à jour vers le fichier texte d'exportation 
        try:
            shutil.copy(os.path.join(self.getAppDataPath(), "declinator_listflex"), fichpath)
            
			# Avertir de la fin de l'exportation
            tkMessageBox.showinfo(parent=self,
                    title = self.__lgget("g", "msg4"),
                    message = self.__lgget("g", "msg5") + "\n" + fichpath)
            
        except:
            tkMessageBox.showwarning(parent=self,
                    title = self.__lgget("g", "msg4"),
                    message = self.__lgget("g", "msg6") )
            
        return


    def __lgget(self, section, clef):
        u"""
        Méthode utilisée en interne par le greffon pour le multilinguisme de l'interface
        Appel d'une chaîne
        """
        
        return eval("self.lg_" + section +"['" + clef + "']")


    def __loadlg(self):
        u"""
        Méthode utilisée en interne par le greffon pour le multilinguisme de l'interface
        Chargement des chaînes (contenues dans des pyDictionnaires)
        """
        
        if self.lgcode in ("en", "eng"):
            
            self.lg_g = {
             "title"    : u"Decline & Conjugate",
             "ftxt"     : "Text files",
             "fall"     : "All the files",
             
             "s1"       : "Indicative",
             "s2"       : "Subjonctive/Conditionnel",
             "s3"       : "Present",
             "s4"       : "Imperfect",
             "s5"       : "Future",
             "s6"       : "Perfect",
             "s7"       : "Pluperfect",
             "s8"       : "Futur Perfect",
             
             "s9"       : "Mood:",
             "s10"      : "Tense:",
             "s11"      : "Active",
             "s12"      : "Passive",
             "s13"      : "1st pers. sing.",
             "s14"      : "2nd pers. sing.",
             "s15"      : "3rd pers. sing.",
             "s16"      : "1st pers. plur.",
             "s17"      : "2nd pers. plur.",
             "s18"      : "3rd pers. plur.",
             "s19"      : "Infinitive :",
             "s20"      : "Radical of Present :",
             "s21"      : "Radical of Perfect :",
             "s22"      : "Radical of Supine  :",
             
             "s23"      : "Type or paste the text here:",
             "s24"      : "Tool for displaying Latin declensions and conjugations",
             "s25"      : "Move he mouse",
             "s26"      : "Declinator must at first re-build its database of the inflections.\n\nThat may need a few minutes\n\n\nPlease wait...",
             "s27"      : "NOMINATIVE : case of the subject and of the attibrute of the subject.",
             "s28"      : "VOCATIVE : case of the apostrophe, the de l'interpellation.\nThis case is unusual in technical context (scientific Latin).",
             "s29"      : "ACCUSATIVE : case of the direct object et its attribute.",
             "s30"      : "GENITIVE : case of the possessive.",
             "s31"      : "DATIVE : case of the indirect object (to smb. or smth.)\nor attribution (for smb. oo smth.).",
             "s32"      : "ABLATIVE : case of the agent or the state.",
             "s33"      : "Selected headword of the dictonary. You may enter in this case some words\nabsent from the dictionary (with using if possible the suitable grammatical encoding).",
             "s34"      : "Grammatical status of the selected headword.",
             "s35"      : "Display the help of Declinator",
             "s36"      : "Export the list of the inflections (can be used as database for spelling checking).",
             "s37"      : "Latin translation helper (taking in account the inflections).",
             "s38"      : "Paste the contents of the clipboard in the area of the text to translate.",
             "s39"      : "Global translating and spelling checking: underline the words not recognized\nand translate the other words.",
             "s40"      : "Open a Latin text file to translate.",
             "s41"      : "Type or paste here the Latin text to translate.\nDouble-click on a word to display its translation.",
             "s42"      : "Area of displaying the translations",
             "s43"      : "Move the mouse on an element of Declinator to display the related information...",
             "s44"      : "Declinator help",
             "s45"      : "(select or type a word)",
             "s46"      : "(this expression is not declinable/conjugable)",
             "s47"      : "(the declension/conjugation of this expresson can't be displayed)",
             "s48"      : "(can't display a declension/conjugation)",
			 "s49"		: "(no direct matching)",
			 "s50"		: "(conjonction postposed)",
			 "s51"		: "(prefix)",
			 "s52"		: "and",
			 "s53"		: "or",
			 "s54"		: "nearly, hardly",
			 "s55"		: "partially, half-",
            
             "msg1"     : u"Open a Latin text file to translate",
             "msg2"     : u"Latin translation helper",
             "msg3"     : u"Open at first a Latin-English dictionary!",
			 "msg4"		: u"Export the list of the inflections",
			 "msg5"		: u"The list of the inflections was exported in the file:",
			 "msg6"		: "Export failure!",
			 
			 "caspers"	: {
							"N":"Nominative",
							"V":"Vocative",
							"A":"Accusative",
							"G":"Genitive",
							"D":"Dative",
							"B":"Ablative",
							"m":"masculine",
							"f":"feminine",
							"n":"neuter",
							"s":"singulier",
							"p":"plural",
							"I":"Indicative",
							"S":"Subjonctive",
							"P":"Present",
							"a":"active",
							"z":"passive",
							"1":"1rst person of the",
							"2":"2nd person of the",
							"3":"3nd person of the",
							"L":"Prefix of compound of Latin roots",
							"K":"Prefix of compound of Greek roots",
							"L":"Prefix of compound word",
							"~":"(no inflection referenced)",
							"?":"(no inflection referenced)"
							}
							
            }
        
        else:   # français par défaut
            
            # Nb : ne pas utiliser de caractères spéciaux de s1 à s8 (car utilisés comme variables tkInter)
            self.lg_g = {
             "title"    : u"Décliner & Conjuguer",
             "ftxt"     : "Fichiers texte",
             "fall"     : "Tous les fichiers",
             
             "s1"       : "Indicatif",
             "s2"       : "Subjonctif/Conditionnel",
             "s3"       : "Present",
             "s4"       : "Imparfait",
             "s5"       : "Futur",
             "s6"       : "Parfait",
             "s7"       : "Plus-que-parfait",
             "s8"       : "Futur anterieur",
             
             "s9"       : "Mode :",
             "s10"      : "Temps :",
             "s11"      : "Actif",
             "s12"      : "Passif",
             "s13"      : "1ère pers. sing.",
             "s14"      : "2ème pers. sing.",
             "s15"      : "3ème pers. sing.",
             "s16"      : "1ère pers. plur.",
             "s17"      : "2ème pers. plur.",
             "s18"      : "3ème pers. plur.",
             "s19"      : "Infinitif  :",
             "s20"      : "Radical du Présent :",
             "s21"      : "Radical du Parfait :",
             "s22"      : "Radical du Supin   :",
             "s23"      : "Tapez ou collez ici le texte :",
             "s24"      : "Outil d'affichage des déclinaisons et conjugaisons latines",
             "s25"      : "Bougez la souris",
             "s26"      : "Declinator doit d'abord reconstruire sa base des flexions.\n\nCela peut nécessiter quelques minutes\n\n\nMerci de patienter...",
             "s27"      : "NOMINATIF : cas du sujet et de l'attribut du sujet.",
             "s28"      : "VOCATIF : cas de l'apostrophe, de l'interpellation.\nCe cas est inusité en contexte technique (Latin scientifique).",
             "s29"      : "ACCUSATIF : cas du complément d'objet direct et de son attribut.",
             "s30"      : "GENITIF : cas du complément du nom.",
             "s31"      : "DATIF : cas du complément d'objet indirect (à qqun ou qqchse)\net du complément d'attribution (à qqun ou qqchse).",
             "s32"      : "ABLATIF : cas des compléments circonstanciels (de moyen, de manière, d'origine)\nou d'état (avec...).",
             "s33"      : "Entrée du dictionnaire sélectionnée. Vous pouvez entrer dans cette case des mots\nabsents du dictionnaire (en utilisant si possible le codage grammatical approprié).",
             "s34"      : "Statut grammatical de l'entrée en sélection.",
             "s35"      : "Afficher l'aide de Declinator",
             "s36"      : "Exporter une liste des flexions (peut servir de base de correction orthographique).",
             "s37"      : "Aide à la traduction latine (tenant compte des flexions).",
             "s38"      : "Coller le contenu du presse-papiers dans la zone du texte à traduire.",
             "s39"      : "Traduction et contrôle orthographique globaux : surligne les mots non reconnus\n et traduit les autres.",
             "s40"      : "Ouvrir un fichier texte latin à traduire.",
             "s41"      : "Tapez ou collez ici le texte latin à traduire.\nDouble-cliquez sur un mot pour afficher sa traduction.",
             "s42"      : "Zone d'affichage des traductions",
             "s43"      : "Déplacez la souris sur un élément de Declinator pour afficher l'info correspondante...",
             "s44"      : "Aide de Declinator",
             "s45"      : "(sélectionnez ou tapez un mot)",
             "s46"      : "(cette expression n'est pas déclinable/conjugable)",
             "s47"      : "(la déclinaison/conjugaison de cette expression n'est pas affichable)",
             "s48"      : "(impossible d'afficher une déclinaison/conjugaison)",
             "s49"		: "(pas de correspondance directe)",
			 "s50"		: "(conjonction postposée)",
			 "s51"		: "(préfixe)",
			 "s52"		: "et, ainsi que",
			 "s53"		: "ou, ou bien",
			 "s54"		: "presque, à peine",
			 "s55"		: "partiellement, à moitié",
			 
             "msg1"     : u"Ouvrir un fichier texte latin à traduire",
             "msg2"     : u"Aide à la traduction latine",
             "msg3"     : u"Ouvrez d'abord un dictionnaire Latin-Français !",
             "msg4"		: u"Exporter la liste des flexions",
			 "msg5"		: u"La liste des flexions a été exportée dans le fichier :",
			 "msg6"		: u"L'exportation a échoué !",
			 
			 "caspers"	: {
							"N":"Nominatif",
							"V":"Vocatif",
							"A":"Accusatif",
							"G":"Génitif",
							"D":"Datif",
							"B":"Ablatif",
							"m":"masculin",
							"f":"féminin",
							"n":"neutre",
							"s":"singulier",
							"p":"pluriel",
							"I":"Indicatif",
							"S":"Subjonctif",
							"P":"Présent",
							"a":"actif",
							"z":"passif",
							"1":"1ère personne du",
							"2":"2ème personne du",
							"3":"3ème personne du",
							"L":"Préfixe de composé à racines latines",
							"K":"Préfixe de composé à racines grecques",
							"L":"Préfixe de mot composé",
							"~":"(pas de flexion référencée)",
							"?":"(pas de flexion référencée)"
							}
			
			}
        
        return


class MotCas():
    u"""
    Structure des données déclinées
    """
    def __init__(self):
        self.Rac=""       # racine
        self.Des=""       # désinence



class cl_LatinWord():
    u"""
    Code de travail de Déclinaison/conjugaison (hors interface graphique)
    """

    def __init__(self, item):
        """
        Décline ou conjugue 'item'
        ('item' est une entrée complète de dictionnaire : mot + code grammatical)
        """
        
        # ========================================
        # === Propriétés publiques de la classe   
        # ========================================
        
        # flags de statut
        self.isUnknownStatus = False          #(Boolean) expression à statut grammatical inconnu
        self.toNotDecl = False                #(Boolean) expression à ne pas décliner même si potentiellement déclinable(locutions par exemple)
        self.isDeclUnknown = False            #(Boolean) expression potentiellement déclinable mais non déclinée car déclinaison non connue
        self.isDeclNone = False               #(Boolean) expression réellement indéclinable
        self.isDeclined = False               #(Boolean) expression déclinable et a été effectivement déclinée (des données sont dans Decl() )
        self.isConjugated = False             #(Boolean) expression qui a été effectivement conjuguée (des données sont dans conj() )
        
        # flags grammaticaux
        self.isSubstantive = False            #(Boolean) substantif
        self.isAdjective = False              #(Boolean) adjectif
        self.isVerb = False                   #(Boolean) verbe
        self.isAdverb = False                 #(Boolean) adverbe
        self.isRelative = False               #(Boolean) pronom-adjectif relatif
        self.isNumeral = False                #(Boolean) nombre (cardinal ou ordinal)
        self.isPrefix = False                 #(Boolean) préfixe
        self.isSuffix = False                 #(Boolean) suffixe
        self.isLocution = False               #(Boolean) locution
        self.isConjunction = False            #(Boolean) conjonction
        self.isDemonstrative = False          #(Boolean) démonstratif
        self.isAbbreviation = False           #(Boolean) abréviation
        self.isMasculine = False              #(Boolean) masculin
        self.isFeminine = False               #(Boolean) féminin
        self.isNeutral = False                #(Boolean) neutre
        self.isSingular = False               #(Boolean) singulier
        self.isPlural = False                 #(Boolean) pluriel
        self.isTransitive = False             #(Boolean) transitif
        self.isIntransitive = False           #(Boolean) intransitif
        self.isPreposition = False            #(Boolean) préposition
        self.isRem = False                    #(Boolean) commentaire
        self.isWithAccusative = False         #(Boolean) ... + accusatif
        self.isWithAblative = False           #(Boolean) ... + ablatif
        self.isSymbol = False                 #(Boolean) symbole
        self.isComparative = False            #(Boolean) comparatif
        self.isSuperlative = False            #(Boolean) superlatif
        self.isFromLatin = False              #(Boolean) provenant du Latin
        self.isFromGreek = False              #(Boolean) provenant du Grec
        self.isDecl1 = False                  #(Boolean) 1ère déclinaison
        self.isDecl2 = False                  #(Boolean) 2ème déclinaison
        self.isDecl3 = False                  #(Boolean) 3ème déclinaison
        self.isDecl4 = False                  #(Boolean) 4ème déclinaison
        self.isDecl5 = False                  #(Boolean) 5ème déclinaison
        self.isGroupA = False                 #(Boolean) groupe A (adjectifs)
        self.isGroupB = False                 #(Boolean) groupe B (adjectifs)
        self.isGroupC = False                 #(Boolean) groupe C (adjectifs)
        self.isConj1 = False                  #(Boolean) 1ère conjugaison
        self.isConj2 = False                  #(Boolean) 2ème conjugaison
        self.isConj3 = False                  #(Boolean) 3ème conjugaison
        self.isConj4 = False                  #(Boolean) 4ème conjugaison
        self.isConjM = False                  #(Boolean) conjugaison mixte
        self.isConjSum = False                #(Boolean) conjugaison de Sum et ses dérivés
        self.isConjFero = False               #(Boolean) conjugaison de Fero et ses dérivés
        
        
        self.GramInfo=""                    #(String) descriptif convivial du code grammatical
        
        self.Conj=[]                        # Séquence de la conjugaison : liste de (racine, désinence)
        self.Decl=[]                        # Séquence de la déclinaison : liste de (racine, désinence)
        
        # Données des verbes
        self.Vinfinitif=""                  #(String) --- infinitif
        self.Vradic1=""                     #(String) --- radical du présent
        self.Vradic2=""                     #(String) --- radical du parfait
        self.Vradic3=""                     #(String) --- radical du supin
        
        # ========================================
        # === Propriétés privées de la classe     
        # ========================================
        
        
        # --- Mot de base (mot nu, nettoyé de la suite de désinences, codes grammaticaux etc.)
        #   ex : "Rosa/ae [s f 1]" > MotBase = "Rosa"
        self.__MotBase =""                         #(String)
        
        
        # ---- Données des verbes ---
        self.curNumConj=""                       #(String) --- n° de conjugaison courante
        
        
        # =======(fin des initialisations des propriétés)=======
        
        
        self.__definirDeclinaison(item)
        
        
        
        return




    def AnalyseAutomatique(self, item):
        
        u"""
        Tente d'attribuer des données grammaticales à un mot
        qui en est explicitement dépourvu
        """
        
        
        idGram = ""
        sp = ""      # séparateur des désinences du mot source
        
        # ------------
        
        
        for sp in ("/", ",", ", ", " "):
            
            # === numéraux ===
                
            if "unus" + sp + "a" + sp + "um" in item:
                
                idGram = "num1"
            
            elif ("duo" + sp + "duae" + sp + "duo" in item) or ("duo" + sp + u"duæ" + sp + "duo" in item):
                
                idGram = "num2"
            
            elif "tres" + sp + "tres" + sp + "tria" in item:
                
                idGram = "num3"
            
            
            # === Adjectifs ===
                
            elif "us" + sp + "a" + sp + "um" in item:
                
                idGram = "adj A"
            
            elif "er" + sp + "era" + sp + "erum" in item:
                
                idGram = "adj Aa"
            
            elif "is" + sp + "is" + sp + "e" in item:
                
                idGram = "adj Bp"
            
            elif "ex" + sp + "icis" in item:
                
                idGram = "adj Bex"
            
            elif ("er" + sp + "cris" + sp + "cre" in item) or ("er" + sp + "tris" + sp + "tre" in item):
                
                idGram = "adj Ber"
            
            elif ("ax" + sp + "acis" in item) or ("ox" + sp + "ocis" in item):
                
                idGram = "adj Bx"
            
            elif "or" + sp + "oris" in item:
                
                idGram = "adj Bor"
            
            elif "us" + sp + "eris" in item:
                
                idGram = "adj Bus"
            
            elif "oides" + sp + "oidis" in item:
                
                idGram = "adj Ci"
            
            elif "odes" + sp + "odis" in item:
                
                idGram = "adj Co"
            
            elif "ior" + sp + "ior" + sp + "ius" in item:
                
                idGram = "cmp"
            
            
            # === Substantifs ===
                
            elif ("a" + sp + "ae" in item) or ("a" + sp + u"æ" in item):
                
                idGram = "s 1"
            
            elif "us" + sp + "i" in item:
                
                idGram = "s 2"
            
            elif "um" + sp + "i" in item:
                
                idGram = "s n 2"
            
            elif "us" + sp + "us" in item:
                
                idGram = "s 4"
            
            elif "us" + sp + "ua" in item:
                
                idGram = "s n 4"
            
            elif "es" + sp + "ei" in item:
                
                idGram = "s 5"
            
            
            # === Verbes ===
                
            elif sp + "are" + sp in item:
                
                idGram = "v1"
                
            elif (sp + "ire" + sp in item) and (sp == "/"):
                
                idGram = "v4"
                
            elif (sp + "ere" + sp in item) and (sp == "/"):
                
                if "eo" + sp in item:
                    
                    idGram = "v2"
                
                elif "io" + sp in item:
                    
                    idGram = "vm"
                
                elif "o" + sp in item:
                    
                    idGram = "v3"
                
                
                
            elif "esse" + sp in item:
                
                idGram = "vs"
                
            elif ("ferre" + sp in item) and (sp == "/"):
                
                idGram = "vf"
            
            # ---(end if)
            
                
            if idGram <> "" :
                break
        
        
        # ---(fin for sp)
        
        
        # ================
        
        if idGram <> "":
            item = item + " [" + idGram + "]"
            self.__definirDeclinaison(item)



    def ConjUpdate(self, mode, temps):

        u"""~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        Remplit la liste publique de conjugaison, Conj(), pour un temps et un mode donnés
        à partir des racines et du numéro de conjugaison (antérieurement établis)
        
           Paramètres :
                           mode    = mode de la conjugaison
                           temps   = temps de la conjugaison
        
        Procédure utilisée par le constructeur puis ensuite utilisable comme méthode publique
         pour mettre à jour la liste Conj() de l'objet avec d'autres temps/modes
         que l'indicatif présent
        
        Cartographie des index de la liste :
                   0-5  : voix active
                   6-11 : voix passive
        
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        """
        
        n = 0
        flagParfaitDefectif = False
        flagSupinDefectif = False
        # -----------------------
        
        # réinitialiser la liste
        self.Conj=[]
        for n in range(12): self.Conj.append(MotCas())
        
        # homogénéiser la casse des paramètres (> minuscules)
        mode = mode.lower()
        temps = temps.lower()
        
        self.isConjugated = True
        
        # ==============================================
        # === Remplissage des racines du verbe conjugué 
        # ==============================================
        
        if temps in ("present", "imparfait", "futur"):
            
            for n in range(12):
                self.Conj[n].Rac = self.Vradic1         # racine du présent
        
        else:
            if self.Vradic2 != "-":
                for n in range(6):                      # actif
                    self.Conj[n].Rac = self.Vradic2     # racine du parfait
            else:
                flagParfaitDefectif = True
            
            
            if self.Vradic3 != "-":
                for n in range(6,12):                   # passif
                    self.Conj[n].Rac = self.Vradic3     # racine du supin
            else:
                flagSupinDefectif = True
        
        
        # ========================================================
        # === VOIX ACTIVE ========================================
        # ========================================================
        
        if mode == "indicatif":                         # actif/indicatif
            
            if temps == "present":                      # actif/indicatif/présent
                
                if self.curNumConj == "1":
                    self.Conj[0].Des = "o"
                    self.Conj[1].Des = "as"
                    self.Conj[2].Des = "at"
                    self.Conj[3].Des = "amus"
                    self.Conj[4].Des = "atis"
                    self.Conj[5].Des = "ant"
                elif self.curNumConj == "2":
                    self.Conj[0].Des = "eo"
                    self.Conj[1].Des = "es"
                    self.Conj[2].Des = "et"
                    self.Conj[3].Des = "emus"
                    self.Conj[4].Des = "etis"
                    self.Conj[5].Des = "ent"
                elif self.curNumConj == "3":
                    self.Conj[0].Des = "o"
                    self.Conj[1].Des = "is"
                    self.Conj[2].Des = "it"
                    self.Conj[3].Des = "imus"
                    self.Conj[4].Des = "itis"
                    self.Conj[5].Des = "unt"
                elif self.curNumConj == "4":
                    self.Conj[0].Des = "io"
                    self.Conj[1].Des = "is"
                    self.Conj[2].Des = "it"
                    self.Conj[3].Des = "imus"
                    self.Conj[4].Des = "itis"
                    self.Conj[5].Des = "iunt"
                elif self.curNumConj == "m":
                    self.Conj[0].Des = "io"
                    self.Conj[1].Des = "is"
                    self.Conj[2].Des = "it"
                    self.Conj[3].Des = "imus"
                    self.Conj[4].Des = "itis"
                    self.Conj[5].Des = "iunt"
                elif self.curNumConj == "s":  # sum et dérivés
                    self.Conj[0].Des = "sum"
                    self.Conj[1].Des = "es"
                    self.Conj[2].Des = "est"
                    self.Conj[3].Des = "sumus"
                    self.Conj[4].Des = "estis"
                    self.Conj[5].Des = "sunt"
                elif self.curNumConj == "f":  # fero et dérivés
                    self.Conj[0].Des = "o"
                    self.Conj[1].Des = "s"
                    self.Conj[2].Des = "t"
                    self.Conj[3].Des = "imus"
                    self.Conj[4].Des = "tis"
                    self.Conj[5].Des = "unt"
                
            elif temps == "imparfait":                # actif/indicatif/imparfait
                
                if self.curNumConj == "1":
                    self.Conj[0].Des = "abam"
                    self.Conj[1].Des = "abas"
                    self.Conj[2].Des = "abat"
                    self.Conj[3].Des = "abamus"
                    self.Conj[4].Des = "abatis"
                    self.Conj[5].Des = "abant"
                elif self.curNumConj in ("2", "3", "f"):
                    self.Conj[0].Des = "ebam"
                    self.Conj[1].Des = "ebas"
                    self.Conj[2].Des = "ebat"
                    self.Conj[3].Des = "ebamus"
                    self.Conj[4].Des = "ebatis"
                    self.Conj[5].Des = "ebant"
                elif self.curNumConj in ("4", "m"):
                    self.Conj[0].Des = "iebam"
                    self.Conj[1].Des = "iebas"
                    self.Conj[2].Des = "iebat"
                    self.Conj[3].Des = "iebamus"
                    self.Conj[4].Des = "iebatis"
                    self.Conj[5].Des = "iebant"
                elif self.curNumConj ==  "m":
                    self.Conj[0].Des = "iam"
                    self.Conj[1].Des = "ies"
                    self.Conj[2].Des = "iet"
                    self.Conj[3].Des = "iemus"
                    self.Conj[4].Des = "ietis"
                    self.Conj[5].Des = "ient"
                elif self.curNumConj == "s":
                    self.Conj[0].Des = "eram"
                    self.Conj[1].Des = "eras"
                    self.Conj[2].Des = "erat"
                    self.Conj[3].Des = "eramus"
                    self.Conj[4].Des = "eratis"
                    self.Conj[5].Des = "erant"
                
            elif temps == "futur":                    # actif/indicatif/futur
                
                if self.curNumConj == "1":
                    self.Conj[0].Des = "abo"
                    self.Conj[1].Des = "abis"
                    self.Conj[2].Des = "abit"
                    self.Conj[3].Des = "abimus"
                    self.Conj[4].Des = "abitis"
                    self.Conj[5].Des = "abunt"
                elif self.curNumConj == "2":
                    self.Conj[0].Des = "ebo"
                    self.Conj[1].Des = "ebis"
                    self.Conj[2].Des = "ebit"
                    self.Conj[3].Des = "ebimus"
                    self.Conj[4].Des = "ebitis"
                    self.Conj[5].Des = "ebunt"
                elif self.curNumConj in ("3", "f"):
                    self.Conj[0].Des = "am"
                    self.Conj[1].Des = "es"
                    self.Conj[2].Des = "et"
                    self.Conj[3].Des = "emus"
                    self.Conj[4].Des = "etis"
                    self.Conj[5].Des = "ent"
                elif self.curNumConj in ("4", "m"):
                    self.Conj[0].Des = "iam"
                    self.Conj[1].Des = "ies"
                    self.Conj[2].Des = "iet"
                    self.Conj[3].Des = "iemus"
                    self.Conj[4].Des = "ietis"
                    self.Conj[5].Des = "ient"
                elif self.curNumConj == "s":
                    self.Conj[0].Des = "ero"
                    self.Conj[1].Des = "eris"
                    self.Conj[2].Des = "erit"
                    self.Conj[3].Des = "erimus"
                    self.Conj[4].Des = "eritis"
                    self.Conj[5].Des = "erunt"
                
            elif temps == "parfait":                  # actif/indicatif/parfait
                
                if flagParfaitDefectif == False:
                    # toutes conjugaisons
                    self.Conj[0].Des = "i"
                    self.Conj[1].Des = "isti"
                    self.Conj[2].Des = "it"
                    self.Conj[3].Des = "imus"
                    self.Conj[4].Des = "istis"
                    self.Conj[5].Des = "erunt/ere"
                
            elif temps == "plus-que-parfait":         # actif/indicatif/Plus-que-parfait
                
                if flagParfaitDefectif == False:
                    #toutes conjugaisons
                    self.Conj[0].Des = "eram"
                    self.Conj[1].Des = "eras"
                    self.Conj[2].Des = "erat"
                    self.Conj[3].Des = "eramus"
                    self.Conj[4].Des = "eratis"
                    self.Conj[5].Des = "erant"
                
            elif temps == "futur anterieur":           # actif/indicatif/futur antérieur
                
                if flagParfaitDefectif == False:
                    # toutes conjugaisons
                    self.Conj[0].Des = "ero"
                    self.Conj[1].Des = "eris"
                    self.Conj[2].Des = "erit"
                    self.Conj[3].Des = "erimus"
                    self.Conj[4].Des = "eritis"
                    self.Conj[5].Des = "erint"
            
            
        elif mode == "subjonctif/conditionnel":     # actif/subjonctif
            
            if temps == "present":                    # actif/subjonctif/présent
                
                if self.curNumConj == "1":
                    self.Conj[0].Des = "em"
                    self.Conj[1].Des = "es"
                    self.Conj[2].Des = "et"
                    self.Conj[3].Des = "emus"
                    self.Conj[4].Des = "etis"
                    self.Conj[5].Des = "ent"
                elif self.curNumConj == "2":
                    self.Conj[0].Des = "eam"
                    self.Conj[1].Des = "eas"
                    self.Conj[2].Des = "eat"
                    self.Conj[3].Des = "eamus"
                    self.Conj[4].Des = "eatis"
                    self.Conj[5].Des = "eant"
                elif self.curNumConj in ("3", "f"):
                    self.Conj[0].Des = "am"
                    self.Conj[1].Des = "as"
                    self.Conj[2].Des = "at"
                    self.Conj[3].Des = "amus"
                    self.Conj[4].Des = "atis"
                    self.Conj[5].Des = "ant"
                elif self.curNumConj in ("4", "m"):
                    self.Conj[0].Des = "iam"
                    self.Conj[1].Des = "ias"
                    self.Conj[2].Des = "iat"
                    self.Conj[3].Des = "iamus"
                    self.Conj[4].Des = "iatis"
                    self.Conj[5].Des = "iant"
                elif self.curNumConj == "s":
                    self.Conj[0].Des = "sim"
                    self.Conj[1].Des = "sis"
                    self.Conj[2].Des = "sit"
                    self.Conj[3].Des = "simus"
                    self.Conj[4].Des = "sitis"
                    self.Conj[5].Des = "sint"
                
            elif temps == "imparfait":                # actif/subjonctif/imparfait
                
                if self.curNumConj == "1":
                    self.Conj[0].Des = "arem"
                    self.Conj[1].Des = "ares"
                    self.Conj[2].Des = "aret"
                    self.Conj[3].Des = "aremus"
                    self.Conj[4].Des = "aretis"
                    self.Conj[5].Des = "arent"
                elif self.curNumConj in ("2", "3", "m"):
                    self.Conj[0].Des = "erem"
                    self.Conj[1].Des = "eres"
                    self.Conj[2].Des = "eret"
                    self.Conj[3].Des = "eremus"
                    self.Conj[4].Des = "eretis"
                    self.Conj[5].Des = "erent"
                elif self.curNumConj == "4":
                    self.Conj[0].Des = "irem"
                    self.Conj[1].Des = "ires"
                    self.Conj[2].Des = "iret"
                    self.Conj[3].Des = "iremus"
                    self.Conj[4].Des = "iretis"
                    self.Conj[5].Des = "irent"
                elif self.curNumConj == "s":
                    self.Conj[0].Des = "essem/(forem)"
                    self.Conj[1].Des = "esses/(fores)"
                    self.Conj[2].Des = "esset/(foret)"
                    self.Conj[3].Des = "essemus"
                    self.Conj[4].Des = "essetis"
                    self.Conj[5].Des = "essent/(forent)"
                elif self.curNumConj == "f":
                    self.Conj[0].Des = "errem"
                    self.Conj[1].Des = "erres"
                    self.Conj[2].Des = "erret"
                    self.Conj[3].Des = "erremus"
                    self.Conj[4].Des = "erretis"
                    self.Conj[5].Des = "errent"
                
            elif temps == "parfait":                  # actif/subjonctif/parfait
                
                if flagParfaitDefectif == False:
                    # toutes conjugaisons
                    self.Conj[0].Des = "erim"
                    self.Conj[1].Des = "eris"
                    self.Conj[2].Des = "erit"
                    self.Conj[3].Des = "erimus"
                    self.Conj[4].Des = "eritis"
                    self.Conj[5].Des = "erint"
                
            elif temps == "plus-que-parfait":         # actif/subjonctif/plus-que-parfait
                
                if flagParfaitDefectif == False:
                    # toutes conjugaisons
                    self.Conj[0].Des = "issem"
                    self.Conj[1].Des = "isses"
                    self.Conj[2].Des = "isset"
                    self.Conj[3].Des = "issemus"
                    self.Conj[4].Des = "issetis"
                    self.Conj[5].Des = "issent"
        
        
        # ====================================================
        # === VOIX PASSIVE ===================================
        # ====================================================
        
        
        if self.curNumConj == "s":                  # pas de passif pour 'sum'
            
            for n in range(6,12):      # (n = 6 To 11)
                self.Conj[n].Rac = ""
                self.Conj[n].Des = ""
            return
        
        
        # --------------------------------------
        
        elif mode == "indicatif":                   # passif/indicatif
            
            if temps == "present":                  # passif/indicatif/présent
                
                if self.curNumConj == "1":
                    self.Conj[6].Des = "or"
                    self.Conj[7].Des = "aris/are"
                    self.Conj[8].Des = "atur"
                    self.Conj[9].Des = "amur"
                    self.Conj[10].Des = "amini"
                    self.Conj[11].Des = "antur"
                elif self.curNumConj == "2":
                    self.Conj[6].Des = "eor"
                    self.Conj[7].Des = "eris/ere"
                    self.Conj[8].Des = "etur"
                    self.Conj[9].Des = "emur"
                    self.Conj[10].Des = "emini"
                    self.Conj[11].Des = "entur"
                elif self.curNumConj == "3":
                    self.Conj[6].Des = "or"
                    self.Conj[7].Des = "eris/ere"
                    self.Conj[8].Des = "itur"
                    self.Conj[9].Des = "imur"
                    self.Conj[10].Des = "imini"
                    self.Conj[11].Des = "untur"
                elif self.curNumConj == "4":
                    self.Conj[6].Des = "ior"
                    self.Conj[7].Des = "iris/ire"
                    self.Conj[8].Des = "itur"
                    self.Conj[9].Des = "imur"
                    self.Conj[10].Des = "imini"
                    self.Conj[11].Des = "iuntur"
                elif self.curNumConj == "m":
                    self.Conj[6].Des = "ior"
                    self.Conj[7].Des = "eris/ere"
                    self.Conj[8].Des = "itur"
                    self.Conj[9].Des = "imur"
                    self.Conj[10].Des = "imini"
                    self.Conj[11].Des = "iuntur"
                elif self.curNumConj == "f":
                    self.Conj[6].Des = "or"
                    self.Conj[7].Des = "ris"
                    self.Conj[8].Des = "tur"
                    self.Conj[9].Des = "imur"
                    self.Conj[10].Des = "imini"
                    self.Conj[11].Des = "untur"
                
            elif temps == "imparfait":                # passif/indicatif/imparfait
                
                if self.curNumConj == "1":
                    self.Conj[6].Des = "abar"
                    self.Conj[7].Des = "abaris/abare"
                    self.Conj[8].Des = "abatur"
                    self.Conj[9].Des = "abamur"
                    self.Conj[10].Des = "abamini"
                    self.Conj[11].Des = "abantur"
                elif self.curNumConj in ("2", "3", "f"):
                    self.Conj[6].Des = "ebar"
                    self.Conj[7].Des = "ebaris/ebare"
                    self.Conj[8].Des = "ebatur"
                    self.Conj[9].Des = "ebamur"
                    self.Conj[10].Des = "ebamini"
                    self.Conj[11].Des = "ebantur"
                elif self.curNumConj in ("4", "m"):
                    self.Conj[6].Des = "iebar"
                    self.Conj[7].Des = "iebaris/iebare"
                    self.Conj[8].Des = "iebatur"
                    self.Conj[9].Des = "iebamur"
                    self.Conj[10].Des = "iebamini"
                    self.Conj[11].Des = "iebantur"
                
            elif temps == "futur":                    # passif/indicatif/futur
                
                if self.curNumConj == "1":
                    self.Conj[6].Des = "abor"
                    self.Conj[7].Des = "aberis/abere"
                    self.Conj[8].Des = "abitur"
                    self.Conj[9].Des = "abimur"
                    self.Conj[10].Des = "abimini"
                    self.Conj[11].Des = "abuntur"
                elif self.curNumConj == "2":
                    self.Conj[6].Des = "ebor"
                    self.Conj[7].Des = "eberis/ebere"
                    self.Conj[8].Des = "ebitur"
                    self.Conj[9].Des = "ebimur"
                    self.Conj[10].Des = "ebimini"
                    self.Conj[11].Des = "ebuntur"
                elif self.curNumConj in ("3", "f"):
                    self.Conj[6].Des = "ar"
                    self.Conj[7].Des = "eris/ere"
                    self.Conj[8].Des = "etur"
                    self.Conj[9].Des = "emur"
                    self.Conj[10].Des = "emini"
                    self.Conj[11].Des = "entur"
                elif self.curNumConj in ("4", "m"):
                    self.Conj[6].Des = "iar"
                    self.Conj[7].Des = "ieris/iere"
                    self.Conj[8].Des = "ietur"
                    self.Conj[9].Des = "iemur"
                    self.Conj[10].Des = "iemini"
                    self.Conj[11].Des = "ientur"
                
            elif temps == "parfait":                  # passif/indicatif/parfait
                
                if flagSupinDefectif == False:
                    if self.curNumConj <> "s": # toutes autres conjugaisons que sum
                        self.Conj[6].Des = "us/a/um sum"
                        self.Conj[7].Des = "us/a/um es"
                        self.Conj[8].Des = "us/a/um est"
                        self.Conj[9].Des = u"i/æ/a sumus"
                        self.Conj[10].Des = u"i/æ/a estis"
                        self.Conj[11].Des = u"i/æ/a sunt"
                
            elif temps == "plus-que-parfait":         # passif/indicatif/Plus-que-parfait
                
                if flagSupinDefectif == False:
                    if self.curNumConj <> "s":         # toutes autres conjugaisons que sum
                        self.Conj[6].Des = "us/a/um eram"
                        self.Conj[7].Des = "us/a/um eras"
                        self.Conj[8].Des = "us/a/um erat"
                        self.Conj[9].Des = u"i/æ/a eramus"
                        self.Conj[10].Des = u"i/æ/a eratis"
                        self.Conj[11].Des = u"i/æ/a erant"
                
            elif temps == "futur anterieur":            # passif/indicatif/futur antérieur
                
                if flagSupinDefectif == False:
                    if self.curNumConj <> "s":          # toutes autres conjugaisons que sum
                        self.Conj[6].Des = "us/a/um ero"
                        self.Conj[7].Des = "us/a/um eris"
                        self.Conj[8].Des = "us/a/um erit"
                        self.Conj[9].Des = u"i/æ/a erimus"
                        self.Conj[10].Des = u"i/æ/a eritis"
                        self.Conj[11].Des = u"i/æ/a erunt"
                
                
        
        elif mode == "subjonctif/conditionnel":         # passif/subjonctif
        
            if temps == "present":                      # passif/subjonctif/présent
                
                if self.curNumConj == "1":
                    self.Conj[6].Des = "er"
                    self.Conj[7].Des = "eris/ere"
                    self.Conj[8].Des = "etur"
                    self.Conj[9].Des = "emur"
                    self.Conj[10].Des = "emini"
                    self.Conj[11].Des = "entur"
                elif self.curNumConj == "2":
                    self.Conj[6].Des = "ear"
                    self.Conj[7].Des = "earis/eare"
                    self.Conj[8].Des = "eatur"
                    self.Conj[9].Des = "eamur"
                    self.Conj[10].Des = "eamini"
                    self.Conj[11].Des = "eantur"
                elif self.curNumConj in ("3", "f"):
                    self.Conj[6].Des = "ar"
                    self.Conj[7].Des = "aris/eare"
                    self.Conj[8].Des = "atur"
                    self.Conj[9].Des = "amur"
                    self.Conj[10].Des = "amini"
                    self.Conj[11].Des = "antur"
                elif self.curNumConj in ("4", "m"):
                    self.Conj[6].Des = "iar"
                    self.Conj[7].Des = "iaris/iare"
                    self.Conj[8].Des = "iatur"
                    self.Conj[9].Des = "iamur"
                    self.Conj[10].Des = "iamini"
                    self.Conj[11].Des = "iantur"
            
            elif temps == "imparfait":                # passif/subjonctif/imparfait
                
                if self.curNumConj == "1":
                    self.Conj[6].Des = "arer"
                    self.Conj[7].Des = "areris/arere"
                    self.Conj[8].Des = "aretur"
                    self.Conj[9].Des = "aremur"
                    self.Conj[10].Des = "aremini"
                    self.Conj[11].Des = "arentur"
                elif self.curNumConj in ("2", "3", "m"):
                    self.Conj[6].Des = "erer"
                    self.Conj[7].Des = "ereris/erere"
                    self.Conj[8].Des = "eretur"
                    self.Conj[9].Des = "eremur"
                    self.Conj[10].Des = "eremini"
                    self.Conj[11].Des = "erentur"
                elif self.curNumConj == "4":
                    self.Conj[6].Des = "irer"
                    self.Conj[7].Des = "ireris/irere"
                    self.Conj[8].Des = "iretur"
                    self.Conj[9].Des = "iremur"
                    self.Conj[10].Des = "iremini"
                    self.Conj[11].Des = "irentur"
                elif self.curNumConj == "f":
                    self.Conj[6].Des = "rer"
                    self.Conj[7].Des = "reris"
                    self.Conj[8].Des = "retur"
                    self.Conj[9].Des = "remur"
                    self.Conj[10].Des = "remini"
                    self.Conj[11].Des = "rentur"
            
            elif temps == "parfait":                   # passif/subjonctif/parfait
                
                if flagSupinDefectif == False:
                    # toutes conjugaisons
                    self.Conj[6].Des = "us/a/um sim"
                    self.Conj[7].Des = "us/a/um sis"
                    self.Conj[8].Des = "us/a/um sit"
                    self.Conj[9].Des = u"i/æ/a simus"
                    self.Conj[10].Des = u"i/æ/a sitis"
                    self.Conj[11].Des = u"i/æ/a sint"
            
            elif temps == "plus-que-parfait":         # passif/subjonctif/plus-que-parfait
                
                if flagSupinDefectif == False:
                    # toutes conjugaisons
                    self.Conj[6].Des = "us/a/um essem"
                    self.Conj[7].Des = "us/a/um esses"
                    self.Conj[8].Des = "us/a/um esset"
                    self.Conj[9].Des = u"i/æ/a essemus"
                    self.Conj[10].Des = u"i/æ/a essetis"
                    self.Conj[11].Des = u"i/æ/a essent"
        
        return



    def DeclinerAdjectif(self, Radic, d):
        
        
        Radic = Radic.encode('utf-8')
        
        if d == "": return
        
        i = 0
        n = 0
        # -----
        
        
        self.isMasculine = True
        self.isFeminine = True
        self.isNeutral = True
        
        self.isDeclined = True
        
        
        # =============================================================
        if self.isSingular:         # === SINGULIER                    
        # =============================================================
            
            
            # ---------------------------------------
            # --- Masculin singulier                 
            # ---------------------------------------
            
            i = 0 # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
                
                
            if d == "A":
                self.Decl[i + 0].Des = "us"     # Nominatif
                self.Decl[i + 1].Des = "e"      # Vocatif
                self.Decl[i + 2].Des = "um"     # Accusatif
                self.Decl[i + 3].Des = "i"      # Génitif
                self.Decl[i + 4].Des = "o"      # Datif
                self.Decl[i + 5].Des = "o"      # Ablatif
                
            elif d == "Aa":
                self.Decl[i + 0].Des = ""       # Nominatif
                self.Decl[i + 1].Des = ""       # Vocatif
                self.Decl[i + 2].Des = "um"     # Accusatif
                self.Decl[i + 3].Des = "i"      # Génitif
                self.Decl[i + 4].Des = "o"      # Datif
                self.Decl[i + 5].Des = "o"      # Ablatif
                
            elif d == "Ab":
                self.Decl[i + 0].Rac = Radic[0:-1] + "er" # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] + "er" # Vocatif
                
                self.Decl[i + 0].Des = ""       # Nominatif
                self.Decl[i + 1].Des = ""       # Vocatif
                self.Decl[i + 2].Des = "um"     # Accusatif
                self.Decl[i + 3].Des = "i"      # Génitif
                self.Decl[i + 4].Des = "o"      # Datif
                self.Decl[i + 5].Des = "o"      # Ablatif
            
            elif d == "Bp":
                self.Decl[i + 0].Des = "is"     # Nominatif
                self.Decl[i + 1].Des = "is"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bns":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                
                self.Decl[i + 0].Des = "s"      # Nominatif
                self.Decl[i + 1].Des = "s"      # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i/e"    # Ablatif
                
            elif d == "Bex":
                self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
                
                self.Decl[i + 0].Des = "ex"     # Nominatif
                self.Decl[i + 1].Des = "ex"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
                
            elif d == "Ber":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                
                self.Decl[i + 0].Des = "er"     # Nominatif
                self.Decl[i + 1].Des = "er"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
                
            elif d == "Bx":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                
                self.Decl[i + 0].Des = "x"      # Nominatif
                self.Decl[i + 1].Des = "x"      # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
                
            elif d == "Bor":
                self.Decl[i + 0].Des = ""       # Nominatif
                self.Decl[i + 1].Des = ""       # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
                
            elif d == "Bus":
                self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
                
                self.Decl[i + 0].Des = "us"     # Nominatif
                self.Decl[i + 1].Des = "us"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "e"      # Ablatif
                
            elif d in ("Ci", "Co"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "e"      # Ablatif
                
            elif d == "cmp":
                self.Decl[i + 0].Des = "or"     # Nominatif
                self.Decl[i + 1].Des = "or"     # Vocatif
                self.Decl[i + 2].Des = "orem"   # Accusatif
                self.Decl[i + 3].Des = "oris"   # Génitif
                self.Decl[i + 4].Des = "ori"    # Datif
                self.Decl[i + 5].Des = "ore"    # Ablatif
            
            elif d == "cmp-i": #(hors contexte, il ne semble y avoir que des pluriels : "plures/a")
                pass
            
            
            
            # -----------------------------------------------------
            # --- Féminin singulier                                
            # -----------------------------------------------------
            
            i = 12 # index de départ dans Decl
            
            
            for n in range(6):    # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            if d in ("A", "Aa", "Ab"):
                self.Decl[i + 0].Des = "a"      # Nominatif
                self.Decl[i + 1].Des = "a"      # Vocatif
                self.Decl[i + 2].Des = "am"     # Accusatif
                self.Decl[i + 3].Des = u"æ"     # Génitif
                self.Decl[i + 4].Des = u"æ"     # Datif
                self.Decl[i + 5].Des = "a"      # Ablatif
            
            elif d in ("Bp", "Ber"):
                self.Decl[i + 0].Des = "is"     # Nominatif
                self.Decl[i + 1].Des = "is"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bns":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                
                self.Decl[i + 0].Des = "s"      # Nominatif
                self.Decl[i + 1].Des = "s"      # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i/e"    # Ablatif
            
            elif d == "Bex":
                self.Decl[i + 0].Rac = Radic[0:-2]  # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-2]  # Vocatif
                
                self.Decl[i + 0].Des = "ex"     # Nominatif
                self.Decl[i + 1].Des = "ex"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bx":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                
                self.Decl[i + 0].Des = "x"      # Nominatif
                self.Decl[i + 1].Des = "x"      # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bor":
                self.Decl[i + 0].Des = ""       # Nominatif
                self.Decl[i + 1].Des = ""       # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bus":
                self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
                
                self.Decl[i + 0].Des = "us"     # Nominatif
                self.Decl[i + 1].Des = "us"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "e"      # Ablatif
            
            elif d in ("Ci", "Co"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "e"      # Ablatif
            
            elif d == "cmp":
                self.Decl[i + 0].Des = "or"     # Nominatif
                self.Decl[i + 1].Des = "or"     # Vocatif
                self.Decl[i + 2].Des = "orem"   # Accusatif
                self.Decl[i + 3].Des = "oris"   # Génitif
                self.Decl[i + 4].Des = "ori"    # Datif
                self.Decl[i + 5].Des = "ore"    # Ablatif
            
            elif d == "cmp-i": #(hors contexte, il ne semble y avoir que des pluriels : "plures/a")
                pass
            
            
            # -----------------------------------------------------
            # --- Neutre singulier                                 
            # -----------------------------------------------------
            
            i = 24 # index de départ dans Decl
            
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            if d in ("A", "Aa", "Ab"):
                self.Decl[i + 0].Des = "um"     # Nominatif
                self.Decl[i + 1].Des = "um"     # Vocatif
                self.Decl[i + 2].Des = "um"     # Accusatif
                self.Decl[i + 3].Des = "i"      # Génitif
                self.Decl[i + 4].Des = "o"      # Datif
                self.Decl[i + 5].Des = "o"      # Ablatif
            
            elif d in ("Bp", "Ber"):
                self.Decl[i + 0].Des = "e"      # Nominatif
                self.Decl[i + 1].Des = "e"      # Vocatif
                self.Decl[i + 2].Des = "em"     # Accusatif
                self.Decl[i + 3].Des = "is"     #Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bns":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                self.Decl[i + 2].Rac = Radic[0:-1] # Accusatif
                
                self.Decl[i + 0].Des = "s"      # Nominatif
                self.Decl[i + 1].Des = "s"      # Vocatif
                self.Decl[i + 2].Des = "s"      # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bex":
                self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
                self.Decl[i + 2].Rac = Radic[0:-2] # Accusatif
                
                self.Decl[i + 0].Des = "ex"     # Nominatif
                self.Decl[i + 1].Des = "ex"     # Vocatif
                self.Decl[i + 2].Des = "ex"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bx":
                self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
                
                self.Decl[i + 0].Des = "x"      # Nominatif
                self.Decl[i + 1].Des = "x"      # Vocatif
                self.Decl[i + 2].Des = "e"      # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bor":
                self.Decl[i + 0].Des = ""       # Nominatif
                self.Decl[i + 1].Des = ""       # Vocatif
                self.Decl[i + 2].Des = ""       # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "i"      # Ablatif
            
            elif d == "Bus":
                self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
                self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
                self.Decl[i + 2].Rac = Radic[0:-2] # Accusatif
                
                self.Decl[i + 0].Des = "us"     # Nominatif
                self.Decl[i + 1].Des = "us"     # Vocatif
                self.Decl[i + 2].Des = "us"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "e"      # Ablatif
            
            elif d in ("Ci", "Co"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "is"     # Génitif
                self.Decl[i + 4].Des = "i"      # Datif
                self.Decl[i + 5].Des = "e"      # Ablatif
            
            elif d == "cmp":
                self.Decl[i + 0].Des = "us"     # Nominatif
                self.Decl[i + 1].Des = "us"     # Vocatif
                self.Decl[i + 2].Des = "orem"   # Accusatif
                self.Decl[i + 3].Des = "oris"   # Génitif
                self.Decl[i + 4].Des = "ori"    # Datif
                self.Decl[i + 5].Des = "ore"    # Ablatif
            
            elif d == "cmp-i": #(hors contexte, il ne semble y avoir que des pluriels : "plures/a")
                pass
        
        
        
        # ==========================================================
        if self.isPlural:    # === PLURIEL                          
        # ==========================================================
            
            # -----------------------------------------------------
            # --- Masculin pluriel                                 
            # -----------------------------------------------------
            
            i = 6 # index de départ dans Decl
            
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            if d in ("A", "Aa", "Ab"):
                self.Decl[i + 0].Des = "i"      # Nominatif
                self.Decl[i + 1].Des = "i"      # Vocatif
                self.Decl[i + 2].Des = "os"     # Accusatif
                self.Decl[i + 3].Des = "orum"   # Génitif
                self.Decl[i + 4].Des = "is"     # Datif
                self.Decl[i + 5].Des = "is"     # Ablatif
            
            elif d in ("Bp", "Bns", "Bex", "Bx", "Bor", "Ber", "cmp-i"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "ium"    # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d == "Bus":
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "um"     # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d in ("Ci", "Co"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "um"     # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d == "cmp":
                self.Decl[i + 0].Des = "ores"   # Nominatif
                self.Decl[i + 1].Des = "ores"   # Vocatif
                self.Decl[i + 2].Des = "ores"   # Accusatif
                self.Decl[i + 3].Des = "orum"   # Génitif
                self.Decl[i + 4].Des = "oribus" # Datif
                self.Decl[i + 5].Des = "oribus" # Ablatif
            
            
            
            # -----------------------------------------------------
            # --- Féminin pluriel                                  
            # -----------------------------------------------------
            
            i = 18    # index de départ dans Decl
            
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic


            if d in ("A", "Aa", "Ab"):
                self.Decl[i + 0].Des = u"æ"     # Nominatif
                self.Decl[i + 1].Des = u"æ"     # Vocatif
                self.Decl[i + 2].Des = "as"     # Accusatif
                self.Decl[i + 3].Des = "arum"   # Génitif
                self.Decl[i + 4].Des = "is"     # Datif
                self.Decl[i + 5].Des = "is"     # Ablatif
            
            elif d in ("Bp", "Bns", "Bex", "Bx", "Bor", "Ber", "cmp-i"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "ium"    # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d == "Bus":
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "um"     # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d in ("Ci", "Co"):
                self.Decl[i + 0].Des = "es"     # Nominatif
                self.Decl[i + 1].Des = "es"     # Vocatif
                self.Decl[i + 2].Des = "es"     # Accusatif
                self.Decl[i + 3].Des = "um"     # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d == "cmp":
                self.Decl[i + 0].Des = "ores"   # Nominatif
                self.Decl[i + 1].Des = "ores"   # Vocatif
                self.Decl[i + 2].Des = "ores"   # Accusatif
                self.Decl[i + 3].Des = "orum"   # Génitif
                self.Decl[i + 4].Des = "oribus" # Datif
                self.Decl[i + 5].Des = "oribus" # Ablatif
            
            
            
            
            # -----------------------------------------------------
            # --- Neutre pluriel                                   
            # -----------------------------------------------------
            
            i = 30    # index de départ dans Decl
            
            
            for n in range(6):         # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            if d in ("A", "Aa", "Ab"):
                
                self.Decl[i + 0].Des = "a"      # Nominatif
                self.Decl[i + 1].Des = "a"      # Vocatif
                self.Decl[i + 2].Des = "a"      # Accusatif
                self.Decl[i + 3].Des = "orum"   # Génitif
                self.Decl[i + 4].Des = "is"     # Datif
                self.Decl[i + 5].Des = "is"     # Ablatif
            
            elif d in ("Bp", "Bns", "Bex", "Bx", "Bor", "Ber"):
                self.Decl[i + 0].Des = "ia"     # Nominatif
                self.Decl[i + 1].Des = "ia"     # Vocatif
                self.Decl[i + 2].Des = "ia"     # Accusatif
                self.Decl[i + 3].Des = "ium"    # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d == "Bus":
                self.Decl[i + 0].Des = "a"      # Nominatif
                self.Decl[i + 1].Des = "a"      # Vocatif
                self.Decl[i + 2].Des = "a"      # Accusatif
                self.Decl[i + 3].Des = "um"     # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d in ("Ci", "Co"):
                self.Decl[i + 0].Des = "a"      # Nominatif
                self.Decl[i + 1].Des = "a"      # Vocatif
                self.Decl[i + 2].Des = "a"      # Accusatif
                self.Decl[i + 3].Des = "um"     # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif
            
            elif d == "cmp":
                self.Decl[i + 0].Des = "ora"    # Nominatif
                self.Decl[i + 1].Des = "ora"    # Vocatif
                self.Decl[i + 2].Des = "ora"    # Accusatif
                self.Decl[i + 3].Des = "orum"   # Génitif
                self.Decl[i + 4].Des = "oribus" # Datif
                self.Decl[i + 5].Des = "oribus" # Ablatif
            
            elif d == "cmp-i":
                self.Decl[i + 0].Des = "a"      # Nominatif
                self.Decl[i + 1].Des = "a"      # Vocatif
                self.Decl[i + 2].Des = "a"      # Accusatif
                self.Decl[i + 3].Des = "ium"    # Génitif
                self.Decl[i + 4].Des = "ibus"   # Datif
                self.Decl[i + 5].Des = "ibus"   # Ablatif





    def DeclinerDemonstratif(self, mot):
        
        mot = mot.lower()
        
        
        if mot == "hic":
            
            self.isMasculine = True
            self.isFeminine = True
            self.isNeutral = True
            
            self.isDeclined = True
            
            # ----------------------------------------------
            # --- Masculin singulier                        
            # ----------------------------------------------
            
            i = 0     # index de départ dans Decl
            
            for n in range(6):     # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = "h"
            
            self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
            
            self.Decl[i + 0].Des = "ic"     # Nominatif
            self.Decl[i + 1].Des = ""       # (pas de Vocatif)
            self.Decl[i + 2].Des = "unc"    # Accusatif
            self.Decl[i + 3].Des = "ujus"   # Génitif
            self.Decl[i + 4].Des = "uic"    # Datif
            self.Decl[i + 5].Des = "oc"     # Ablatif
            
            # --------------------------------------------
            # --- Féminin singulier                       
            # --------------------------------------------
            
            i = 12    # index de départ dans l'Array Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = "h"
            
            
            self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
            
            self.Decl[i + 0].Des = "aec"    # Nominatif
            self.Decl[i + 1].Des = ""       # (pas de Vocatif)
            self.Decl[i + 2].Des = "anc"    # Accusatif
            self.Decl[i + 3].Des = "ujus"   # Génitif
            self.Decl[i + 4].Des = "uic"    # Datif
            self.Decl[i + 5].Des = "ac"     # Ablatif
            
            
            # --------------------------------------------
            # --- Neutre singulier                        
            # --------------------------------------------
            
            i = 24    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = "h"
            
            
            self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
            
            self.Decl[i + 0].Des = "oc"     # Nominatif
            self.Decl[i + 1].Des = ""       # (pas de Vocatif)
            self.Decl[i + 2].Des = "oc"     # Accusatif
            self.Decl[i + 3].Des = "ujus"   # Génitif
            self.Decl[i + 4].Des = "uic"    # Datif
            self.Decl[i + 5].Des = "oc"     # Ablatif
            
            
            # -------------------------------------------
            # --- Masculin pluriel                       
            # -------------------------------------------
            
            i = 6     # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = "h"
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif)
            
            self.Decl[i + 0].Des = "i"        # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "os"       # Accusatif
            self.Decl[i + 3].Des = "orum"     # Génitif
            self.Decl[i + 4].Des = "is"       # Datif
            self.Decl[i + 5].Des = "is"       # Ablatif
            
            # -----------------------------------------
            # --- Feminin pluriel                      
            # -----------------------------------------
            
            i = 18    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = "h"
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif)
            
            self.Decl[i + 0].Des = u"æ"       # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif)
            self.Decl[i + 2].Des = "as"       # Accusatif
            self.Decl[i + 3].Des = "arum"     # Génitif
            self.Decl[i + 4].Des = "is"       # Datif
            self.Decl[i + 5].Des = "is"       # Ablatif
            
            # -----------------------------------------
            # --- Neutre pluriel                       
            # -----------------------------------------
            
            i = 30    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = "h"
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif)
            
            self.Decl[i + 0].Des = u"æc"      # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif)
            self.Decl[i + 2].Des = u"æc"      # Accusatif
            self.Decl[i + 3].Des = "orum"     # Génitif
            self.Decl[i + 4].Des = "is"       # Datif
            self.Decl[i + 5].Des = "is"       # Ablatif
        
        
        return


    def declinerRelatif(self):
        
        
        self.isMasculine = True
        self.isFeminine = True
        self.isNeutral = True
        
        self.isDeclined = True
        
        # ----------------------------------------------
        # --- Masculin singulier                        
        # ----------------------------------------------
        
        i = 0     # index de départ dans Decl
        
        for n in range(6):     # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = "qu"
        
        self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
        self.Decl[i + 3].Rac = "cu"     # Génitif
        self.Decl[i + 4].Rac = "cu"     # Datif
        
        self.Decl[i + 0].Des = "i"      # Nominatif
        self.Decl[i + 1].Des = ""       # (pas de Vocatif)
        self.Decl[i + 2].Des = "em"     # Accusatif
        self.Decl[i + 3].Des = "jus"    # Génitif
        self.Decl[i + 4].Des = "i"      # Datif
        self.Decl[i + 5].Des = "o"      # Ablatif
        
        # --------------------------------------------
        # --- Féminin singulier                       
        # --------------------------------------------
        
        i = 12    # index de départ dans Decl
        
        for n in range(6):        # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = "qu"
        
        self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
        self.Decl[i + 3].Rac = "cu"     # Génitif
        self.Decl[i + 4].Rac = "cu"     # Datif
        
        self.Decl[i + 0].Des = "ae"     # Nominatif
        self.Decl[i + 1].Des = ""       # (pas de Vocatif)
        self.Decl[i + 2].Des = "am"     # Accusatif
        self.Decl[i + 3].Des = "jus"    # Génitif
        self.Decl[i + 4].Des = "i"      # Datif
        self.Decl[i + 5].Des = "a"      # Ablatif
        
        
        # --------------------------------------------
        # --- Neutre singulier                        
        # --------------------------------------------
        
        i = 24    # index de départ dans Decl
        
        for n in range(6):        # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = "qu"
        
        self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
        self.Decl[i + 3].Rac = "cu"     # Génitif
        self.Decl[i + 4].Rac = "cu"     # Datif
        
        self.Decl[i + 0].Des = "od"     # Nominatif
        self.Decl[i + 1].Des = ""       # (pas de Vocatif)
        self.Decl[i + 2].Des = "od"     # Accusatif
        self.Decl[i + 3].Des = "jus"   # Génitif
        self.Decl[i + 4].Des = "i"    # Datif
        self.Decl[i + 5].Des = "o"     # Ablatif
        
        
        # -------------------------------------------
        # --- Masculin pluriel                       
        # -------------------------------------------
        
        i = 6     # index de départ dans Decl
        
        for n in range(6):        # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = "qu"
        
        self.Decl[i + 1].Rac = ""         # (pas de Vocatif)
        
        self.Decl[i + 0].Des = "i"        # Nominatif
        self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
        self.Decl[i + 2].Des = "os"       # Accusatif
        self.Decl[i + 3].Des = "orum"     # Génitif
        self.Decl[i + 4].Des = "ibus"     # Datif
        self.Decl[i + 5].Des = "ibus"     # Ablatif
        
        # -----------------------------------------
        # --- Feminin pluriel                      
        # -----------------------------------------
        
        i = 18    # index de départ dans Decl
        
        for n in range(6):        # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = "qu"
        
        
        self.Decl[i + 1].Rac = ""         # (pas de Vocatif)
        
        self.Decl[i + 0].Des = u"æ"       # Nominatif
        self.Decl[i + 1].Des = ""         # (pas de Vocatif)
        self.Decl[i + 2].Des = "as"       # Accusatif
        self.Decl[i + 3].Des = "arum"     # Génitif
        self.Decl[i + 4].Des = "ibus"     # Datif
        self.Decl[i + 5].Des = "ibus"     # Ablatif
        
        # -----------------------------------------
        # --- Neutre pluriel                       
        # -----------------------------------------
        
        i = 30    # index de départ dans Decl
        
        for n in range(6):        # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = "qu"
        
        
        self.Decl[i + 1].Rac = ""       # (pas de Vocatif)
        
        self.Decl[i + 0].Des = u"æ"     # Nominatif
        self.Decl[i + 1].Des = ""       # (pas de Vocatif)
        self.Decl[i + 2].Des = u"æ"     # Accusatif
        self.Decl[i + 3].Des = "orum"   # Génitif
        self.Decl[i + 4].Des = "ibus"   # Datif
        self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        
        return
        
        
        
        
        

    def DeclinerNumeral(self, Radic, d):
        
        Radic = Radic.encode('utf-8')
        
        if d == "": return
        
        i = 0
        n = 0
        # ------------
        
        self.isMasculine = True
        self.isFeminine = True
        self.isNeutral = True
        
        self.isDeclined = True
        
        if d == "num1": # =================================================
        
            # ----------------------------------------------
            # --- Masculin singulier                        
            # ----------------------------------------------
            
            i = 0     # index de départ dans Decl
            
            for n in range(6):     # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
                
            
            self.Decl[i + 1].Rac = ""       # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "us"     # Nominatif
            self.Decl[i + 1].Des = ""       # (pas de Vocatif) 
            self.Decl[i + 2].Des = "um"     # Accusatif
            self.Decl[i + 3].Des = "ius"    # Génitif
            self.Decl[i + 4].Des = "i"      # Datif
            self.Decl[i + 5].Des = "o"      # Ablatif
            
            # --------------------------------------------
            # --- Féminin singulier                       
            # --------------------------------------------
            
            i = 12    # index de départ dans l'Array Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""       # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "a"      # Nominatif
            self.Decl[i + 1].Des = ""       # (pas de Vocatif) 
            self.Decl[i + 2].Des = "am"     # Accusatif
            self.Decl[i + 3].Des = "ius"    # Génitif
            self.Decl[i + 4].Des = "i"      # Datif
            self.Decl[i + 5].Des = "a"      # Ablatif
            
            
            # --------------------------------------------
            # --- Neutre singulier                        
            # --------------------------------------------
            
            i = 24    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""       # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "um"     # Nominatif
            self.Decl[i + 1].Des = ""       # (pas de Vocatif) 
            self.Decl[i + 2].Des = "um"     # Accusatif
            self.Decl[i + 3].Des = "ius"    # Génitif
            self.Decl[i + 4].Des = "i"      # Datif
            self.Decl[i + 5].Des = "o"      # Ablatif
            
            
            # -------------------------------------------
            # --- Masculin pluriel                       
            # -------------------------------------------
            
            i = 6     # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "i"        # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "os"       # Accusatif
            self.Decl[i + 3].Des = "orum"     # Génitif
            self.Decl[i + 4].Des = "is"       # Datif
            self.Decl[i + 5].Des = "is"       # Ablatif
            
            # -----------------------------------------
            # --- Feminin pluriel                      
            # -----------------------------------------
            
            i = 18    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = u"æ"       # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "as"       # Accusatif
            self.Decl[i + 3].Des = "arum"     # Génitif
            self.Decl[i + 4].Des = "is"       # Datif
            self.Decl[i + 5].Des = "is"       # Ablatif
            
            # -----------------------------------------
            # --- Neutre pluriel                       
            # -----------------------------------------
            
            i = 30    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "a"        # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "a"        # Accusatif
            self.Decl[i + 3].Des = "orum"     # Génitif
            self.Decl[i + 4].Des = "is"       # Datif
            self.Decl[i + 5].Des = "is"       # Ablatif
        
        
        
        elif d == "num2": # ====================================================
        
            # -------------------------------------------
            # --- Masculin pluriel                       
            # -------------------------------------------
            
            i = 6     # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "o"        # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "os/o"   # Accusatif
            self.Decl[i + 3].Des = "orum"     # Génitif
            self.Decl[i + 4].Des = "obus"     # Datif
            self.Decl[i + 5].Des = "obus"     # Ablatif
            
            # ------------------------------------------
            # --- Féminin pluriel                       
            # ------------------------------------------
            
            i = 18    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = u"æ"       # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "as"       # Accusatif
            self.Decl[i + 3].Des = "arum"     # Génitif
            self.Decl[i + 4].Des = "abus"     # Datif
            self.Decl[i + 5].Des = "abus"     # Ablatif
            
            # -----------------------------------------
            # --- Neutre pluriel                       
            # -----------------------------------------
            
            i = 30    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "o"        # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "o"        # Accusatif
            self.Decl[i + 3].Des = "orum"     # Génitif
            self.Decl[i + 4].Des = "obus"     # Datif
            self.Decl[i + 5].Des = "obus"     # Ablatif
        
        
        
        
        
        elif d == "num3": # ============================================
            
            # ----------------------------------------
            # --- Masculin pluriel                    
            # ----------------------------------------
            
            i = 6     # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "es"       # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "es"       # Accusatif
            self.Decl[i + 3].Des = "ium"      # Génitif
            self.Decl[i + 4].Des = "ibus"     # Datif
            self.Decl[i + 5].Des = "ibus"     # Ablatif
            
            # -----------------------------------------
            # --- Féminin pluriel                      
            # -----------------------------------------
            
            i = 18    # index de départ dans l'Array Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "es"       # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "es"       # Accusatif
            self.Decl[i + 3].Des = "ium"      # Génitif
            self.Decl[i + 4].Des = "ibus"     # Datif
            self.Decl[i + 5].Des = "ibus"     # Ablatif
            
            # ----------------------------------------
            # --- Neutre pluriel                      
            # ----------------------------------------
            
            i = 30    # index de départ dans Decl
            
            for n in range(6):        # (0 To 5) racine par défaut (= radical)
                self.Decl[i + n].Rac = Radic
            
            
            self.Decl[i + 1].Rac = ""         # (pas de Vocatif) 
            
            self.Decl[i + 0].Des = "ia"       # Nominatif
            self.Decl[i + 1].Des = ""         # (pas de Vocatif) 
            self.Decl[i + 2].Des = "ia"       # Accusatif
            self.Decl[i + 3].Des = "ium"      # Génitif
            self.Decl[i + 4].Des = "ibus"     # Datif
            self.Decl[i + 5].Des = "ibus"     # Ablatif
        
        
        else:
            self.isDeclined = False
        
        
        return
    


    def DeclinerSubstantif(self, Radic, d):
        u"""
        Décline le substantif de radical 'Radic' suivant la décinaison 'd'
        """
        
        Radic = Radic.encode('utf-8')
        
        if d == "": return
        
        i = 0
        flagGenreConnu = False
        # -------------
        
        # =======================================================================
        if self.isMasculine:        # === Masculin                               
        # =======================================================================
            
            flagGenreConnu = True
            
            if self.isSingular:  # --- singulier
                i = 0
                self.DeclinerSubstantif_Singulier(Radic, d, i)
            
            
            if self.isPlural:    # --- pluriel
                i = 6
                self.Declinersubstantif_Pluriel(Radic, d, i)
        
        
        
        
        # =======================================================================
        if self.isFeminine:         # === Féminin                                
        # =======================================================================
            
            flagGenreConnu = True
            
            if self.isSingular:  # --- singulier
                i = 12
                self.DeclinerSubstantif_Singulier(Radic, d, i)
            
            
            if self.isPlural:    # --- pluriel
                i = 18
                self.Declinersubstantif_Pluriel(Radic, d, i)
        
        
        
        
        # ========================================================================
        if self.isNeutral:          # === Neutre                                  
        # ========================================================================
        
            flagGenreConnu = True
            
            if self.isSingular:  # --- singulier
                i = 24
                self.DeclinerSubstantif_Singulier(Radic, d, i)
            
            
            if self.isPlural:    # --- pluriel
                i = 30
                self.Declinersubstantif_Pluriel(Radic, d, i)
        
        
        
        
        # ===========================================================================
        if flagGenreConnu == False:  # genre non précisé > remplir comme masculin    
        # ===========================================================================
            
            if self.isSingular:  # --- singulier
                i = 0
                self.DeclinerSubstantif_Singulier(Radic, d, i)
            
            
            if self.isPlural:    # --- pluriel
                i = 6
                self.Declinersubstantif_Pluriel(Radic, d, i)
        
        
        return



    def Declinersubstantif_Pluriel(self, Radic, d, i):

        u"""
        (sous-routine de DeclinerSubstantif)
        le paramètre i est l'index de départ dans Decl
        """
        
        self.isDeclined = True
        
        for n in range(6):     # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = Radic
        
        # --- 1ère déclinaison
        
        if d in ("1", "1e", "1ae"):
            self.Decl[i + 0].Des = u"æ"     # Nominatif
            self.Decl[i + 1].Des = u"æ"     # Vocatif
            self.Decl[i + 2].Des = "as"     # Accusatif
            self.Decl[i + 3].Des = "arum"   # Génitif
            self.Decl[i + 4].Des = "is"     # Datif
            self.Decl[i + 5].Des = "is"     # Ablatif
        
        # --- 2ème déclinaison
        
        elif d == "2_mf":
            self.Decl[i + 0].Des = "i"      # Nominatif
            self.Decl[i + 1].Des = "i"      # Vocatif
            self.Decl[i + 2].Des = "os"     # Accusatif
            self.Decl[i + 3].Des = "orum"   # Génitif
            self.Decl[i + 4].Des = "is"     # Datif
            self.Decl[i + 5].Des = "is"     # Ablatif
        
        elif d == "2_n":
            self.Decl[i + 0].Des = "a"      # Nominatif
            self.Decl[i + 1].Des = "a"      # Vocatif
            self.Decl[i + 2].Des = "a"      # Accusatif
            self.Decl[i + 3].Des = "orum"   # Génitif
            self.Decl[i + 4].Des = "is"     # Datif
            self.Decl[i + 5].Des = "is"     # Ablatif
        
        elif d in ("2r1", "2r2"):
            self.Decl[i + 0].Des = "i"      # Nominatif
            self.Decl[i + 1].Des = "i"      # Vocatif
            self.Decl[i + 2].Des = "os"     # Accusatif
            self.Decl[i + 3].Des = "orum"   # Génitif
            self.Decl[i + 4].Des = "is"     # Datif
            self.Decl[i + 5].Des = "is"     # Ablatif
        
        elif d == "2on":
            self.Decl[i + 0].Des = "a"      # Nominatif
            self.Decl[i + 1].Des = "a"      # Vocatif
            self.Decl[i + 2].Des = "a"      # Accusatif
            self.Decl[i + 3].Des = "orum"   # Génitif
            self.Decl[i + 4].Des = "is"     # Datif
            self.Decl[i + 5].Des = "is"     # Ablatif
        
        # --- 3ème déclinaison
        
        elif d in ("3p_mf", "3pg", "3ns1", "3ns2"):
            self.Decl[i + 0].Des = "es"     # Nominatif
            self.Decl[i + 1].Des = "es"     # Vocatif
            self.Decl[i + 2].Des = "es"     # Accusatif
            self.Decl[i + 3].Des = "ium"    # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        elif d == "3p_n":
            self.Decl[i + 0].Des = "ia"     # Nominatif
            self.Decl[i + 1].Des = "ia"     # Vocatif
            self.Decl[i + 2].Des = "ia"     # Accusatif
            self.Decl[i + 3].Des = "ium"    # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        elif d in ("3a", "3en", "3er1", "3us1", "3us2"):
            self.Decl[i + 0].Des = "a"      # Nominatif
            self.Decl[i + 1].Des = "a"      # Vocatif
            self.Decl[i + 2].Des = "a"      # Accusatif
            self.Decl[i + 3].Des = "um"     # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        elif d in ("3on", "3o1", "3o2", "3er2", "3or", "3as", "3es1", "3es2", "3is", "3isg", "3os", "3ax", "3ex", "3ix", "3s"):
            self.Decl[i + 0].Des = "es"     # Nominatif
            self.Decl[i + 1].Des = "es"     # Vocatif
            self.Decl[i + 2].Des = "es"     # Accusatif
            self.Decl[i + 3].Des = "um"     # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        elif d == "3ar":
            self.Decl[i + 0].Des = "ia"     # Nominatif
            self.Decl[i + 1].Des = "ia"     # Vocatif
            self.Decl[i + 2].Des = "ia"     # Accusatif
            self.Decl[i + 3].Des = "ium"    # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        # --- 4ème déclinaison
        
        elif d == "4_mf":
            self.Decl[i + 0].Des = "us"     # Nominatif
            self.Decl[i + 1].Des = "us"     # Vocatif
            self.Decl[i + 2].Des = "us"     # Accusatif
            self.Decl[i + 3].Des = "uum"    # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        elif d == "4_n":
            self.Decl[i + 0].Des = "ua"     # Nominatif
            self.Decl[i + 1].Des = "ua"     # Vocatif
            self.Decl[i + 2].Des = "ua"     # Accusatif
            self.Decl[i + 3].Des = "uum"    # Génitif
            self.Decl[i + 4].Des = "ibus"   # Datif
            self.Decl[i + 5].Des = "ibus"   # Ablatif
        
        elif d == "4a":
            self.Decl[i + 0].Des = "us"     # Nominatif
            self.Decl[i + 1].Des = "us"     # Vocatif
            self.Decl[i + 2].Des = "us"     # Accusatif
            self.Decl[i + 3].Des = "uum"    # Génitif
            self.Decl[i + 4].Des = "ubus"   # Datif
            self.Decl[i + 5].Des = "ubus"   # Ablatif
        
        # --- 5ème déclinaison
        
        elif d == "5":
            self.Decl[i + 0].Des = "es"     # Nominatif
            self.Decl[i + 1].Des = "es"     # Vocatif
            self.Decl[i + 2].Des = "es"     # Accusatif
            self.Decl[i + 3].Des = "erum"   # Génitif
            self.Decl[i + 4].Des = "ebus"   # Datif
            self.Decl[i + 5].Des = "ebus"   # Ablatif
        
        # ---
        
        else:
            self.isDeclined = False
        
        
        return



    def DeclinerSubstantif_Singulier(self, Radic, d, i):

        u"""
        (sous-routine de DeclinerSubstantif)
        le paramètre i est l'index de départ dans Decl
        """
        
        self.isDeclined = True
        
        for n in range(6):     # (0 To 5) racine par défaut (= radical)
            self.Decl[i + n].Rac = Radic
        
        if d == "1":
            self.Decl[i + 0].Des = "a"        # Nominatif
            self.Decl[i + 1].Des = "a"        # Vocatif
            self.Decl[i + 2].Des = "am"       # Accusatif
            self.Decl[i + 3].Des = u"æ"       # Génitif
            self.Decl[i + 4].Des = u"æ"       # Datif
            self.Decl[i + 5].Des = "a"        # Ablatif
        
        elif d == "1e":
            self.Decl[i + 0].Des = "a/e"      # Nominatif
            self.Decl[i + 1].Des = "..."      # Vocatif
            self.Decl[i + 2].Des = "en"       # Accusatif
            self.Decl[i + 3].Des = "es"       # Génitif
            self.Decl[i + 4].Des = u"æ"       # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "1ae":
            self.Decl[i + 0].Des = "a"        # Nominatif
            self.Decl[i + 1].Des = "a"        # Vocatif
            self.Decl[i + 2].Des = "am"       # Accusatif
            self.Decl[i + 3].Des = u"æ"       # Génitif
            self.Decl[i + 4].Des = u"æ"       # Datif
            self.Decl[i + 5].Des = "e/a"      # Ablatif
        
        # --- 2ème déclinaison
        
        elif d == "2_mf":
            self.Decl[i + 0].Des = "us"       # Nominatif
            self.Decl[i + 1].Des = "e"        # Vocatif
            self.Decl[i + 2].Des = "um"       # Accusatif
            self.Decl[i + 3].Des = "i"        # Génitif
            self.Decl[i + 4].Des = "o"        # Datif
            self.Decl[i + 5].Des = "o"        # Ablatif
        
        elif d == "2_n":
            self.Decl[i + 0].Des = "um"       # Nominatif
            self.Decl[i + 1].Des = "um"       # Vocatif
            self.Decl[i + 2].Des = "um"       # Accusatif
            self.Decl[i + 3].Des = "i"        # Génitif
            self.Decl[i + 4].Des = "o"        # Datif
            self.Decl[i + 5].Des = "o"        # Ablatif
        
        elif d == "2r1":
            self.Decl[i + 0].Rac = Radic[0:-1] + "er" # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] + "er" # Vocatif
            
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = "um"       # Accusatif
            self.Decl[i + 3].Des = "i"        # Génitif
            self.Decl[i + 4].Des = "o"        # Datif
            self.Decl[i + 5].Des = "o"        # Ablatif
        
        elif d == "2r2":
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = "um"       # Accusatif
            self.Decl[i + 3].Des = "i"        # Génitif
            self.Decl[i + 4].Des = "o"        # Datif
            self.Decl[i + 5].Des = "o"        # Ablatif
        
        elif d == "2on":
            self.Decl[i + 0].Des = "on"       # Nominatif
            self.Decl[i + 1].Des = "on"       # Vocatif
            self.Decl[i + 2].Des = "on"       # Accusatif
            self.Decl[i + 3].Des = "i"        # Génitif
            self.Decl[i + 4].Des = "o"        # Datif
            self.Decl[i + 5].Des = "o"        # Ablatif
        
        # --- 3ème déclinaison
        
        elif d == "3p_mf":
            self.Decl[i + 0].Des = "is"       # Nominatif
            self.Decl[i + 1].Des = "is"       # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3p_n":
            self.Decl[i + 0].Des = "e"        # Nominatif
            self.Decl[i + 1].Des = "e"        # Vocatif
            self.Decl[i + 2].Des = "e"        # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "i"        # Ablatif
        
        elif d == "3pg":
            self.Decl[i + 0].Des = "is"       # Nominatif
            self.Decl[i + 1].Des = "is"       # Vocatif
            self.Decl[i + 2].Des = "in/im/em" # Accusatif
            self.Decl[i + 3].Des = "is/eos"   # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "i/e"      # Ablatif
        
        elif d == "3a":
            self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
            self.Decl[i + 2].Rac = Radic[0:-1] # Accusatif
            
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = ""         # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3en":
            self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
            self.Decl[i + 2].Rac = Radic[0:-2] # Accusatif
            
            self.Decl[i + 0].Des = "en"       # Nominatif
            self.Decl[i + 1].Des = "en"       # Vocatif
            self.Decl[i + 2].Des = "en"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d in ("3on", "3or", "3er2"):
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3o1":
            self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
            
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3o2":
            self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
            
            self.Decl[i + 0].Des = "o"        # Nominatif
            self.Decl[i + 1].Des = "o"        # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3ar":
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = ""         # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "i"        # Ablatif
        
        elif d == "3er1":
            self.Decl[i + 0].Des = ""         # Nominatif
            self.Decl[i + 1].Des = ""         # Vocatif
            self.Decl[i + 2].Des = ""         # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d in ("3as", "3es1", "3is", "3ns1", "3ns2", "3os"):
            self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
            
            self.Decl[i + 0].Des = "s"        # Nominatif
            self.Decl[i + 1].Des = "s"        # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d in ("3es2"):
            self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
            
            self.Decl[i + 0].Des = "es"        # Nominatif
            self.Decl[i + 1].Des = "es"        # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d in ("3isg"):
            self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
            self.Decl[i + 2].Rac = Radic[0:-1] # Accusatif
            
            self.Decl[i + 0].Des = "s"        # Nominatif
            self.Decl[i + 1].Des = "s"        # Vocatif
            self.Decl[i + 2].Des = "n/m"      # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d in ("3us1", "3us2"):
            self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
            self.Decl[i + 2].Rac = Radic[0:-2] # Accusatif
            
            self.Decl[i + 0].Des = "us"       # Nominatif
            self.Decl[i + 1].Des = "us"       # Vocatif
            self.Decl[i + 2].Des = "us"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d in ("3ax", "3ix"):
            self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
            
            self.Decl[i + 0].Des = "x"        # Nominatif
            self.Decl[i + 1].Des = "x"        # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3ex":
            self.Decl[i + 0].Rac = Radic[0:-2] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-2] # Vocatif
            
            self.Decl[i + 0].Des = "ex"       # Nominatif
            self.Decl[i + 1].Des = "ex"       # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        elif d == "3s":
            self.Decl[i + 0].Rac = Radic[0:-1] # Nominatif
            self.Decl[i + 1].Rac = Radic[0:-1] # Vocatif
            
            self.Decl[i + 0].Des = "s"        # Nominatif
            self.Decl[i + 1].Des = "s"        # Vocatif
            self.Decl[i + 2].Des = "em"       # Accusatif
            self.Decl[i + 3].Des = "is"       # Génitif
            self.Decl[i + 4].Des = "i"        # Datif
            self.Decl[i + 5].Des = "e"        # Ablatif
        
        # --- 4ème déclinaison
        
        elif d in ("4_mf", "4a"):
            self.Decl[i + 0].Des = "us"       # Nominatif
            self.Decl[i + 1].Des = "us"       # Vocatif
            self.Decl[i + 2].Des = "um"       # Accusatif
            self.Decl[i + 3].Des = "us"       # Génitif
            self.Decl[i + 4].Des = "ui"       # Datif
            self.Decl[i + 5].Des = "u"        # Ablatif
        
        elif d == "4_n":
            self.Decl[i + 0].Des = "u"        # Nominatif
            self.Decl[i + 1].Des = "u"        # Vocatif
            self.Decl[i + 2].Des = "u"        # Accusatif
            self.Decl[i + 3].Des = "us"       # Génitif
            self.Decl[i + 4].Des = "ui"       # Datif
            self.Decl[i + 5].Des = "u"        # Ablatif
        
        
        # --- 5ème déclinaison
        
        elif d == "5":
            self.Decl[i + 0].Des = "es"        # Nominatif
            self.Decl[i + 1].Des = "es"        # Vocatif
            self.Decl[i + 2].Des = "em"        # Accusatif
            self.Decl[i + 3].Des = "ei"        # Génitif
            self.Decl[i + 4].Des = "ei"        # Datif
            self.Decl[i + 5].Des = "e"         # Ablatif
        
        # ---
        
        else:
            self.isDeclined = False
        
        
        return



    def __definirDeclinaison(self, item): #(Private)
        
        u"""
        Analyse du code grammatical pour définir le type de déclinaison/conjugaison à appliquer
        puis les méthodes de déclinaison/conjugaison sont appelées et la liste correspondante est complétée
        
        Cette méthode est invoquée en fin d'__init__
        """
        
        p1=0
        p2=0
        idGram = []
        Radic = ""
        
        
        # ===========================================================
        # === Initialiser les données de sortie de la classe         
        # ===========================================================
        # Decl : pyListe des résultats de déclinaison (indices 0-35) 
        # Conj : pyListe des résultats de conjuguaison (indices 0-11)
        # 2 listes d'éléments vides au départ                        
        
        i=0
        for i in range(36): self.Decl.append(MotCas())
        for i in range(12): self.Conj.append(MotCas())
        
        
        # =====================================================
        
        
        item = item.strip()
        
        
        # === Reconnaître une entrée hors-contexte à ne pas traiter
        #     (les items commençant par '#' ne sont pas traités, simples commentaires dans le dico)
        if item == "" or item[1] == "#":
            self.isRem = True
            self.isDeclNone = True # indéclinable
            return
        
        
        
        # ==============================================================================
        # === Extraire la chaine d'identification grammaticale (contenue entre crochets)
        # ==============================================================================
        
        p1 = item.find("[")
        p2 = item.find("]")
        
        
        if p1 > 0:      # une chaîne entre crochets est présente
            
            if p2 < p1 : p2 = len(item) # si les crochets ne sont pas fermés
            
            idGram = item[p1+1 : p2].strip().split() # convertir en pyListe
        
        else: # absence de chaîne entre crochets
            
            self.isDeclUnknown = True # déclinable ou non ???
            
            # >> tenter d'attribuer des données grammaticales et relancer la procédure si possible
            self.AnalyseAutomatique(item)
            return
        
        
        # ================================================================
        # === Définir le type grammatical (parsing du code entre crochet) 
        # ================================================================
        
        # Valeurs si aucun motif n'a été reconnu dans le code grammatical
        self.isUnknownStatus = True
        self.GramInfo = "(Statut grammatical non précisable)"
        

        # --- Scan des Items instaurant une chaîne grammaticale (GramInfo)  
        
        for it in idGram:
            
            if it == "adj":
                self.isAdjective = True
                self.GramInfo = "Adjectif"
                
            elif it == "s" in idGram:
                self.isSubstantive = True
                self.GramInfo = "Substantif"
                
            elif it == "adv":
                self.isAdverb = True
                self.isDeclNone = True
                self.GramInfo = "Adverbe"
                
            elif it.startswith('suf'): # --- Suffixes
                
                self.isSuffix = True
                
                if (it == "suf-LG") or (it == "suf-GL"):
                    self.isFromGreek = True
                    self.isFromLatin = True
                    self.GramInfo = "Suffixe ou racine suffixée (dans les composés à racines latines ou grecques)"
                    
                elif it == "suf-L":
                    self.isFromLatin = True
                    self.GramInfo = "Suffixe ou racine suffixée (dans les composés à racines latines)"
                    
                elif it == "suf-G":
                    self.isFromGreek = True
                    self.GramInfo = "Suffixe ou racine suffixée (dans les composés à racines grecques)"
                    
                elif it == "suf":
                    self.GramInfo = "Suffixe ou racine suffixée"
                
            elif it.startswith('prf'): # --- Préfixes
                
                self.isPrefix = True
                self.isDeclNone = True
                
                if (it == "prf-LG") or (it == "prf-GL"):
                    self.isFromGreek = True
                    self.isFromLatin = True
                    self.GramInfo = "Préfixe ou racine préfixée (dans les composés à racines latines ou grecques)"
                    
                elif it == "prf-L":
                    self.isFromLatin = True
                    self.GramInfo = "Préfixe ou racine préfixée (dans les composés à racines latines)"
                    
                elif it == "prf-G":
                    self.isFromGreek = True
                    self.GramInfo = "Préfixe ou racine préfixée (dans les composés à racines grecques)"
                    
                elif it == "prf":
                    self.GramInfo = "Préfixe ou racine préfixée"
                
                
            elif it == "s-adj":
                self.isSubstantive = True
                self.isAdjective = True
                self.GramInfo = "Substantif utilisé adjectivement"
                
            elif it.startswith('cmp'): # --- Comparatifs
                
                self.isComparative = True
                
                if it == "cmp":
                    self.GramInfo = "Adjectif comparatif de supériorité"
                elif it == "cmp-i":
                    self.GramInfo = "Adjectif comparatif de supériorité (déclinaison spéciale)"
                
            elif it == "sup":
                self.isSuperlative = True
                self.GramInfo = "Adjectif superlatif"
                
            elif it == "conj":
                self.isConjunction = True
                self.isDeclNone = True
                self.GramInfo = "Conjonction"
                
            elif it == "dem":
                self.isDemonstrative = True
                self.GramInfo = "Pronom-adjectif démonstratif"
                
            elif it.startswith('prep'): # --- Prépositions
                
                self.isPreposition = True
                
                if it == "prep+ab":
                    self.isWithAblative = True
                    self.isDeclNone = True
                    self.GramInfo = "Préposition (+ ablatif)"
                    
                elif it == "prep+ac":
                    self.isWithAccusative = True
                    self.isDeclNone = True
                    self.GramInfo = "Préposition (+ accusatif)"
                    
                elif it == "prep+ac/ab" or it == "prep+ab/ac":
                    self.isWithAccusative = True
                    self.isWithAblative = True
                    self.isDeclNone = True
                    self.GramInfo = "Préposition (+ accusatif ou ablatif)"
                    
                elif it == "prep":
                    self.isDeclNone = True
                    self.GramInfo = "Préposition"
                
            elif it.startswith("v"):
                self.isVerb = True
                self.isDeclNone = True
                self.GramInfo = "Verbe"
                
            elif it.startswith("num"):
                self.isNumeral = True
                self.GramInfo = "Expression numérique"
                
            elif it == "symb":
                self.isSymbol = True
                self.isDeclNone = True
                self.GramInfo = "(Symbole)"
                
            elif it == "loc":
                self.isLocution = True
                self.toNotDecl = True  # ne pas décliner
                self.GramInfo = "Locution ou formule consacrée"
                
            elif it == "rel":
                self.isRelative = True
                self.GramInfo = "Pronom-adjectif relatif"    
           
        
        # --- Scan des Items complétant la chaîne grammaticale
        
        for it in idGram:
            
            if it.startswith("1"):
                self.isDecl1 = True
                self.GramInfo += " 1ère déclinaison"
                
            elif it.startswith("2"):
                self.isDecl2 = True
                self.GramInfo += " 2ème déclinaison"
                
            elif it.startswith("3"):
                self.isDecl3 = True
                self.GramInfo += " 3ème déclinaison"
                
            elif it.startswith("4"):
                self.isDecl4 = True
                self.GramInfo += " 4ème déclinaison"
                
            elif it.startswith("5"):
                self.isDecl5 = True
                self.GramInfo += " 5ème déclinaison"
                
            elif it.startswith("A"):
                self.isGroupA = True
                self.GramInfo += " 1er groupe"
                
            elif it.startswith("B"):
                self.isGroupB = True
                self.GramInfo += " 2ème groupe"
                
            elif it.startswith("C"):
                self.isGroupC = True
                self.GramInfo += " 2ème groupe ('C')"
        
        
        # --- Items du genre
        
        if ( ("m" in idGram) and ("f" in idGram) ) or ("fm" in idGram) or ("mf" in idGram):
            self.isMasculine = True
            self.isFeminine = True
            self.GramInfo += " masculin et féminin"
        
        elif "m" in idGram:
            self.isMasculine = True
            self.GramInfo = self.GramInfo + " masculin"
        
        elif "f" in idGram:
            self.isFeminine = True
            self.GramInfo += " féminin"
        
        elif "n" in idGram:
            self.isNeutral = True
            self.GramInfo += " neutre"
        
        
        # --- Items du Nombre
        
        if "pl" in idGram:          # utilisé (décliné) au pluriel seul
            self.isPlural = True
            self.GramInfo += " pluriel"
        
        elif "sg" in idGram:        # utilisé (décliné) au singulier seul
            self.isSingular = True
            self.GramInfo += " singulier"
        
        else:                       # par défaut : utilisé (décliné) au singulier et pluriel
            self.isSingular = True
            self.isPlural = True
        
        
        # --- Items cloturant la chaîne grammaticale
        
        if "abr" in idGram:
            self.isAbbreviation = True
            self.isDeclNone = True
            self.GramInfo += "(abréviation)"
        
        
        # === Forcer l'indéclinabilité réelle ===
        
        if "indecl" in idGram:
            self.isDeclNone = True
            self.GramInfo += " (expression indéclinable)"
        
        
        # ================================================================
        # === Extraire le mot de base (= 1er mot avec sa désinence)       
        # ================================================================

        self.__MotBase = item
        
        n = item.find("/")
        if n > 0:
            self.__MotBase = item[0:n]
        else:
            n = item.find(" ")
            if n > 0:
                self.__MotBase = item[0:n]
            else:
                n = item.find("[")
                if n > 0:
                    self.__MotBase = item[0:n]
                else:
                    n = item.find("(")
                    if n > 0:
                        self.__MotBase = item[0:n]
        
        
        self.__MotBase = self.__MotBase.strip()
        
        
        # Formatage d'affichage du mot de base des suffixes    
        if self.isSuffix:
            self.__MotBase = "...-" + self.__MotBase
        
        
        
        
        # ===========================================================
        # === Traitements préalables et aiguillage vers              
        # === les modules de déclinaison/conjugaisons                
        # === en fonction du type grammatical                        
        # ===========================================================
        
        
        
        # --------------------------------------------------
        if self.isDemonstrative: # --- Démonstratifs        
        # --------------------------------------------------
            
            self.DeclinerDemonstratif(self.__MotBase)
        
        
        # --------------------------------------------------
        elif self.isVerb: # --- Verbe                       
        # --------------------------------------------------
            
            # --- Transitivité
            if "t" in idGram:
                self.isTransitive = True
                self.isDeclNone = True
                self.GramInfo = self.GramInfo + " transitif"
            elif "i" in idGram:
                self.isIntransitive = True
                self.isDeclNone = True
                self.GramInfo = self.GramInfo + " intransitif"
            elif "ti" in idGram:
                self.isTransitive = True
                self.isIntransitive = True
                self.isDeclNone = True
                self.GramInfo = self.GramInfo + " transitif et intransitif"
            
            # --- Définir conjugaison, extraire radical du présent et infininif
            #    puis conjuguer par défaut au présent indicatif actif)
            
            if "v1" in idGram:
                self.isConj1 = True
                self.curNumConj = "1"
                self.Vradic1 = self.__MotBase[0:-1]             # radical du présent
                self.Vinfinitif = self.Vradic1 + "are"
                self.ExtraireRadicParfSupin(item)
                self.ConjUpdate("Indicatif", "Present")
                self.GramInfo = self.GramInfo + " 1ère conjugaison"
            
            elif "v2" in idGram:
                self.isConj2 = True
                self.curNumConj = "2"
                self.Vradic1 = self.__MotBase[0:-2]             # radical du présent
                self.Vinfinitif = self.Vradic1 + "ere"
                self.ExtraireRadicParfSupin(item)
                self.ConjUpdate("indicatif", "present")
                self.GramInfo = self.GramInfo + " 2ème conjugaison"
            
            elif "v3" in idGram:
                self.isConj3 = True
                self.curNumConj = "3"
                self.Vradic1 = self.__MotBase[0:-1]             # radical du présent
                self.Vinfinitif = self.Vradic1 + "ere"
                self.ExtraireRadicParfSupin(item)
                self.ConjUpdate("indicatif", "present")
                self.GramInfo = self.GramInfo + " 3ème conjugaison"
            
            elif "v4" in idGram:
                self.isConj4 = True
                self.curNumConj = "4"
                self.Vradic1 = self.__MotBase[0:-2]             # radical du présent
                self.Vinfinitif = self.Vradic1 + "ire"
                self.ExtraireRadicParfSupin(item)
                self.ConjUpdate("indicatif", "present")
                self.GramInfo = self.GramInfo + " 4ème conjugaison"
            
            elif "vm" in idGram:
                self.isConjM = True
                self.curNumConj = "m"
                self.Vradic1 = self.__MotBase[0:-2]             # radical du présent
                self.Vinfinitif = self.Vradic1 + "ere"
                self.ExtraireRadicParfSupin(item)
                self.ConjUpdate("indicatif", "present")
                self.GramInfo = self.GramInfo + " conjugaison mixte"
            
            elif "vs" in idGram:       # --- sum et dérivés
                self.isConjSum = True
                self.curNumConj = "s"
                self.Vradic1 = self.__MotBase[0:-3]             # radical du présent
                self.Vradic2 = self.__MotBase[0:-3] + "fu"      # radical du parfait
                self.Vradic3 = "-"                              # radical du supin
                self.Vinfinitif = self.Vradic1 + "esse"
                self.ConjUpdate("indicatif", "present")
                self.GramInfo = self.GramInfo + " ('esse' et dérivés : conjugaison irrégulière)"
            
            elif "vf" in idGram:       # --- fero et dérivés
                self.isConjFero = True
                self.curNumConj = "f"
                self.Vradic1 = self.__MotBase[0:-1]             # radical du présent
                self.ExtraireRadicParfSupin(item)
                self.Vinfinitif = self.Vradic1 + "re"
                self.ConjUpdate("indicatif", "present")
                self.GramInfo = self.GramInfo + " ('ferre' et dérivés : conjugaison irrégulière)"
            
            
            self.Vradic1 = self.Vradic1.encode('utf-8')
            self.Vradic2 = self.Vradic2.encode('utf-8')
            self.Vradic3 = self.Vradic3.encode('utf-8')
            
         
        
        
        # -----------------------------------------------------------------------------------------
        #elif self.isDeclNone or self.toNotDecl: # --- réellement indéclinable ou à ne pas décliner 
        # -----------------------------------------------------------------------------------------
        #   pass
        
        
        
        # -------------------------------------------------------------
        if self.isDecl1: # --- 1ère déclinaison                        
        # -------------------------------------------------------------
            
            # --- racine
            if self.__MotBase.endswith("ae"):       # mots pluriels écrits sans ligature
                Radic = self.__MotBase[0:-2]
            else:
                Radic = self.__MotBase[0:-1]
            
            # --- code de déclinaison
            arg=""
            if "1e" in idGram:
                arg = "1e"
            elif "1ae" in idGram:
                arg = "1ae"
            elif "1-" in idGram:
                self.isDeclUnknown = True
            else:
                arg = "1"
            
            # ---
            self.DeclinerSubstantif(Radic, arg)
        
        
        # ----------------------------------------------------------------
        elif self.isDecl2: # --- 2ème déclinaison                         
        # ----------------------------------------------------------------
            
            arg = ""
            if "2r1" in idGram:
                arg = "2r1"
                Radic = self.__MotBase[0:-2] + "r"
            elif "2r2" in idGram:
                arg = "2r2"
                Radic = self.__MotBase
            elif "2on" in idGram:
                arg = "2on"
                Radic = self.__MotBase[0:-2]
            elif "2-" in idGram:
                self.isDeclUnknown = True
                
            else:
                
                if self.isPlural and not self.isSingular :       # mot au pluriel seul
                    Radic = self.__MotBase[0:-1]
                else:
                    Radic = self.__MotBase[0:-2]
                
                if self.isNeutral:
                    arg = "2_n"
                else:
                    arg = "2_mf"
            
            # ---
            self.DeclinerSubstantif(Radic, arg)
        
        
        # -----------------------------------------------------------------
        elif self.isDecl3: # --- 3ème déclinaison                          
        # -----------------------------------------------------------------
            
            arg=""
            if "3p" in idGram:          # parisyllabiques standards
                
                if self.isNeutral:
                    arg="3p_n"
                    if not self.isSingular:
                        Radic = self.__MotBase[0:-2]
                    else:
                        Radic = self.__MotBase[0:-1]
                else:
                    arg="3p_mf"
                    Radic = self.__MotBase[0:-2]
            
            elif "3pg" in idGram:       # parisyllabiques à déclinaison grécisante
                arg="3pg"
                Radic = self.__MotBase[0:-2]
            
            elif "3en" in idGram:
                arg="3en"
                Radic = self.__MotBase[0:-2] + "in"
            
            elif ("3on" in idGram) or ("3or" in idGram):
                arg="3on"
                Radic = self.__MotBase
            
            elif "3ar" in idGram:
                arg="3ar"
                Radic = self.__MotBase
            
            elif "3er1" in idGram:
                arg="3er1"
                Radic = self.__MotBase
            
            elif "3er2" in idGram:
                arg="3er2"
                Radic = self.__MotBase
            
            elif "3or" in idGram:
                arg="3or"
                Radic = self.__MotBase
            
            elif "3o1" in idGram:
                arg="3o1"
                Radic = self.__MotBase + "n"
            
            elif "3o2" in idGram:
                arg="3o2"
                Radic = self.__MotBase[0:-1] + "in"
            
            elif "3as" in idGram:
                arg="3as"
                Radic = self.__MotBase[0:-1] + "t"
            
            elif "3es1" in idGram:
                arg="3es1"
                Radic = self.__MotBase[0:-1] + "d"
            
            elif "3es2" in idGram:
                arg="3es2"
                Radic = self.__MotBase[0:-2] + "it"
            
            elif "3is" in idGram:
                arg="3is"
                Radic = self.__MotBase[0:-1] + "d"
            
            elif "3isg" in idGram:
                arg="3isg"
                Radic = self.__MotBase[0:-1] + "d"
            
            elif "3ns1" in idGram:
                arg="3ns1"
                Radic = self.__MotBase[0:-1] + "t"
            
            elif "3ns2" in idGram:
                arg="3ns2"
                Radic = self.__MotBase[0:-1] + "d"
            
            elif "3os" in idGram:
                arg="3os"
                Radic = self.__MotBase[0:-1] + "r"
            
            elif "3us1" in idGram:
                arg="3us1"
                Radic = self.__MotBase[0:-2] + "er"
            
            elif "3us2" in idGram:
                arg="3us2"
                Radic = self.__MotBase[0:-2] + "or"
            
            elif "3ax" in idGram:
                arg="3ax"
                Radic = self.__MotBase[0:-1] + "c"
            
            elif "3ix" in idGram:
                arg="3ix"
                Radic = self.__MotBase[0:-1] + "c"
            
            elif "3ex" in idGram:
                arg="3ex"
                Radic = self.__MotBase[0:-2] + "ic"
            
            elif "3a" in idGram:
                arg="3a"
                Radic = self.__MotBase + "t"
            
            elif "3s" in idGram:
                arg="3s"
                Radic = self.__MotBase[0:-1] + "t"
            
            elif "3-" in idGram:
                self.isDeclUnknown = True
            
            # ---
            self.DeclinerSubstantif(Radic, arg)
        
        
        # -------------------------------------------------------------------
        elif self.isDecl4: # --- 4ème déclinaison                            
        # -------------------------------------------------------------------
            
            # --- racine
            if self.__MotBase.endswith("us"):
                Radic = self.__MotBase[0:-2]
            else:
                Radic = self.__MotBase[0:-1]
            
            # --- décliner
              
            arg = ""
            if "4a" in idGram:
                arg = "4a"
            else:
                if self.isNeutral:
                  arg = "4_n"
                else:
                  arg = "4_mf"
            
            # ---
            self.DeclinerSubstantif(Radic, arg)
        
        
        # -------------------------------------------------------------------------
        elif self.isDecl5: # --- 5ème déclinaison                                  
        # -------------------------------------------------------------------------
            
            Radic = self.__MotBase[0:-2]
            arg = "5"
            
            # ---
            self.DeclinerSubstantif(Radic, arg)
        
        
        # ------------------------------------------------------------------------
        elif self.isGroupA: # --- Groupe A                                        
        # ------------------------------------------------------------------------
            
            
            arg = ""
            if "Aa" in idGram:
                arg = "Aa"
                Radic = self.__MotBase
            
            elif "Ab" in idGram:
                arg = "Ab"
                Radic = self.__MotBase[0:-2] + "r"
            
            elif "A-" in idGram:
                self.isDeclUnknown = True
            
            elif "A" in idGram:
                arg = "A"
                
                if (self.__MotBase.endswith(u"æ")) or (self.__MotBase.endswith("i")):
                    Radic = self.__MotBase[0:-1]
                else:
                    Radic = self.__MotBase[0:-2]
            
            # ---
            self.DeclinerAdjectif(Radic, arg)
        
        
        # --------------------------------------------------------------
        elif self.isGroupB: # --- Groupe B                              
        # --------------------------------------------------------------
            
            arg = ""
            if "Bp" in idGram:
                arg = "Bp"
                Radic = self.__MotBase[0:-2]
            
            elif "Bns" in idGram:
                arg = "Bns"
                Radic = self.__MotBase[0:-1] + "t"
            
            elif "Bex" in idGram:
                arg = "Bex"
                Radic = self.__MotBase[0:-2] + "ic"
            
            elif "Ber" in idGram:
                arg = "Ber"
                Radic = self.__MotBase[0:-2] + "r"
            
            elif "Bx" in idGram:
                arg = "Bx"
                Radic = self.__MotBase[0:-1] + "c"
            
            elif "Bor" in idGram:
                arg = "Bor"
                Radic = self.__MotBase
            
            elif "Bus" in idGram:
                arg = "Bus"
                Radic = self.__MotBase[0:-2] + "er"
            
            elif "B-" in idGram:
                self.isDeclUnknown = True
            
            else:
                self.isDeclUnknown = True
            
            # ---
            self.DeclinerAdjectif(Radic, arg)
        
        
        # -------------------------------------------------------------------------
        elif self.isGroupC: # --- Groupe C                                         
        # -------------------------------------------------------------------------
            
            arg = ""
            if "Ci" in idGram:
                arg = "Ci"
                Radic = self.__MotBase[0:-2]
            
            elif "Co" in idGram:
                arg = "Co"
                Radic = self.__MotBase[0:-2]
            
            elif "C-" in idGram:
                self.isDeclUnknown = True
            
            else:
                self.isDeclUnknown = True
                
            # ---
            self.DeclinerAdjectif(Radic, arg)
            
            
        # -------------------------------------------------------------------------
        elif self.isComparative: # --- Comparatif                                  
        # -------------------------------------------------------------------------
            
            arg = ""
            if "cmp-i" in idGram:
                arg= "cmp-i"
                Radic = self.__MotBase[0:-2]
                
            else:
                arg = "cmp"
                Radic = self.__MotBase[0:-2]
            
            # ---
            self.DeclinerAdjectif(Radic, arg)
            
            
        # -------------------------------------------------------------------------
        elif self.isNumeral: # ---- Numéral                                        
        # -------------------------------------------------------------------------
            
            arg = ""
            if "num1" in idGram:
                arg = "num1"
                Radic = self.__MotBase[0:-2]
                self.GramInfo += " (basé sur 'unus')"
            
            elif "num2" in idGram:
                arg = "num2"
                Radic = self.__MotBase[0:-1]
                self.GramInfo += " (basé sur 'duo')"
            
            elif "num3" in idGram:
                arg = "num3"
                Radic = self.__MotBase[0:-2]
                self.GramInfo += " (basé sur 'tres')"
            
            elif self.isDeclNone:
                pass
            
            else:
                self.isDeclUnknown = True
            
            self.DeclinerNumeral(Radic, arg)
            
            
        # -------------------------------------------------------------------------
        elif self.isRelative: # ---- Pronom relatif                                
        # -------------------------------------------------------------------------
            
            self.declinerRelatif()
            
        # ---------------------------------------------------------------------------
        else: # --- Aucune déclinaison n'a été trouvée                               
        # ---------------------------------------------------------------------------
            
            self.isDeclUnknown = True
        
        return



    def ExtraireRadicParfSupin(self, item):

        u"""
        Extraction du radical du parfait/supin d'un verbe
        """
        
        n = 0
        p1 = 0
        p2 = 0
        ParfAbr = ""
        SupAbr =""
        # --------
        
        # Principe de l'extraction :
        #    faire concorder la première lettre du radical abrégé
        #    avec sa dernière occurrence dans le radical du présent
        
        
        # --- cas particulier : 1ère déclinaison ---
        if self.curNumConj == "1":
            
            self.Vradic2 = self.Vradic1 + "av"
            self.Vradic3 = self.Vradic1 + "at"
                
            if "/-/" in item:                 # parfait défectif
                self.Vradic2 = "-"
                
                
            if ("/- " in item) or ("/-[" in item):
                self.Vradic3 = "-"
                
            return
        
        
        
        # --- extraire le radical abrégé du parfait
        
        for n in range(2):  # (1 To 2)
            p1 = item.find("/", p1 + 1)     # cherche le 2ème '/'
        
        
        p2 = item.find("/", p1 + 1)
        
        ParfAbr = item[p1 + 1 : p2 - 1] 	# nb: ote le i "final"
        
        
        if ParfAbr == "":                   # parfait défectif
            ParfAbr = "-"
        
        
        # --- extraire le radical abrégé du supin
        
        p1 = p2
        p2 = item.find("um", p1)
        
        if p2 > 0:
            SupAbr = item[p1 + 1 : p2]
        else:
          SupAbr = "-"                      # supin défectif
        
        
        
        # --- coller pour reconstituer le radical du parfait
        
        p1 = -1
        p2 = 0
        
        while 1:
            p1 = self.Vradic1.find(ParfAbr[0], p1 + 1)
            if p1 < 0 : break
            p2 = p1
        
        
        if p2 > 0:
            self.Vradic2 = self.Vradic1[0:p2] + ParfAbr
        else:
            self.Vradic2 = ParfAbr
        
        
        # --- coller pour reconstituer le radical du supin
        
        p1 = -1
        p2 = 0
        
        while 1:
            p1 = self.Vradic1.find(SupAbr[0], p1 + 1)
            if p1 < 0 : break
            p2 = p1
        
        
        if p2 > 0:
            self.Vradic3 = self.Vradic1[0:p2]  + SupAbr
        else:
            self.Vradic3 = SupAbr


    

class ListFlex():
    
    u"""
    Classe générant un pyDictionnaire des formes fléchies et conjuguées (en minuscules)
    à partir d'une liste d'items (mots + code grammaticaux) : 'lstsource'
    retour en utf-8
    """
    
    def __init__(self, lstsource, dicfile, lstflxpath, labprogr=None):
        
        u"""
        Paramètres :
          - 'dicfile'     : l'objet fichier du dictionnaire
          - 'lstflxpath'  : chemin du fichier des flexion (fichier à créer ou mettre à jour)
          - 'labprogr'    : référence facultative à Label affichant la progression (en pourcentage)
        """
        
        
        listflexpath = lstflxpath 
        
        
        self.listflex={} # pyDictionnaire qui contiendra la liste des mots fléchis
        
        # Tuple miroir du tableau de déclinaison, contenant les abbrév. des cas/genre/nombre
        infoflexdecl=("Nms","Vms","Ams","Gms","Dms","Bms",
                      "Nmp","Vmp","Amp","Gmp","Dmp","Bmp",
                      "Nfs","Vfs","Afs","Gfs","Dfs","Bfs",
                      "Nfp","Vfp","Afp","Gfp","Dfp","Bfp",
                      "Nns","Vns","Ans","Gns","Dns","Bns",
                      "Nnp","Vnp","Anp","Gnp","Dnp","Bnp")
        # Tuple miroir du tableau de conjugaison, contenant les les abbrév. pour l'Indicatif Présent
        infoflexconjIP=("IPa1s","IPa2s","IPa3s","IPa1p","IPa2p","IPa3p",
                         "IPz1s","IPz2s","IPz3s","IPz1p","IPz2p","IPz3p")
        # Tuple miroir du tableau de conjugaison, contenant les les abbrév. pour l'Indicatif Imparfait
        infoflexconjIM=("IMa1s","IMa2s","IMa3s","IMa1p","IMa2p","IMa3p",
                         "IMz1s","IMz2s","IMz3s","IMz1p","IMz2p","IMz3p")
        # Tuple miroir du tableau de conjugaison, contenant les les abbrév. pour l'Indicatif Futur
        infoflexconjIF=("IFa1s","IFa2s","IFa3s","IFa1p","IFa2p","IFa3p",
                         "IFz1s","IFz2s","IFz3s","IFz1p","IFz2p","IFz3p")
        # Tuple miroir du tableau de conjugaison, contenant les les abbrév. pour le Subjonctif Présent
        infoflexconjSP=("SPa1s","SPa2s","SPa3s","SPa1p","SPa2p","SPa3p",
                         "SPz1s","SPz2s","SPz3s","SPz1p","SPz2p","SPz3p")
        # Tuple miroir du tableau de conjugaison, contenant les les abbrév. pour le Subjonctif Imparfait
        infoflexconjSM=("SMa1s","SMa2s","SMa3s","SMa1p","SMa2p","SMa3p",
                         "SMz1s","SMz2s","SMz3s","SMz1p","SMz2p","SMz3p")
        
        i = -1
        lenSource = len(lstsource)
        pourcent = 0
        
        unlig = lib.mytools.unlig # (fonction convertissant les ligatures en caractères séparés)
        
        for itemsource in lstsource:
        # On scanne chaque mot de la liste du dictionnaire
        # et on l'envoie au module de déclinaison/conjugaison
            
            # --- Afficher la progression
            if not labprogr is None:
                oldpourcent = pourcent
                pourcent = (i*100) // lenSource
                if pourcent > oldpourcent:
                    labprogr['text'] = str(pourcent) + "%"
                    labprogr.update()
            
            # ----------------------------------------
            # --- Instancier le mot Latin décliné     
            # ----------------------------------------
            
            i += 1 # Index du mot du dictionnaire (sera inscrit dans la base)
            
            motLatin=None
            
            try:
                motLatin = cl_LatinWord(itemsource)
            except:
                if motLatin is None:
                # en cas d'échec, le mot n'est pas inscrit dans la base et on passe au suivant
                    print "plouf : retour motLatin = None..." + str (i) + "..."
                    print itemsource
                    continue
            
            
            
            # -------------------
            # --- Préfixes       
            # -------------------
            
            if motLatin.isPrefix:
                
                # Extraire le préfixe
                ks = itemsource[:itemsource.rfind("-...") + 1].lower()
                ks = ks.split("/") # éventuelles variantes
                
                for k in ks:
                                
                    k = unlig(k) # défaire les ligatures dans la liste de flexions
                    
                    if motLatin.isFromLatin:
                        v = "L"
                    elif motLatin.isFromGreek:
                        v = "K"
                    else:
                        v = "+"
                    
                    if k != "":
                        if self.listflex.has_key(k):    # La clef-flexion est déjà présente > on la complète
                            if self.listflex[k].find(str(i) + ":") > -1 : # compléter une flexion en cours 
                                self.listflex[k] += "-" + v
                            else:
                                self.listflex[k] += "|" + str(i) + ":" + v
                        else:                           # La clef-flexion est absente > on l'ajoute
                            self.listflex[k] = str(i) + ":" + v
                    else:
                        try:
                            print "!!! syntaxe incorrecte !!! : " + itemsource
                        except:
                            print "!!! syntaxe incorrecte !!! : index " + str(i)
            
            
            
            
            # ---------------------------------------------------------
            # --- Substantifs : balayage du tableau de déclinaison     
            # ---------------------------------------------------------
            
            elif motLatin.isDeclined:
                
                for iDecl in range(36):
                # On scanne chaque flexion du mot
                    
                    
                    # le conteneur de la flexion 'ks' est une liste plutôt qu'une simple chaîne
                    # pour permettre la séparation des variantes orthographiques
                    ks = []
                    try:
                        k = motLatin.Decl[iDecl].Rac + motLatin.Decl[iDecl].Des.encode('utf-8')
                    except:
                        print "Plouf Decl..." + motLatin.Decl[iDecl].Rac.encode('utf-8')
                    k = k.lower()
                    if motLatin.isSuffix:
                        k = k.replace("...-","-")
                    ks.append(k)
                    
                    
                    if ks[0] != "":
                        
                        # on n'incorpore pas les flexions modifiées par des caractères non alphabétiques
                        if (not "(" in ks[0]) and (not "..." in ks[0]):
                            
                            # --- Formatages de cas particuliers
                            if ks[0][-3:] == "i/e":   # ablatifs Bns > séparer les variantes
                                radic = ks[0][:-3]
                                ks[0] = radic + "e"
                                ks.append(radic + "i")
                            elif ks[0][-3:] == "a/e": # nominatifs type 'botanica' > séparer les variantes
                                radic = ks[0][:-3]
                                ks[0] = radic + "a"
                                ks.append(radic + "e")
                            elif ks[0][-3:] == "e/a": # ablatifs  a/e 1ère decl > séparer les variantes
                                radic = ks[0][:-3]
                                ks[0] = radic + "e"
                                ks.append(radic + "a")
                            elif ks[0][-8:] == "in/im/em": 
                                radic = ks[0][:-8]
                                ks[0] = radic + "in"
                                ks.append(radic + "im")
                                ks.append(radic + "em")
                            
                            # --- Compléter le pyDictionnaire
                            
                            for k in ks:
                                
                                k = unlig(k) # défaire les ligatures dans la liste de flexions
                                v = infoflexdecl[iDecl]
                                
                                if self.listflex.has_key(k):    # La clef-flexion est déjà présente > on la complète
                                    
                                    if self.listflex[k].find(str(i) + ":") > -1 : # compléter une flexion en cours 
                                        self.listflex[k] += "-" + v
                                    else:
                                        self.listflex[k] += "|" + str(i) + ":" + v
                                else:                           # La clef-flexion est absente > on l'ajoute
                                    self.listflex[k] = str(i) + ":" + v
            
            
            
            # ----------------------------------------------------
            # --- Verbes : balayage du tableau de conjugaison     
            # ----------------------------------------------------
            
            elif motLatin.isConjugated:
                
                for modetemps in ("def",("indicatif","imparfait",infoflexconjIM),("indicatif","futur",infoflexconjIF),("subjonctif","present",infoflexconjSP),("subjonctif","imparfait",infoflexconjSM)):
                    
                    # On met à jour la conjugaison avec le mode-temps
                    if modetemps == "def":
                        # (par défaut= Indicatif Présent)
                        infoflexconj = infoflexconjIP
                    else:
                        motLatin.ConjUpdate(modetemps[0], modetemps[1])
                        infoflexconj = modetemps[2]
                    
                    for iConj in range(12):
                        try:
                            k = motLatin.Conj[iConj].Rac + motLatin.Conj[iConj].Des.encode('utf-8')
                        except:
                            print "Plouf Conj..." + motLatin.Conj[iConj].Rac
                        
                        
                        if motLatin.Conj[iConj].Des != "":
                            
                            k = k.lower()
                            
                            # on n'incorpore pas les flexions modifiées par des caractères non alphabétiques
                            if (not "(" in k) and (not "-" in k):
                                
                                # --- Compléter le pyDictionnaire
                                
                                k = unlig(k) # défaire les ligatures dans la liste de flexions
                                v = infoflexconj[iConj]
                                
                                if self.listflex.has_key(k):    # La clef-flexion est déjà présente > on la complète
                                    
                                    if self.listflex[k].find(str(i) + ":") > -1 : # compléter une flexion en cours 
                                        self.listflex[k] += "-" + v
                                    else:
                                        self.listflex[k] += "|" + str(i) + ":" + v
                                    
                                else:                       # La clef-flexion est absente > on l'ajoute
                                    self.listflex[k] = str(i) + ":" + v
                        
                        
                    
            
            # -----------------------------------------------------
            # --- Mots indéclinables/inconjugables à exclure       
            # -----------------------------------------------------
            
            elif motLatin.isLocution:
                pass
            
            # -----------------------------------------------------
            # --- Mots indéclinables/inconjugables à inclure       
            # -----------------------------------------------------
            
            else:
                if motLatin.isDeclNone : # réellement indécinables
                    v = "~"
                else:                    # divers non déclinés
                    v = "?"
                
                k = itemsource.split(' ')[0]
                k = k.split('[')[0]
                k = k.split('/')[0]
                k = k.strip()
                k = k.rstrip(".")   # supprime un éventuel point abbréviatif
                k = k.encode('utf-8')
                k = unlig(k)        # défaire les ligatures
                
                # on n'incorpore pas les mots modifiés par des caractères non alphabétiques
                if (not "(" in k) and (not "-" in k):
                
                    if self.listflex.has_key(k):    # La clef est déjà présente > on la complète
                        self.listflex[k] += "|" + str(i) + ":" + v
                    else:                       # La clef-flexion est absente > on l'ajoute
                        self.listflex[k] = str(i) + ":" + v
            
        
        # --------------------------------------------------
        # --- Sauvegarder le pyDictionnaire dans un fichier 
        # --------------------------------------------------
        
        # ff = open(os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])), "plugins", "declinator_listflex"),"wb")
        ff = open(os.path.join(listflexpath),"wb")
        
        # On inscrit le md5 (en hexa sur 32 octets) du fichier du dico en première ligne
        # (utile pour vérifier concordance de la liste avec le dico)
        dicfile.seek(0)
        ff.write( hashlib.md5(dicfile.read()).hexdigest() + "\n" )
        #ff.write( md5.md5(dicfile.read()).hexdigest() + "\n" )
        
        
        # On évite de concaténer en mémoire et on écrit séquentiellement le fichier
        # vu la taille potentiellement imposante de la liste...
        
        for k, x in self.listflex.items():
            try:
                ff.write(k + "|")
                ff.write(x + "\n")
            except:
                t= k + x # on saute les mots à problèmes d'encodages (caractères exotiques)
                print "! ! !" + t.encode('utf-8')
                
        ff.close()
        
        
        labprogr['text']=""
        
        return


# ===============================================
# === MAIN (widget en mode autonome interactif)  
# ===============================================
if __name__=='__main__':
    print '# # # MODE TEST INTERACTIF # # #'
    w=Widget()
    w.pack()
    w.mainloop()
