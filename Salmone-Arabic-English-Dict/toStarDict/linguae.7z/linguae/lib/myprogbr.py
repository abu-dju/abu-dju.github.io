#!/usr/bin/env python
# -*- coding:utf-8 -*-

#///////////////////////////////////////
#/// Widget Barre de progression ///////
#///////////////////////////////////////

from Tkinter import *


class ProgressBar(Frame):
    
    u"""
    Pour masquer le rectangle d'avancement et le pourcentage : .setValue(-1)
    """

    def __init__(self, root="", width=300, height=15, min=0, max=100, borderwidth=2, relief=SUNKEN):
        
        Frame.__init__(self, root, borderwidth=borderwidth, relief=relief, width=width, height=height)
        
        self.can = Canvas(self, bg=self['bg'], width=width, height=height, highlightthickness=0, relief='flat', borderwidth=0)
        self.can.pack(fill='x', expand=True)
        
        self.rect = self.can.create_rectangle(0, 0, 0, int(height), fill='blue', width=0)
        
        self.txt = self.can.create_text(int(width)/2, int(height)/2, text='')
        
        self.min = min
        self.max = max
        self.range = max - min
        self.width = width
        self.height = height
        self.pourcent = -1
      
        if self.range <= 0: self.range = 1
  
  
    def setMax(self, newMax):
        u"""
        Modifier la valeur maxi absolue de la barre
        """
        
        self.max = newMax
        self.range = newMax - self.min
        
        if self.range <= 0: self.range = 1


    def setMin(self, newMin):
        u"""
        Modifier la valeur mini absolue de la barre
        """
        
        self.min = newMin
        self.range = self.max - newMin
        
        if self.range <= 0: self.range = 1
  
    

    def setValue(self, newval):
        u"""
        Modifier la valeur du curseur de la barre
        """
        
        if newval == -1:
            self.can.coords(self.rect, 0, 0, 0, self.height)    # masquer le rectangle
            self.can.itemconfigure(self.txt, text="")           # masquer le pourcentage
            return
        elif newval < self.min:
            newval = self.min 
        elif newval > self.max:
            newval = self.max
        
        
        # convertir la valeur en largeur du rectangle
        # max - min = 100% donc ( newval / (max-min) ) x 100 = le pourcentage de la largeur maxi
        
        pourcent = (newval*100) // self.range
        
        # mise à jour de l'affichage uniquement si le pourcentage arrondi a changé
        if pourcent == self.pourcent:
            return
        
        self.pourcent = pourcent # mémoriser
        
        newwidth = (self.width * pourcent) // 100
        
        # Dimensionner le rectangle
        self.can.coords(self.rect, 0, 0, newwidth, self.height)
        
        # Ecrire le pourcentage
        t = str(pourcent) + ' %'
        if pourcent < 50 :
          self.can.itemconfigure(self.txt, text=t, fill='black')
        else:
          self.can.itemconfigure(self.txt, text=t, fill='white')
        
        self.can.update()
  
  
    def setWidth(self, newWidth):
        u"""
        Modifier la largeur de la barre après sa création
        """
        
        self.can['width']= newWidth
        self.can.move(self.txt, (newWidth-self.width)/2, 0)
        self.width = newWidth
        
        return
  

    
#=== MAIN (test du widget)

def __testerprogbar():
  
    for n in range(progr.max+1):
        progr.setValue(n)
        for i in range(100):x = ((i*i)/2)*(n+2)
    print "Terminé"
  
if __name__=='__main__':
  
    f_main=Tk()
    progr=ProgressBar(f_main, max=100000)
    progr.pack()
    Button(f_main, text="Go", command=__testerprogbar).pack()
      
    f_main.mainloop()