#!/usr/bin/env python
# -*- coding:utf-8 -*-

# ////////////////////////////////////////////////////////////////////////
#                                                                         
#   LINGUAE                                                               
#   Gestionnaire de dictionnaire multiformat multiplateforme              
#                                                                         
#   sous licence CeCILL-2 (GNU-GPL compatible) : http://www.cecill.info/  
#                                                                         
#   Auteur   : Billig - 2008-2011                                         
#   Contact  : linguae@stalikez.info                                      
#   Site Web : http://linguae.stalikez.info                               
#                                                                         
# ////////////////////////////////////////////////////////////////////////


u"""
| Module mydic.py                                                               
|                                                                               
| Contenu :                                                                     
|   Classe de l'objet dictionnaire 'DicObject'                                  
"""

import os.path
import datetime
import gzip
import sqlite3
import re                       # Expressions rationnelles

# bibliothèque de fonctions perso
from lib.mytools import atrifer, numToStr32, str32ToNum, unlig, convToAmp


class DicObject():
    
    u"""
    | Objet Dictionnaire multiformat                                            
    """
    
    specificationLing = 10100
    

    def __init__(self, 
                dicfilepath,
                lgget,
                winparent = None,
                lstbox = None,
                prgbar = None,
                cp1 = "", cp2 = "",
                cachedir = "",
                hideprogress = lambda : str(1) ):
        
        u"""
        | 1) Lit le ou les fichiers du dictionnaire (formats de dictionnaires   
        |    monofichiers ou multifichiers) :                                   
        |                                                                       
        |   - charge la liste des entrées dans la Tkinter.ListBox liée '.lstbox'
        |     OU dans la pyListe '.innerlst' si aucune listBox n'est spécifiée   
        |                                                                       
        |   - crée la pyListe '.datamap' : liste de tuples contenant les        
        |     décalages et tailles des notices. Cette pyListe est complétée pour
        |     tous les formats supportés.                                       
        |                                                                       
        |   - crée le pyDictionnaire wordIDs : table des WordIDS pointant sur   
        |     les index et les offsets des entrées dans le fichier. Ce          
        |     pyDictionnaire reste vide pour les formats démunis de wordIDs.    
        |                                                                       
        |                                                                       
        | 2) Ouvre et laisse ouvert le fichier des données du dico, accessible  
        |    par l'attribut-objet '.file'                                       
        |                                                                       
        |                                                                       
        | 3) Pilote une barre de progression liée à l'objet : '.progr', si      
        |    celle-ci est spécifiée                                             
        |                                                                       
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'dicfilepath' : (obligatoire) chemin du fichier du dictionnaire     
        |                   à charger.                                          
        |                                                                       
        |   'lgget' : référence à une fonction fournissant les chaînes de       
        |             langage pour les messages sous la forme à 2 arguments :   
        |                    lgget ("section", "nom_chaîne")                    
        |                                                                       
        |   'prgbar' : barre de progression liée à l'objet                      
        |                                                                       
        |   'lstbox' : (facultatif) référence d'une ListBox Tkinter liée au     
        |              dictionnaire, dans laquelle sera stockée la liste des    
        |              entrées. Si aucune référence n'est fournie, cette liste  
        |              est stockée dans une pyListe attibut de l'objet :        
        |              '.innerlst'                                              
        |                                                                       
        |   'cp1', 'cp2' : (facultatifs) encodages langue 1 et langue 2.        
        |                   S'ils sont fournis lors de l'initialisation, ils    
        |                   évitent la demande à l'utilisateur des encodages à  
        |                   utiliser. Nb : 'cp1' et 'cp2' ne sont pris en compte
        |                   que pour les formats de dicos dont l'encodage est   
        |                   variable (WB, CSV...), pour les autres formats leur 
        |                   notification est sans effet.                        
        |                                                                       
        |   'cachedir' : chemin d'un répertoire servant de cache pour les       
        |                fichiers temporaires, s'il n'est pas spécifié le       
        |                répertoire de l'utilisateur est utilisé. Spécifier     
        |                un cache facilite les récupérations et contrôles en    
        |                cas de besoin.                                         
        |                                                                       
        |   'winparent' : fenêtre parent si fonctionnement en mode graphique, si
        |                 différent de None l'objet peut piloter la listBox liée
        |                 'lstbox' et la progressBar liée 'prgbar', et ses      
        |                 messages sortent dans des MessageBox et InputBox      
        |                 dépendants de 'winparent'. Si 'winparent' est None,   
        |                 les messages sortent dans la console.                 
        |                                                                       
        |   'hideprogress' : référence à une fonction sans arguments permettant
        |                   de masquer la ProgressBar, il est préférable de     
        |                   faire fournir une fonction par le processus         
        |                   appellant que de simplement masquer la barre depuis 
        |                   l'objet car 1) le processus appelant peut nécessiter 
        |                   des actions complémentaires (réafficher quelque     
        |                   chose à la place de la barre par ex.)               
        |                   2) le gestionnaire de fenêtre (grid, pack...) n'est 
        |                   pas forcément connu                                 
        |                                                                       
        """
        
        # Sélectionner le mode de sortie des messages (graphique ou console)
        if winparent:
            self.showMessage = self.__showMessageWin
        else:
            self.showMessage = self.__showMessageCons
        
        
        
        # =========================================================
        # === Initialiser les Attributs de l'objet dictionnaire    
        # =========================================================
        
        # --- Attributs généraux
        
        self.file = None            # (objet fichier) pointeur vers le fichier des données du dictionnaire courant
        self.path = ""              # (string) chemin complet du fichier
        self.type = ""              # (string) type du dictionnaire courant (dict, wb, ...)
        self.subtype = ""           # (string) sous-type du dictionnaire courant (utile surtout pour dict (m, x, ...))
        self.innerlst = []          # (pyListe) liste des entrées (complétée uniquement si pas de listbox liée)
        
        # --- Attributs de structure et d'encodage des données
        
        self.br = ""                # (string) terminateur des enregistrements/lignes du dictionnaire courant (utile pour fichiers texte délimités)
        self.sep = ""               # (string) séparateur des champs du dictionnaire courant (utile pour fichiers texte délimmités)
        self.subsep = ""            # (string) segmenteur des champs du dictionnaire courant
        self.encoding1 = ""         # (string) encodage langue 1
        self.encoding2 = ""         # (string) encodage langue 2
        
        # --- Images (icônes de langue)
        
        self.img1b64 = ""           # (string) code en base64 de l'image de la langue 1
        self.img2b64 = ""           # (string) code en base64 de l'image de la langue 2
        self.img1type = ""          # (string) format graphique de l'image de la langue 1
        self.img2type = ""          # (string) format graphique de l'image de la langue 2
        
        # ---
        
        self.datamap = []           # (pyListe) liste d'indexage (offset, taille) du dico courant
        self.wordIDs ={}            # (pyDictionnaire) wordIDs pointant sur les index et les offsets des entrées
        self.curWordID = ""         # (string) wordID courant du dictionnaire
        self.curIdx = -1            # (integer) index courant du dictionnaire
        
        # --- Objets de l'interface graphique liés au dictionnaire
        
        self.winparent = winparent  # (objet fenêtre Tk) fenêtre dont dépend le dictionnaire
        self.lstbox = None          # (objet Listbox) listbox liée au dictionnaire dans l'interface
        self.progr = None           # (objet ProgressBar) barre de progression liée au dictionnaire dans l'interface
        self.lgget = lgget          # (fonction) fonction fournissant les chaînes de langue
        self.hideprogress = hideprogress # (fonction) fonction masquant la barre de progression liée
        
        # --- Attributs de cartographie des données du fichier du dictionnaire
        
        self.hdroffset = 0          # (integer) Offset du bloc de l'en-tête
        self.hdrsize = 0            # (integer) Taille du bloc de l'en-tête
        self.wordlistoffset = 0     # (integer) Offset du bloc de la liste des entrées
        self.wordlistsize = 0       # (integer) Taille du bloc de la liste des entrées
        self.idlistoffset = 0       # (integer) Offset du bloc des wordIDs
        self.idlistsize = 0         # (integer) Taille du bloc des wordIDs
        self.datamapoffset = 0      # (integer) Offset du bloc de cartographie des données
        self.datamapsize = 0        # (integer) Taille du bloc de cartographie des données
        self.dataoffset = 0         # (integer) Offset du bloc des données
        self.datasize = 0           # (integer) Taille du bloc des données
        self.img1offset = 0         # (integer) Offset du bloc de l'icône1 (0 si absent)
        self.img1size = 0           # (integer) Taille du bloc de l'icône1 (0 si absent)
        self.img2offset = 0         # (integer) Offset du bloc de l'icône2 (0 si absent)
        self.img2size = 0           # (integer) Taille du bloc de l'icône2 (0 si absent)
        
        # --- Attributs du header du format Ling (certains sont utilisables par d'autres formats)
        
        self.compatVersion = ""     # (string) Numéro de version de la norme suivie par le dictionnaire
        self.minCompatVersion = ""  # (string) Compatibilité minimale du fichier avec les versions du format (sans limite si vide)
        self.maxCompatVersion = ""  # (string) Compatibilité maximale du fichier avec les versions du format (sans limite si vide)
        
        self.dicName = ""           # (string) Nom convivial du dictionnaire
        self.langName1 = ""         # (string) Nom convivial de la langue 1 (langue source)
        self.langName2 = ""         # (string) Nom convivial de la langue 2 (langue cible)
        self.langIso1 = ""          # (string) Code ISO 639 de la langue 1 (langue source)
        self.langIso2 = ""          # (string) Code ISO 639 de la langue 2 (langue cible)
        self.langNameUser=""        # (string) Nom convivial de la langue de l'utilisateur supposé du dictionnaire
        self.langIsoUser=""         # (string) Code ISO 639 de la langue de l'utilisateur supposé du dictionnaire
        self.langFamily1=""         # (string) Famille linguistique de la langue 1
        self.langFamily2=""         # (string) Famille linguistique de la langue 2
        self.isReverseDic = False   # (booléen) ce dictionnnaire est un dictionnaire inverse
        self.doReverseDic = False   # (booléen) ce dictionnnaire pilote un dictionnaire inverse
        self.reverseDicFileName=""  # (String) Nom du fichier du dictionnaire inverse (ou du dictionnaire maître)
        self.reverseDicName = ""    # (String) Nom convivial du fichier du dictionnaire inverse (ou du dictionnaire maître)
        self.sortEquPatterns = []   # (tupple de strings) Motifs d'équivalence pour le tri alphabétique du dictionnaire
        self.sortEquPatternsRev = [] # (tupple de strings) Motifs d'équivalence pour le tri alphabétique du dictionnaire inverse
        self.wordcount = 0          # (integer) Nombre d'entrées du dictionnaire
        
        self.mainAuthors = []       # (tupple de strings) Auteurs principaux du dictionnaire
        self.altAuthors = []        # (tupple de strings) Auteurs accessoires
        self.contactAuthor = ""     # (string) Contacter les auteurs
        self.shortAuthors = ""      # (string) Auteurs, formulation courte
        self.dicStatus = ""         # (string) Statut du dictionnaire (domaine public, freeware, etc.)
        self.showDicStatus = False  # (booléen) Afficher le statut du dictionnaire 
        self.copyright = ""         # (string) Mention de copyright ou équivalent
        
        self.creationDate = ""      # (string) Date de création du dictionnaire
        self.versionDate = ""       # (string) Date de la présente version du dictionnaire
        self.localEditDate = ""     # (string) Date d'édition locale du fichier (par l'utilisateur)
        
        self.dicID = ""             # (string) Identifiant du dictionnaire (nom interne unique dans un ensemble de dictionnaires)
        self.dicVersionNumber = ""  # (string) N° de version du dictionnaire
        self.dicUrl = ""            # (string) URL du dictionnaire sur le Web
        self.verUrl = ""            # (string) URL d'un éventuel fichier annexe au dictionnaire (infos de version, etc.)
        self.dicInfo = ""           # (string) Infos sur le dictionnaire (saut de ligne : '\n')
        self.showDicInfo = False    # (booléen) Afficher les infos du dictionnaire 
        
        self.protected1 = ""        # (string) Type de protection des entrées d'index (langue 1) (vide = pas de protection)
        self.protected2 = ""        # (string) Type de protection des données (langue 2) (vide = pas de protection)
        
        self.displayFontName1 = ""  # (string) Police d'affichage de la langue 1
        self.displayFontName2 = ""  # (string) Police d'affichage de la langue 2
        self.grammarEncoding1 = ""  # (string) Norme de l'encodage grammatical de la langue 1
        
        self.compatPlugins = []     # (tupple de strings) Liste de plugins compatibles avec le dictionnaire
        self.noCompatPlugins = []   # (tupple de strings) Liste de plugins incompatibles avec le dictionnaire
        self.usePlugins = []        # (tupple de strings) Liste des noms des plugins à associer au dictionnaire
        
        self.wordGroups=[]          # (tupple de strings) Noms/IDs des groupes de mots du dictionnaire
        
        self.biblio = []            # (tupple de strings) Liste de références biblio
        self.showBiblio = False     # (booléen) Afficher la biblio du dictionnaire 
        
        self.extFieldCount = 0      # (integer) Nombre de champs d'extension de la section data de ce dictionnaire
        self.extFieldList = []      # (pyListe) Liste des Noms conviviaux des champs supplémentaires
        
        
        
        # =========================================
        # === Lier la ListBox au dictionnaire      
        # =========================================
        
        # NB : s'il n'y a pas de Listbox fournie (lstbox is None),
        # la pyListe self.innerlst est utilisée en mémoire à sa place
        
        if not lstbox is None:
            self.lstbox = lstbox
            self.lstbox.delete(0, "end")              # Vider la listbox liée
            self.lstbox.update()
        
        
        # =========================================
        # === Lier la ProgressBar au dictionnaire  
        # =========================================
        
        try:
            self.progr = prgbar
            
        except:         # Message : "Impossible de lier la barre de progression"
            self.showMessage(type = "warning",
                title = self.lgget("dic", "msg1"),
                message = dicfilepath + u"\n\n" + self.lgget("dic", "msg2") + " : '"+ prgbar + u"'\n\n" + self.lgget("dic", "msg3"))
            return
        
        
        # =================================================
        # === Lier le répertoire de cache au dictionnaire  
        # =================================================
        
        # cache par défaut : répertoire utilisateur
        if cachedir == "":
            self.cachedir = os.path.expanduser("~")
        else:
            self.cachedir = cachedir
        
        
        # ===============================================================================
        # === Traitement du chemin fourni, en fonction de la source et de la plateforme  
        # ===============================================================================
        
        
        dicfilepath = os.path.normpath(dicfilepath) # Normalise le chemin en fonction de la plateforme
        
        if not os.path.isfile(dicfilepath):         # Vérifie que le chemin existe, sinon avertir et quitter
            self.showMessage(type = "warning",
                title = self.lgget("dic", "msg1"),
                message = u"'" + dicfilepath + u"'\n\n" + self.lgget("dic", "msg4"))# ("Fichier introuvable")
            self = None
            return
        
        self.path = dicfilepath                     # Le chemin de fichier est correct, on l'affecte à l'objet
        
        fplow = dicfilepath.lower()                 # version en minuscule du chemin du fichier
        
        
        # =================================================================
        # === Charger le fichier (aiguillage suivant le format)            
        # =================================================================
        
        if fplow.endswith('.ling'):                     # === Fichier Ling
            
            ret = self.__loadLing(self.path)
        
        elif fplow.endswith('.ifo') or fplow.endswith('.dict') or fplow.endswith('.dict.dz') or fplow.endswith('.dict.gz'): # === Fichier DICT
            
            ret = self.__loadDict(self.path)
        
        elif fplow.endswith('.idx') or fplow.endswith('.dict.gz'):   # === Fichier DICT (bis)
            # Nb : les fichiers *idx sont normalement masqués par le sélecteur de fichier
            ret = self.__loadDict(self.path)
        
        elif fplow.endswith('.wb'):                     # === Fichier WB
            
            ret = self.__loadWB(self.path, cp1=cp1, cp2=cp2)
        
        elif fplow[-4:] in ('.csv', '.tab', '.txt'):    # === Fichier délimité
            
            ret = self.__loadCSV(self.path, cp=cp1)
        
        elif fplow.endswith('.ini'):                    # === Fichier WB
            
            ret = self.__loadINI(self.path, cp=cp1)
        
        elif fplow.endswith('.xdxf'):                   # === Fichier XDXF
            
            ret = self.__loadXDXF(self.path)
        
        else:                                           # Extension de fichier non reconnue
            
            ret = self.lgget("dic", "msg5")
        
        
        # ---------------------------------------------------------------
        # --- Traitement de la chaîne de retour (vide si chargement OK)  
        # ---------------------------------------------------------------
        
        if ret != "":
            
            # Afficher le message d'erreur retourné
            self.showMessage(type = "warning",
                    title = self.lgget("dic", "msg1"),
                    message = ret )
            self.file = None
        
        return
    


    def __loadLing(self, fichPath):
        
        u"""
        | [ appelé par DicOject.__init__ ]
        |                                                                       
        | Charge un fichier dictionnaire de type Ling dans l'objet dictionnaire 
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne vide en cas de succès, un message d'erreur sinon.        
        """
        
        self.file = open(fichPath, 'rb')            # Ouvrir le fichier en lecture binaire
        
        
        # -----------------------------------------
        # --- Lire le mappage global du fichier    
        # -----------------------------------------
        
        # Copier le bloc de mappage dans une chaîne, ce bloc fait toujours 70 octets
        filemap = self.file.read(70)                
        
        # Identifiant de format de fichier
        if filemap[:6] != "%ling/":
            return "'" + fichPath + "'\n\n" + self.lgget("dic", "msg36")
        
        # Version de la spécification Ling suivie par le dictionnaire
        self.compatVersion = filemap[6:14]
        
        # Cartographie des blocs du fichier
        self.hdroffset = str32ToNum(filemap[14:18])
        self.hdrsize = str32ToNum(filemap[18:22])
        self.wordlistoffset = str32ToNum(filemap[22:26])
        self.wordlistsize = str32ToNum(filemap[26:30])
        self.idlistoffset = str32ToNum(filemap[30:34])
        self.idlistsize = str32ToNum(filemap[34:38])
        self.datamapoffset = str32ToNum(filemap[38:42])
        self.datamapsize = str32ToNum(filemap[42:46])
        self.dataoffset = str32ToNum(filemap[46:50])
        self.datasize = str32ToNum(filemap[50:54])
        self.img1offset = str32ToNum(filemap[54:58])
        self.img1size = str32ToNum(filemap[58:62])
        self.img2offset = str32ToNum(filemap[62:66])
        self.img2size = str32ToNum(filemap[66:70])
        
        
        
        # --------------------------------------
        # --- Lire le bloc des propriétés       
        # --------------------------------------
        
        self.file.seek(self.hdroffset)                              # Offset du bloc du header
        chps = self.file.read(self.hdrsize).split("\0")             # Lire le bloc et le splitter
        
        # Charger les propriétés du bloc
        for chp in chps:
            try:
                exec("self." + chp)
                
            except: # avertir et continuer si une propriété ne se charge pas
                
                try   : chp = chp.decode('utf-8')
                except: pass
                try:
                    self.showMessage(type = "warning",
                        title = self.lgget("dic", "msg1"),
                        message = self.lgget("dic", "msg37") + u"\n\n" + chp )
                except:
                    pass

        
        # S'assurer que les propriétés standards de type tuple
        # sont réellement des tuples et non des chaînes
        # (car ils se chargent en tant que chaînes s'il n'y a qu'un seul élément...)
        
        if type(self.mainAuthors) is type('xxx'):self.mainAuthors=(self.mainAuthors,)
        if type(self.altAuthors) is type('xxx'):self.altAuthors=(self.altAuthors,)
        if type(self.compatPlugins) is type('xxx'):self.compatPlugins=(self.compatPlugins,)
        if type(self.usePlugins) is type('xxx'):self.usePlugins=(self.usePlugins,)
        if type(self.biblio) is type('xxx'):self.biblio=(self.biblio,)
        if type(self.extFieldList) is type('xxx'):self.extFieldList=(self.extFieldList,)
        if type(self.sortEquPatterns) is type('xxx'):self.sortEquPatterns=(self.sortEquPatterns,)
        if type(self.sortEquPatternsRev) is type('xxx'):self.sortEquPatternsRev=(self.sortEquPatternsRev,)
        if type(self.wordGroups) is type('xxx'):self.wordGroups=(self.wordGroups,)
        
        
        # --------------------------------------------------------------
        # --- Contrôle de la compatibilité du dico                      
        # --- avec la spécification Ling suivie par le programme        
        # --------------------------------------------------------------
        
        # Version Ling nominale du dico
        v = int(self.compatVersion.replace(".","").lstrip("0"))
        
        if v != DicObject.specificationLing:
            # Vérifier que la spécification Ling du programme est dans l'intervale de compatibilité du dico
            v1 = self.minCompatVersion.split(" ")[0].replace(".","").lstrip("0")
            if v1 == "": v1 = v
            else: v1 = int(v1)
            v2 = self.minCompatVersion.split(" ")[0].replace(".","").lstrip("0")
            if v2 == "": v2 = v
            else: v2 = int(v2)
            
            if not (v1 <= DicObject.specificationLing <= v2):
                # Le dico est incompatible
                return "La version LING de ce dictionnaire est incompatible !"
        
        
        # ---
        # ---
        # ---
        
        prg = 0 ; self.progr.setMax(self.wordcount * 2)             # Paramétrer la ProgressBar
        
        # Accélérateurs locaux
        setprogr = self.progr.setValue
        dmap = self.datamap.append
        
        # --------------------------------
        # --- Lire le bloc des entrées    
        # --------------------------------
        
        self.file.seek(self.wordlistoffset)                         # Offset du bloc des entrées
        sz = self.wordlistsize                                      # Taille du bloc des entrées
        
        if sz >0:
            
            chps = self.file.read(sz)                               # Lire le bloc des entrées
            if self.protected1=="Linguae": chps=atrifer(chps)
            chps = chps.split("\0")                                 # Splitter le bloc des entrées
            
            # boucle de lecture des entrées
            for chp in chps:
                self.lstAdd(chp)                                    # Charger la liste des entrées
                prg += 1 ; setprogr(prg)                            # Afficher la progression
            
            # Compter les mots chargés
            if not self.lstbox is None:                             
                self.wordcount = self.lstbox.size()
            else:
                self.wordcount = len(self.innerlst)
        
        
        # ----------------------------------------
        # --- Lire les wordIDs                    
        # ----------------------------------------
        # construire le pyDictionnaire'self.wordIDs' :
        #  wordIDs[wordID] = (index de l'entrée, offset dans bloc des entrées) 
        
        self.file.seek(self.idlistoffset)                           # Offset du bloc des wordIDs
        sz = self.idlistsize                                        # Taille du bloc (nulle si aucun wordID défini)
        
        if sz > 0:                                                  # Lire le bloc des wordIDs
            bloc = self.file.read(sz)
            
            i = 0
            while i < len(bloc):
                
                
                # lire le wordID (8 caractères)
                wID = bloc[i:i+8].strip()
                
                # Contrôle des doublons de wordID,
                # si un doublon est trouvé > avertir et demander si poursuite du chargement
                if self.wordIDs.has_key(wID) :
                    r = self.showMessage(type = "askyesno",
                        title = self.lgget("dic", "msg1") + " Ling",
                        message = self.lgget("dic", "msg6") + " '" + wID + "' " + self.lgget("dic", "msg7") )
                    if not r:
                        return "Chargement interrompu !"
                
                # Compléter le pyDictionnaire avec l'index et l'offset (nombres sur 32 bits)   
                self.wordIDs[wID] = (str32ToNum(bloc[i+8:i+12]), str32ToNum(bloc[i+12:i+16]))
                i += 16
        
        
        # --------------------------------------------------
        # --- Lire le mappage des données                   
        # --------------------------------------------------
        
        self.file.seek(self.datamapoffset)              # Offset du bloc de mappage des données
        sz = self.datamapsize                           # Taille du bloc de mappage des données
        
        if sz >0:
            bloc = self.file.read(sz)                   # Lire le bloc de mappage dans une chaîne
            
            # --- Construire .datamap en mémoire
            
            delta = self.dataoffset                     # Offset du bloc des données
            
            for i in range(self.wordcount):
                p = i * 8                               # Position des données correspondant à l'entrée
                decal = delta + str32ToNum(bloc[p:p+4]) # Lire l'offset (relatif + delta)
                sz = str32ToNum(bloc[p+4:p+8])          # Lire la taille
                dmap((decal,sz))
                
                prg += 1 ; setprogr(prg)                # Afficher la progression
        
        
        # -------------------------------------------------
        # --- Lire les images                              
        #     <format image><00><code base 64 de l'image>  
        # -------------------------------------------------
        
        if self.img1offset != 0:
            self.file.seek(self.img1offset)
            parts = self.file.read(self.img1size).split("\0")
            self.img1type = parts[0]    # format graphique de l'image
            self.img1b64 = parts[1]     # code base64 de l'image
        
        if self.img2offset != 0:
            self.file.seek(self.img2offset)
            parts = self.file.read(self.img2size).split("\0")
            self.img2type = parts[0]    # format graphique de l'image
            self.img2b64 = parts[1]     # code base64 de l'image
        
        
        # ---
        
        self.type = "ling"
        self.encoding1 = "utf-8"
        self.encoding2 = "utf-8"
        self.subsep = ";"
        
        return ""


    def __loadXDXF(self, fichPath):
        
        u"""
        | [ appelé par DicOject.__init__ ]                                      
        | Charge un dictionnaire de type XDXF dans l'objet dictionnaire         
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne vide en cas de succès, un message d'erreur sinon.        
        """
        

        self.file = open(fichPath, 'rb')            # Ouvrir le fichier en lecture binaire
        
        strf = self.file.read()
        
        
        # ----------------------------------------------
        # --- Parcours de la chaîne xml du fichier      
        # ----------------------------------------------
        
        p1ar = 0    # position de '<ar>'
        p2ar = 0    # position de '</ar>'
        p1k = 0     # position de '<k>'
        p2k = 0     # position de '</k>'
        
        wc = 0
        
        self.progr.setMax(40000)           # Paramétrer la ProgressBar à la louche car nombre exact inconnu
        
        cleanTag = re.compile(r"<[^>]+?>", re.MULTILINE)
        
        # accélérateurs locaux
        sfind = strf.find
        dmap = self.datamap.append
        setprogr = self.progr.setValue
        
        while 1:
            
            # Bornage
            p1ar = sfind("<ar>", p2ar)
            p1k = sfind("<k>", p1ar)
            p2k = sfind("</k>", p1k)
            p2ar = sfind("</ar>", p1ar)
            
            if p1ar < 0: break
            
            chp1 = strf[p1k+3:p2k]
            chp1 = re.sub(cleanTag, "", chp1)
            
            chp1 = chp1.replace("&gt;", ">")    # Gestion a minima des entités html
            
            self.lstAdd(chp1)                   # Charger la liste des entrées
            
            dmap((p1ar, (p2ar+5)-p1ar))         # Conserver décalages et tailles dans .datamap (une liste de tuples)
            
            wc += 1
            
            setprogr(wc)
        
        # ---
        
        self.wordcount = wc
        self.type = "xdxf"
        self.encoding1 = 'utf-8'
        self.encoding2 = 'utf-8'
        
        return ""



    def __loadDict(self, fichPath):
        
        u"""
        | [ appelé par DicOject.__init__ ]                                      
        |                                                                       
        | Charge un dictionnaire de type Dict dans l'ojet dictionnaire          
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne vide en cas de succès, un message d'erreur sinon.        
        """
        
        fplow = fichPath.lower()                            # version en minuscule du chemin du fichier
        
        
        # --- Oter l'extension > radical du chemin
        # (attention : le fichier fourni peut-être non compressé alors que le dict peut être compressé 
        # ou inversement, donc ne pas se baser ensuite sur ce flag temporaire)
        flagGz = False
        if fplow.endswith('.gz'): flagGz = True              # Le fichier est compressé (oui/non)
        if fplow.endswith('.dz'): flagGz = True              # Le fichier est compressé (oui/non)
        
        if flagGz:
            strPathRadic = fichPath[:fichPath.rfind('.', 0, -3)]
        else:
            strPathRadic = fichPath[:fichPath.rfind('.')]
        
        
        # ----------------------------------
        # --- Ouvrir le fichier *.ifo       
        # ----------------------------------
        
        # --- Ouvrir l'ifo en lecture texte
        #   (NB : l'ifo n'est jamais compressé)
        
        try:
            fichifo = open(strPathRadic+'.ifo', 'rU')
        except: 
            return  self.lgget("dic", "msg8")       # ('impossible de charger l'ifo')
        
        lignes = fichifo.readlines()                # Charger dans une liste de lignes
        fichifo.close()
        
        # --- Lecture des champs de propriétés
        
        self.subtype = 'mixte' # ( type par défaut = pas de champ 'sametypesequence' )
        
        for ligne in lignes:
            
            if ligne.startswith("sametypesequence"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.subtype = ligne[ligne.find("=")+1:].strip()
                
            elif ligne.startswith("bookname"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.dicName = ligne[ligne.find("=")+1:].strip()
                
            elif ligne.startswith("author"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.mainAuthors=(ligne[ligne.find("=")+1:].strip(),)
                
            elif ligne.startswith("email"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.contactAuthor=ligne[ligne.find("=")+1:].strip()
                
            elif ligne.startswith("description"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.dicInfo=ligne[ligne.find("=")+1:].strip()
                self.showDicInfo = True
                
            elif ligne.startswith("website"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.dicUrl=ligne[ligne.find("=")+1:].strip()
                
            elif ligne.startswith("date"):
                ligne = ligne.replace("\r", "").replace("\n", "")
                self.versionDate=ligne[ligne.find("=")+1:].strip()
        
        
        # --- Quitter et avertir si le sous-type n'est pas encore pris en charge
        # m : texte Utf-8
        # l : texte 8-bits
        # g : texte balisé Pango
        # x : données XDXF
        # h : données HTML
        
        if not self.subtype in ('m', 'l', 'g', 'x', 'h'):
            return "'" + fichPath + u"'\n\n" + self.lgget("dic", "msg9") + " '" + self.subtype + u"'\n\n" + self.lgget("dic", "msg10")
        
        # --- Lecture du wordcount
        
        for ligne in lignes:
            if ligne.startswith("wordcount"):
                self.wordcount = int(ligne[10:])
                self.progr.setMax(self.wordcount)   # Paramétrer la ProgressBar
                break
        
        
        # ----------------------------------
        # --- Ouvrir le fichier *.idx       
        # ----------------------------------
        
        # Accélérateurs locaux
        setprogr = self.progr.setValue
        dmap = self.datamap.append
        
        # --- Ouvrir l'index en lecture binaire
        try:
            fichidx = open(strPathRadic+'.idx', 'rb')
        except:
            try:
                fichidx = gzip.GzipFile(strPathRadic+'.idx.gz', 'rb')
            except: 
                return self.lgget("dic", "msg11") # ('Impossible d'ouvrir le fichier index')
        
        strfile = fichidx.read()                            # Charger l'index dans une chaîne
        fichidx.close()
        
        
        # --- Analyser la chaîne contenant l'index
        
        p1, p2 = 0, 0
        while 1:
            p2 = strfile.find("\0",p1)
            if p2 == -1 : break
            
            chp = strfile[p1 : p2]
            chp = chp.replace("&gt;", ">")                  # Gestion a minima des entités html
            
            self.lstAdd(chp)                                # charger dans la liste des entrées
            
            decal = str32ToNum(strfile[p2 + 1 : p2 + 5])    # extraire l'offset (4 octets)
            sz = str32ToNum(strfile[p2 + 5 : p2 + 9])       # extraire la taille (4 octets)
            
            p1 = p2 + 9
            
            dmap((decal, sz))                           # conserver décalages et tailles dans une liste de tuples
            
            setprogr(len(self.datamap))                 # afficher progression
        
        
        
        # --------------------------------------------------------------------------------
        # --- Ouvrir le fichier *.dict correspondant (et le laisser ouvert pour la suite) 
        # --------------------------------------------------------------------------------
        
        # Si le dictionnaire est ouvert par appel à un dict compressé, on impose l'ouverture de celui-ci
        if fplow.endswith('dict.dz'):
            self.type = 'dictdz'
        elif fplow.endswith('dict.gz'):
            self.type = 'dictgz'
        else:
        
        # Sinon on essaie d'abord d'ouvrir un *.dict non compressé (s'il est présent)
            try:
                self.file = open(strPathRadic + '.dict', 'rb')          # Pointeur de fichier
                self.type = 'dict'
            except:
                
                # On recherche un fichier compressé en cas d'échec de l'ouverture
                if os.path.isfile(strPathRadic + '.dict.dz'):           
                    self.type = 'dictdz'
                elif os.path.isfile(strPathRadic + '.dict.gz'):
                    self.type = 'dictgz'
                else: 
                    return self.lgget("dic", "msg12") # ('Impossible d'ouvrir le fichier des données')
                
        
        # Décompresser si besoin le dict.*z dans un fichier dict temporaire
        # qui sera utilisé à la place du dict lui-même
        if self.type in ("dictgz", "dictdz"):
            
            # Chemin du fichier dict temporaire dans le cache
            fichtemp = os.path.join(self.cachedir, "TEMP.dict")  
            
            # Effacer un fichier précédent (au cas où...)
            try   : os.remove(fichtemp)
            except: pass
            
            if self.type == "dictdz":
                fichgz = gzip.GzipFile(strPathRadic+'.dict.dz', 'rb')
            else:
                fichgz = gzip.GzipFile(strPathRadic+'.dict.gz', 'rb')
            
            # Ouvrir le fichier temporaire
            try:
                self.file = open(fichtemp, 'wb')
            except: 
                return self.lgget("dic", "msg14")
            
            self.file.write(fichgz.read())          # Enregistrer le contenu décompressé dans le dict temporaire
            self.file.close()
            
            self.file = open(fichtemp, 'rb')        # Rouvrir le dict temporaire en lecture
        
        self.encoding1 = "utf-8"
        self.encoding2 = "utf-8"
        
        
        # ---------------------------------------------------------------
        # --- Ouvrir le fichier *.syn s'il existe                        
        # ---------------------------------------------------------------
        # NB section désactivée car les synonymes Dict ne sont pas utilisables dans l'interface actuelle
        # ces synonymes Dict sont uniquement des synonymes externes (= qui ne sont pas eux-mêmes des entrées du dico)
        # qui pointent sur des entrées du dico
        #
        # --- Ouvrir l'index en lecture binaire
        #flagsyn = True
        #try:
        #    fichsyn = open(strPathRadic+'.syn', 'rb')
        #except:
        #    try:
        #        fichsyn = gzip.GzipFile(strPathRadic+'.syn.gz', 'rb')
        #    except:
        #        flagsyn = False
        #
        #if flagsyn:
        #    strfile = fichsyn.read()                                # Charger le fichier dans une chaîne
        #    fichsyn.close()
        #
        # <<<< Traitement : à réaliser, éventuellement >>>>
        
        return ""


    def __loadWB(self, fichPath, cp1="", cp2=""):
        
        u"""
        | [ appelé par DicOject.__init__ ]                                      
        | Charge un dictionnaire de type WB dans l'objet dictionnaire           
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |  'cp1' et 'cp2' : encodage langue 1 et lanhue 2. S'ils ne sont pas    
        |                   fournis, ils sont demandés dans deux inputBoxes     
        |                   successives.                                        
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne vide en cas de succès, un message d'erreur sinon.        
        """
        
        flagErrCp1 = False
        
        # -----------------------------------------------------------------------------
        # ---Confirmer les deux pages de code                                          
        # les *.wb associent deux codages indépendants dans un unique fichier 8-bits   
        # champ1 (codepage:cp1) \0 champ2 (codepage:cp2)                               
        # -----------------------------------------------------------------------------
        
        
        if cp1 == "":
            # Demander l'encodage de la langue source"
            cp1 = self.showMessage(type = "askstring",
                    title = self.lgget("dic", "msg15") + " " + self.lgget("g", "msg5"),
                    message = self.lgget("dic", "msg16") + "\n\n" + self.lgget("g", "enclst") + "\n\n" + self.lgget("dic", "msg17") + "\n",
                    initialvalue = "cp1252")
        if not cp1:
            return "Chargement annulé !"
        
        if cp2 == "":
            # Demander l'encodage de la langue cible"
            cp2 = self.showMessage(type = "askstring",
                    title = self.lgget("dic", "msg15") + " " + self.lgget("g", "msg6"),
                    message = ".../...\n\n" + self.lgget("g", "enclst") +  "\n\n" + self.lgget("dic", "msg18") + "\n",
                    initialvalue = "cp1252")
        if not cp2:
            return "Chargement annulé !"
        
        
        # ----------------------------
        # --- Scanner le fichier WB   
        # ----------------------------
        
        self.file = open(fichPath, 'rb')                # Ouvrir le fichier en lecture binaire
        strfile = self.file.read()                      # Charger le contenu dans une chaîne
        
        self.wordcount = len(strfile)//84               # Déterminer le wordcount
        self.progr.setMax(self.wordcount)               # Paramétrer la ProgressBar
        
        # Accélérateurs locaux
        setprogr = self.progr.setValue
        
        nbmots = 0
        p = 0
        while p < len(strfile)-1:
            nbmots += 1                                 # Compter les mots chargés
            chp1 = strfile[p:p+31]                      # Champ 1 : entrées (31 octets)
            p0 = chp1.find('\0')
            if p0 > -1: chp1 = chp1[:p0]                # Supprimer les \0 en fin de chaîne
            
            try:
                chp1 = chp1.decode(cp1).encode('utf-8') # Décodage de l'encodage originel et réencodage en utf-8
            except:
                flagErrCp1 = True
            
            self.lstAdd(chp1)                           # Charger la liste des entrées
            
            p += 84
            
            setprogr(nbmots)
        
        # ---
        
        self.type = "wb"
        self.encoding1 = cp1
        self.encoding2 = cp2
        self.subsep = ","
        
        # NB : on laisse ouvert le fichier pour la suite
        
        # Avertir si erreurs de décodage du champ 1
        # sans annuler le chargement du dico pour celà
        if flagErrCp1:
            self.showMessage(type = "warning",
                    title = self.lgget("dic", "msg15"),
                    message = self.lgget("dic", "msg19") + " " + cp1)
        
        
        return ""


    def __loadCSV(self, fichPath, cp=""):
        
        u"""
        | [ appelé par DicOject.__init__ ]                                      
        |                                                                       
        | Charge un dictionnaire de type CSV/TSV dans l'objet dictionnaire.     
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'fichpath' : (obligatoire) chemin du fichier CSV.                   
        |                                                                       
        |   'cp' : (facultatif) encodage du fichier CSV. S'il n'est pas         
        |          mentionné il est demandé dans une InputBox.                  
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne vide en cas de succès, un message d'erreur sinon.        
        """
        
        flagErrCp = False
        
        # Demander l'encodage du fichier s'il n'a pas été fourni en argument
        if cp == "":
            cp = self.showMessage(type = "askstring",
                    title = self.lgget("dic", "msg1") + " CSV",
                    message = self.lgget("dic", "msg20") + "\n\n" + self.lgget("g", "enclst"),
                    initialvalue = "utf-8")
        if not cp:
            return "Chargement annulé !"
        
        
        self.file = open(fichPath, 'rU')                    # Ouvrir le fichier en lecture texte
        
        self.progr.setMax( len(self.file.readlines()) )     # Paramétrer la ProgressBar
        
        
        # ----------------------------------------------------------
        # --- Déterminer automatiquement le caractère séparateur    
        # ----------------------------------------------------------
        
        # --- Charger les deux premières lignes non vides pour tester le séparateur
        lignes = []
        n = 0
        self.file.seek(0)
        while n < 2:
            ligne = self.file.readline()
            if ligne.strip != "":
                lignes.append(ligne)
                n +=1
        
        
        self.file.close()
        
        # --- Recherche du caractère séparateur
        sp = ""
        idxsp1 = 10000 # initialiser avec un grand index très improbable
        idxsp2 = 10000
        idxsp3 = 10000
        
        if (fichPath.lower()[-4:] == '.tab') and (len(lignes[0].split('\t')) == 2):
            sp='\t'
            
        else:
            
            if len(lignes[0].split(';')) == 2 and len(lignes[1].split(';')) == 2:
                idxsp1 = lignes[0].find(";")
            
            if len(lignes[0].split(',')) == 2 and len(lignes[1].split(',')) == 2:
                idxsp2 = lignes[0].find(",")
            
            if len(lignes[0].split('\t')) == 2 and len(lignes[1].split('\t')) == 2:
                idxsp3 = lignes[0].find("\t")
            
            if idxsp1 < idxsp2 and idxsp1 < idxsp3:
                sp = ";"
            elif idxsp2 < idxsp1 and idxsp2 < idxsp3:
                sp = ","
            elif idxsp3 < idxsp1 and idxsp3 < idxsp2:
                sp = "\t"
        
        
        # --- Echec de la détermination du séparateur > avertir et quitter
        if sp == "":
            return self.lgget("dic", "msg21")
        
        
        # -------------------------------------
        # --- Ouverture du fichier démimité    
        # -------------------------------------
        
        self.file = open(fichPath, 'rb')   # Ouvrir le fichier en lecture binaire
        strfile = self.file.read()         # Charger le contenu dans une chaîne
        
        
        # ---------------------------------------------------------
        # --- Déterminer automatiquement le terminateur de ligne   
        # ---------------------------------------------------------
        
        br = ""
        if "\r\n" in strfile: br = "\r\n"
        elif "\n" in strfile: br = "\n"
        elif "\r" in strfile: br = "\r"
        
        # Homogénéiser les sauts de lignes > remplacer par des zéros binaires (1 ou 2)
        # (modification temporaire en mémoire, le fichier sur disque n'est pas modifié)
        strfile = strfile.replace("\n", "\0")
        strfile = strfile.replace("\r", "\0")
        strfile += "\0" # Ajouter un zéro binaire en fin de fichier, au cas où il serait absent
        
        
        # -----------------------------
        # --- Bouccle de Chargement    
        # -----------------------------
        
        # accélérateurs locaux de la boucle de scan
        setprogr = self.progr.setValue
        sfind = strfile.find
        dmap = self.datamap.append
        
        nb = 0                                  # nb des lignes
        wc = 0                                  # wordcount
        psp = 0                                 # pointeur des séparateurs
        pnl = -1                                # pointeur des \n
        while psp > -1:
            
            nb += 1
            setprogr(nb)                        # afficher progression
            
            psp = sfind(sp, pnl+1)              # pointeur des séparateurs
            chp1 = strfile[pnl+1 : psp]
            chp1 = chp1.strip('\0')
            chp1 = chp1.strip()                 # Elimine espaces et lignes vides (elles sont accolées en tête de champ)
            chp1 = chp1.strip('"')              # Eliminer éventuels guillemets d'entourage
            
            try   : chp1 = chp1.decode(cp).encode('utf-8')  # Décodage et réencodage en utf-8
            except: flagErrCp = True
            
            pnl = sfind('\0', psp)              # pointeur des \n
            
            if chp1 !="":
                
                self.lstAdd(chp1)               # Charger la liste des entrées
                
                dmap((psp+1, pnl-psp-1))        # Conserver décalages et tailles dans .datamap (une liste de tuples)
                wc += 1
        
        # ---
        
        self.type = "csv"
        self.sep = sp
        self.br = br
        self.encoding1 = cp
        self.encoding2 = cp
        self.wordcount = wc
        
        # Avertir si erreurs de décodage du champ 1
        # sans annuler le chargement pour cela
        if flagErrCp:
            self.showMessage(type = "warning",
                    title = self.lgget("dic", "msg1") + " CSV",
                    message = self.lgget("dic", "msg22") + " " + cp)
        
        return ""


    def __loadINI(self, fichPath, cp=""):
        
        u"""
        | [ appelé par DicOject.__init__ ]                                      
        |                                                                       
        | Charge un dictionnaire de type INI dans l'objet dictionnaire          
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'fichpath' : (obligatoire) chemin du fichier INI.                   
        |                                                                       
        |   'cp' : (facultatif) encodage du fichier INI. S'il n'est pas         
        |          mentionné il est demandé dans une InputBox.                  
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne vide en cas de succès, un message d'erreur sinon.        
        """
        
        flagErrCp = False
        
        # Demander l'encodage s'il n'a pas été fourni
        if cp == "":
            cp = self.showMessage(type = "askstring",
                    title = self.lgget("dic", "msg23"),
                    message = self.lgget("dic", "msg24") + "\n",
                    initialvalue = "cp1252")
        if not cp:
            return "Chargement annulé !"
        
        
        self.file = open(fichPath, 'rU')                    # Ouvrir le fichier en lecture texte
        self.progr.setMax( len(self.file.readlines()) )     # Paramétrer la ProgressBar
        self.file.close()
        
        sp = '='
        
        self.file = open(fichPath, 'rb')   # Ouvrir le fichier en lecture binaire
        strfile = self.file.read()         # Charger le contenu dans une chaîne
        
        # Déterminer automatiquement le terminateur
        br = ""
        if "\r\n" in strfile: br = "\r\n"
        elif "\n" in strfile: br = "\n"
        elif "\r" in strfile: br = "\r"
        
        # Homogénéiser les sauts de lignes > remplacer par des zéros binaires (1 ou 2)
        # (modification temporaire en mémoire, le fichier sur disque n'est pas modifié)
        strfile = strfile.replace("\n", "\0")
        strfile = strfile.replace("\r", "\0")
        strfile += "\0" # Ajouter un zéro binaire en fin de fichier, au cas où il serait absent
        
        
        # accélérateurs locaux de la boucle de scan
        setprogr = self.progr.setValue
        sfind = strfile.find
        dmap = self.datamap.append
        
        nb = 0                                  # nb des lignes
        wc = 0                                  # wordcount
        psp = 0                                 # pointeur des séparateurs
        pnl = -1                                # pointeur des \n
        cursection = ""                         # section courante
        while psp > -1:
            
            nb += 1
            setprogr(nb)                        # afficher progression
            
            psp = sfind(sp, pnl+1)              # pointeur des séparateurs
            chp1 = strfile[pnl+1 : psp]
            chp1 = chp1.strip('\0')
            chp1 = chp1.strip()                 # Elimine espaces et lignes vides (elles sont accolées en tête de champ)
            chp1 = chp1.strip('"')              # Eliminer éventuels guillemets d'entourage
            
            try   : chp1 = chp1.decode(cp).encode('utf-8')    # Décodage et réencodage en utf-8
            except: flagErrCp = True
            
            oldpnl = pnl
            pnl = sfind('\0', psp)              # pointeur des \n
            
            if chp1 !="":
                
                psec = chp1.find("\0")
                if psec > 0: # i.e. un titre de section est accolé à la ligne suivante
                    cursection = chp1.split("\0")[0]
                    
                    self.lstAdd(cursection)         # Charger la liste des entrées
                    dmap((oldpnl+psec+len(br), 0))  # pas de données associées à cette entrée
                    wc += 1
                    
                    psec = chp1.rfind("\0")
                    chp1= chp1[psec+1:]
                    
                    self.lstAdd(" "*6 + chp1)       # Charger la liste des entrées
                    dmap((psp+1, pnl-psp-1))        # Conserver décalages et tailles dans .datamap
                    wc += 1
            
                else: # ligne "clé=valeur" normale
                    self.lstAdd(" "*6 + chp1)       # Charger la liste des entrées
                    dmap((psp+1, pnl-psp-1))        # Conserver décalages et tailles dans .datamap (une liste de tuples)
                    wc += 1
        
        # ---
        
        self.type = "ini"
        self.sep = sp
        self.br = br
        self.encoding1 = cp
        self.encoding2 = cp
        self.wordcount = wc
        
        # Avertir si erreurs de décodage du champ 1
        # sans annuler le chargement pour cela
        if flagErrCp:
            self.showMessage(type = "warning",
                    title = self.lgget("dic", "msg23"),
                    message = self.lgget("dic", "msg22") + " " + cp)
        
        
        return ""


    def lstAdd(self, mot):
        
        u"""
        | Ajoute le 'mot' à la liste des entrées du dico                        
        | (à la Listbox si elle existe, sinon à la pyListe interne '.innerLst') 
        """
        
        if not self.lstbox is None:
            self.lstbox.insert("end", mot)
        else:
            self.innerlst.append(mot)  
        
        
        return
    
    

    def getdata(self, i):
        
        u"""
        | Retourne la liste des données de la notice d'index i, quel que soit le
        | type de dictionnaire chargé.                                          
        |                                                                       
        | Les données sont lues directement dans le fichier de données.         
        |                                                                       
        | Les données sont retournées  dans un pyDictionnaire de 10 champs utf-8
        |                                                                       
        | Rapports :                                                            
        | Champs des données Ling :   Clefs du pyDictionnaire                   
        | -------------------------   -----------------------                   
        |                             ['mot']     entrée du dico                
        |             chp 0       :   ['short']   traductions courtes           
        |             chp 1       :   ['long']    traductions longues (infos)   
        |             chp 2       :   ['ID']      ID de l'entrée                
        |             chp 3       :   ['rac']     wordIDs des racines           
        |             chp 4       :   ['syn']     wordIDs des synonymes         
        |             chp 5       :   ['see']     wordIDs des voir-aussi        
        |             chp 6       :   ['tok']     tokens                        
        |             chp 7       :   ['phon']    phonétique                    
        |             chp 8       :   ['ant']     antonymes                     
        |                                                                       
        """
        
        
        # ------------------------------------------------
        # --- Initialiser le pyDictionnaire à retourner   
        # ------------------------------------------------
        
        tx = u"|!| non géré par ce format |!|"
        tx = tx.encode('utf-8')
        
        data = {}
        
        # Lire l'entrée dans la liste
        if not self.lstbox is None:
            w = self.lstbox.get(i)
        else:
            w = self.innerlst[i]
        
        try   : w = w.encode("utf-8")
        except: pass
        
        data['mot'] = w
        
        # Initialiser les données de notice à retourner
        data['short']=""
        data['long']= tx
        data['ID']=""
        data['rac']= tx
        data['syn']= tx
        data['see']= tx
        data['tok']= tx
        data['phon']= tx
        data['ant']= tx
        
        
        # -----------------------------------------------------
        # --- Extraction des données du fichier (aiguillage)   
        # -----------------------------------------------------
        
        
        # ---------------------------------------------------------------------
        if self.type.startswith("ling"): # --- LING ---------------------------
        # ---------------------------------------------------------------------
        
            self.file.seek(self.datamap[i][0])                   # Décalage dans le fichier de données
            chp = self.file.read(self.datamap[i][1])             # Lire le bloc de données
            if self.protected2=="Linguae": chp=atrifer(chp)
            
            chp = chp.split("\0")                                # Splitter les champs
            
            data['short'] = chp[0]
            data['long'] = chp[1]
            
            try   : data['ID'] = chp[2].strip()
            except: data['ID'] = ""
            
            try   : data['rac']= chp[3]
            except: data['rac']= ""
            
            try   : data['syn']= chp[4]
            except: data['syn']= ""
            
            try   : data['see']= chp[5]
            except: data['see']= ""
            
            try   : data['tok']= chp[6]
            except: data['tok']= ""
            
            try   : data['phon']= chp[7]
            except: data['phon']= ""
            
            try   : data['ant']= chp[8]
            except: data['ant']= ""
            
            # Théoriquement un ling ne devrait recracher que de l'utf-8 mais...
            try   : data['short'] = data['short'].encode('utf-8')
            except: pass
            try   : data['long'] = data['long'].encode('utf-8')
            except: pass
            try   : data['phon'] = data['phon'].encode('utf-8')
            except: pass
        
        
        # ---------------------------------------------------------------------
        elif self.type.startswith("dict"): # --- DICT -------------------------
        # ---------------------------------------------------------------------
            
            self.file.seek(self.datamap[i][0])          # Décalage dans le fichier de données
            short = self.file.read(self.datamap[i][1])  # Lire le bloc de données
            
            
            # Gestion du retour suivant le sous-type
            
            if self.subtype == "x":  # XDXF
                #self.clipboard_clear()
                #self.clipboard_append(short)
                data = self.__xdxfDataToData(data, short)
                
            else:
                
                # Théoriquement un dict ne devrait recracher que de l'utf-8 mais...
                try   : short = short.encode('utf-8')
                except: pass
                
                data['short'] = short
                data['syn'] = ""
        
        
        # ---------------------------------------------------------------------
        elif self.type.startswith("xdxf"): # --- XDXF -------------------------
        # ---------------------------------------------------------------------
            
            self.file.seek(self.datamap[i][0])                      # Décalage dans le fichier de données
            xmldata = self.file.read(self.datamap[i][1]).strip()    # Lire le bloc de données xml
            
            data = self.__xdxfDataToData(data, xmldata)
            
            
        # ---------------------------------------------------------------------
        elif self.type.startswith("csv"): # --- CSV ---------------------------
        # ---------------------------------------------------------------------
            
            self.file.seek(self.datamap[i][0])                  # Décalage dans le fichier de données
            chp0 = self.file.read(self.datamap[i][1])           # Lire le bloc dans une chaîne
            
            try:
                chp0 = chp0.decode(self.encoding2).encode('utf-8')    # Décodage et réencodage en utf-8
            except:
                self.showMessage(type = "warning",
                        title = u"Linguae",
                        message = self.lgget("dic", "msg25") + " " + str(i) )
            
            data['short'] = chp0
        
        
        # ---------------------------------------------------------------------
        elif self.type.startswith("ini"): # --- INI ---------------------------
        # ---------------------------------------------------------------------
            
            id = ""
            tx = u"|!| non géré par format INI |!|"
            tx = tx.encode('utf-8')
            
            if data['mot'].startswith("["):                     # Titre de section
                chp0 = "|!| titre de section, pas de valeur associée |!|"
            else:
                self.file.seek(self.datamap[i][0])              # Décalage dans le fichier de données
                chp0 = self.file.read(self.datamap[i][1])       # Lire la valeur dans une chaîne
                
                try:
                    chp0 = chp0.decode(self.encoding2).encode('utf-8')    # Décodage et réencodage en utf-8
                except:
                    self.showMessage(type = "warning",
                            title = u"Linguae",
                            message = self.lgget("dic", "msg25") + " " + str(i) )
            
            data['short'] = chp0
        
        
        # ---------------------------------------------------------------------
        elif self.type.startswith("wb"): # --- WB -----------------------------
        # ---------------------------------------------------------------------
            
            p = (i*84)+31
            self.file.seek(p)                                 # Décalage
            chp0 = self.file.read(84)                         # Lire le bloc dans une chaîne
            p0 = chp0.find('\0')
            if p0 > -1: chp0 = chp0[:p0]                      # Supprimer les \0 en fin de chaîne
            
            try:
                chp0 = chp0.decode(self.encoding2).encode('utf-8')    # Décodage et réencodage en utf-8
            except:
                self.showMessage(type = "warning",
                        title = u"Linguae",
                        message = self.lgget("dic", "msg25") + " " + str(i) )
            
            data['short'] = chp0
        
        
        
        # ---------------------------------------------------------
        # --- Retourner le pyDictionnaire des données (en utf-8)   
        # ---------------------------------------------------------
        
        
        return data



    def __xdxfDataToData(self, data, xmldata):
        
        u"""
        | Complète le pyDictionaire d'extraction des données d'une entrée,      
        | à partir d'un bloc de données XDXF (issues d'un *.xdxf ou d'un        
        | *.dict/x)                                                             
        |                                                                       
        | ARGUMENTS :                                                           
        |   'data' : référence au pyDictionnaire de retour des données (renvoyé 
        |            par getData). Il est fourni en argument puis retourné après
        |            modification dans cette méthode.                           
        |                                                                       
        |   'xmldata' : un bloc xml qui sera analysé pour en extraire les       
        |               données qui complèteront 'data'                         
        | RETOUR:                                                               
        |   Le pyDictionnaire 'data' après qu'y ait été ajoutées les données    
        |   de 'xmldata'.                                                       
        """
        
        
#        xmldata = xmldata.strip()
#        
#        # -----------------------------------------
#        # --- Construire l'arbre DOM des données   
#        # -----------------------------------------
#        
#        try:
#            xmldom = xml.dom.minidom.parseString(xmldata)       
#        except:
#            
#            if ("<ar>" not in xmldata) and (not xmldata.startswith("<ar>")):
#                xmldata = "<ar>" + xmldata
#            if ("</ar>" not in xmldata) and (not xmldata.endswith("</ar>")):
#                xmldata = xmldata + "</ar>"
#            
#            try:
#                xmldom = xml.dom.minidom.parseString(xmldata)    # Réessayer
#            except :
#                self.showMessage(type = "warning",
#                        title=u"Extraire les données d'un dictionnaire XDXF",
#                        message=u"Impossible de créer l'arborescence DOM des données !")
#                return
#        
#        # ---
#        cleanTag = re.compile(r"<[^>]*?>", re.MULTILINE)
#                 
#        data['short'] = ""
#        data['long'] = ""
#        data['phon'] = ""
#        
#        
#        for nd in xmldom.getElementsByTagName('ar')[0].childNodes:
#        
##            if nd.nodeType == 3:        # noeud de texte
##                t = nd.nodeValue.strip()
##                t = t.replace("\n", "<br>")
##                #t = re.sub(cleanTag, "", t) 
##                data['short'] += t
##            
##            elif nd.nodeName == 'def':
##                pass    # A COMPLETER...
##            
##            elif nd.nodeName == 'dtrn': # (direct translation)
##                t = nd.firstChild.nodeValue.strip()
##                t = t.replace("\n", "<br>")
##                #t = re.sub(cleanTag, "", t)
##                data['short'] += " " + t
##                nd.unlink()
#            if nd.nodeName == 'k': 
#                #nd.unlink()
#                pass
#                
#            elif nd.nodeName == 'co':   # (commentaire)
#                t = nd.firstChild.nodeValue.strip()
#                t = t.replace("\n", "<br>")
#                #t = re.sub(cleanTag, "", t)
#                data['long'] += " " + t
#                #nd.unlink()
#                
#            elif nd.nodeName == 'ex':   # (exemple)
#                t = nd.firstChild.nodeValue.strip()
#                t = t.replace("\n", "<br>")
#                #t = re.sub(cleanTag, "", t)
#                data['long'] += " " + t
#                #nd.unlink()
#            
#            elif nd.nodeName == 'trn':  # (phonétique)
#                t = nd.firstChild.nodeValue.strip()
#                #t = re.sub(cleanTag, "", t)
#                data['phon'] += " " + t
#                #nd.unlink()
#                
#            data['short'] = xmldom.getElementsByTagName('ar')[0].toxml()
        
        
        bloc = xmldata.strip()
        
        # --- homogénéiser les sauts de lignes
        bloc = bloc.replace ("\r\n", "\n")
        
        
        # --- Oter les balises d'élément xdxf
        bloc = bloc.replace("<ar>", "")
        bloc = bloc.replace("</ar>", "")
        bloc = bloc.strip(" \n")
        
        # --- Rechercher et supprimer le mot d'entrée
        
        oRegex = re.compile(r"<k>.*?</k>", re.MULTILINE)
        bloc = re.sub(oRegex, "", bloc) # supprime <k> et son contenu
        
        
        # --- Supprimer les balises de header xdxf mais laisser l'éventuel contenu
        #     résiduel qui est renvoyé avec la notice (pas de perte d'information)
        
        bloc = bloc.replace("<head>","")
        bloc = bloc.replace("</head>","")
        bloc = bloc.strip(" \n")
        
        # --- Supprimer le conteneur global <def></def>
        if bloc.endswith("</def>"):
            bloc = bloc[:-6]
            bloc = bloc.replace("<def>","", 1)
            bloc = bloc.strip(" \n")
            
        # --- Infos : extraire le contenu de <co lang_user="xxx"></co> (commentaires xdxf)
        
        outs = [] 
        for m in re.findall(r"<co.*?>.*?</co>", bloc, re.MULTILINE|re.UNICODE|re.DOTALL):
            outs.append (m)
            bloc = bloc.replace(m,"")
        if outs:    
            outs = "\n".join(outs)
            outs = re.sub(r"<co.*?>", "", outs)
            outs = outs.replace("</co>", "")
        else:
            outs = ""
        
        data['long'] = outs
        
        
        # --- Phonétique : extraire le contenu de <trn></trn>
        
        outs = [] 
        for m in re.findall(r"<trn>.*?</trn>", bloc, re.MULTILINE|re.UNICODE|re.DOTALL):
            outs.append (m)
            bloc = bloc.replace(m,"")
        if outs:    
            outs = "\n".join(outs)
            outs = outs.replace("<trn>", "")
            outs = outs.replace("</trn>", "")
        else:
            outs = ""
        
        data['phon'] = outs
        
        
        # --- Traductions courtes : le reste du bloc
        
        data['short'] = bloc
        
        
        
        # Théoriquement un document xdxf ne devrait contenir que de l'utf-8 mais...
        try   : data['short'] = data['short'].encode('utf-8')
        except: pass
        try   : data['long'] = data['long'].encode('utf-8')
        except: pass
        try   : data['phon'] = data['phon'].encode('utf-8')
        except: pass
        
        return data
    
    
    def rebuidLing(self):
        u"""
        Reconstruire le dictionnaire ling courant en mémoire et sur disque      
        """
        
        
        ### A FAIRE ###
        
        
        return
    
    
    
    def idxfind(self, motif, dom, decal, debut, ignorecase, ignorelig=False, reverse=False, motentier=False, regex=False):
        
        u"""
        | Cherche 'motif' dans :                                                
        |   - les entrées (la listbox liée ou la pyListe interne '.innerlst').  
        |     si 'dom' vaut "idx"/                                              
        |   - dans les notices si 'dom' vaut "notice".                          
        |   - dans les entrées ET les notices si 'dom' vaut "both".             
        |   - dans les wordIDs si 'dom' vaut "IDs".                             
        |   - dans les attributs si 'dom' vaut "toks".                          
        |                                                                       
        |       - à partir de l'index 'decal'                                   
        |       - à rebours si 'reverse' est True                               
        |       - dans le domaine 'dom' ( idx | notice | both | IDs )           
        |       - uniquement en début d'élément si 'debut' est True             
        |       - uniquement les mots entiers si 'motentier' est True           
        |       - sans tenir compte de la casse si 'ignorecase' est True        
        |       - sans tenir compte des ligatures si 'ignorelig' est True       
        |       - 'motif' est traité comme une expression rationnelle si 'regex'
        |          est 'True'                                                   
        |                                                                       
        | RETOUR :                                                              
        |   - L'index numérique de l'entrée correspondant à 'motif' qui suit    
        |     immédiatement 'decal' si 'decal' > -1                             
        |                                                                       
        |   - La pyListe des index de toutes les entrées correspondantes si     
        |    'decal' == -1                                                      
        |                                                                       
        |   - 'None' si aucune correspondance n'a été trouvé                    
        |                                                                       
        | ATTENTION :                                                           
        |     Les illogismes et incompatibilités des diverses options de        
        |     recherche entre elles doivent être préalablement gérés par la     
        |     procédure appellante. L'absence de tests d'incompatibilité dans la
        |     présente procédure de recherche simplifie et accèlère son action. 
        """
        
        
        # /// Sous-routines imbriquées ///
        def getnotice(i):
            data = self.getdata(i)
            return data['short'] + " " + data['long']
        def getwnotice(i):
            data = self.getdata(i)
            return data['mot'] + " " + data['short'] + " " + data['long']
        def getid(i):
            data = self.getdata(i)
            return data['ID']
        def gettoks(i):
            data = self.getdata(i)
            return data['tok'].split(";")
        # ///////////////////////////////
        
        
        iback = None        # index qui sera retourné (None si rien de trouvé) si recherche simple
        idxlst = []         # liste d'index qui sera retournée (None si rien de trouvé) si recherche globale
        
        flagregex = False   # flag indiquant que le motif de recherche est à traiter en tant qu'expression rationnelle
        
        flagglobal = False  # Flag indiquant qu'il s'agit d'une recherche glogale (retourne une liste d'index)
        
        
        # --------------------------------------------------------------------------
        # --- Définir la procédure d'extraction de la meule en fonction du domaine  
        # --------------------------------------------------------------------------
        
        
        if dom == "idx":
            
            # Accélérateur local (moins lourd que self.getdata)
            if not self.lstbox is None:
                wordget = self.lstbox.get   
            else:
                wordget = self.innerlst.__getitem__
            
        elif dom == "notice" :
            
            wordget = getnotice
            
        elif dom == "both" :
            
            wordget = getwnotice
            
        elif dom == "IDs" :
            
            wordget = getid
        
        elif dom == "toks":
            
            wordget = gettoks
        
        
        # ----------------------------------------------------
        # --- Définir le pas et le "range" de la recherche    
        # ----------------------------------------------------
        
        if decal == -1:     # Recherche globale (de 0 à wordcount-1) > liste d'index
            step = 1
            rg1 = 0
            rg2 = self.wordcount
            flagglobal = True
            
        elif reverse:       # Recherche itérative à rebours (de 'decal' à 0)
            step = -1
            rg1 = decal 
            rg2 = -1
            
        else:               # Recherche itérative en avant (de 'decal' à wordcount-1)
            step = 1
            rg1 = decal
            rg2 = self.wordcount
        
        
        # ----------------------------
        # --- Traitement du motif     
        # ----------------------------
        
        if regex: # --- Le motif est une Expression rationnelle litérale
            
            # motif = motif.replace("\\", "\\\\")   inutile !
            
            flagregex = True
            try:
                motif = motif.encode('utf-8')
            except:
                pass
            
            
        elif motentier: # --- Recherche par mot entier
            
            flagregex = True
            try:
                motif = motif.encode('utf-8')
            except:
                pass
                
            noword = r"[ /\|\+@&#\*%\.\-_~:!\?;\,\[\](){}\"'\t\r\n]"
            ptrn = r"^"  + motif + noword + r"|"
            ptrn += noword + motif + noword + r"|"
            ptrn += r"^" + motif + r"$" + r"|"
            ptrn += noword + motif + r"$"
            
            motif = ptrn
            
            # Attention aux collisions utf8 : ç = 'Ã§' , à = 'Ã ' etc.
            # nb : motif = r"\b" + motif + r"\b" trouve n'importe quoi si le
            # caractère qui précède le motif est encodé sur deux octets
            # avec le deuxième caractère assimilable à \b ...
            
            
        else: # --- Recherche standard
            
            if ignorelig:                       # ligatures non significatives (incompatible avec "mot entier" car unlig >utf8)
                motif = unlig(motif)            
            
            if ignorecase:                      # Casse non significative   
                motif = motif.lower()
            
            
            if ("*" in motif or "?" in motif) and not motentier:    # Usage de jokers
                flagregex = True
                try:
                    motif = motif.encode('utf-8')
                except:
                    pass
                
                motif = motif.replace("*", ".*")
                motif = motif.replace("?", ".?")
                
                
                if debut: # uniquement en début de mot
                    motif = "^" + motif
        
        
        if flagregex:
            
            if ignorecase:
                oRegex = re.compile(motif, re.UNICODE|re.IGNORECASE)
            else:
                oRegex = re.compile(motif, re.UNICODE)
        
        
        # ==============================================
        # === BOUCLE DE RECHERCHE (mot par mot) ========
        # ==============================================
        
        try:
            motif = motif.encode('utf-8')
        except:
            pass
        
        
        for i in range(rg1, rg2, step):
            
            meule = wordget(i)
            
            # -------------------------------
            # --- traitement de la meule     
            # -------------------------------
            
            if not regex:
                if ignorelig:
                    meule = unlig(meule)
                if ignorecase:
                    meule = meule.lower()
            
            try:
                meule = meule.encode('utf-8')
            except:
                pass
            
            
            # -------------------------------
            # --- vérifier la concordance    
            # -------------------------------
            
            # --- Recherche par expression rationnelle
            if flagregex:
                
                if not oRegex.search(meule) is None:
                    iback = i
                    if flagglobal: idxlst.append(iback)
                    else: break
                
            # --- Recherche simple : seulement au début de la meule
            elif debut:   
                
                if meule.startswith(motif):
                    iback = i
                    if flagglobal: idxlst.append(iback)
                    else: break
                
            # --- Recherche simple : n'importe où dans la meule
            else:
                try:
                    
                    if motif in meule:
                        iback = i
                        if flagglobal: idxlst.append(iback)
                        else: break
                except:
                    #print map(ord, motif)
                    pass
                    
        
        # Retour
        
        if flagglobal:
            if len(idxlst)==0: idxlst = None
            return idxlst
        else:
            return iback
    
    
    @staticmethod
    def validateLingWordID(wID):
    
        u"""
        | Valide la syntaxe d'un wordID Ling :                                  
        |    - 1 caractère minimum, 8 caractères maximum.                       
        |    - Uniquement des caractères 7-bits (ascii strict) minuscules.      
        |    - Majuscules, espaces et caractères de soulignement interdits.     
        |                                                                       
        | ARGUMENTS :                                                           
        |   'wID' : le wordID à valider.                                        
        |                                                                       
        |                                                                       
        | RETOUR :                                                              
        |   - une chaîne vide si le wordID est valide.                          
        |   - un message d'erreur si le wordID est invalide.                    
        """
        
        # un wordID de longueur nulle est valide, c'est un wordID non encore défini
        if wID == "":
            return ""
        
        
        flaginval = False
        
        
        # Validation de la longueur
        
        if len(wID) > 8:
            flaginval = True
        
        else:
            
            # Validation des caractères
            listord = map(ord, wID)    
            for o in listord:
                if (not o in range(48,58)) and (not o in range(97,123)):
                    flaginval = True
        
        if flaginval:
            return u"WordID syntax :\n\t* Length / Longueur : 1 - 8 Char./Car.\n\t* Alphanumeric strict Ascii (0-9, a-z)\n\t* Low case only / Minuscules uniquement"
        return ""
    
    
    @staticmethod
    def getPropertyXDXF(filepath, proprname, rootproprname=None):
        u"""
        | Retourne la valeur d'une propriété d'un fichier XDXF fermé (autre     
        | que le fichier courant).                                              
        |                                                                       
        | !!! Ne pas utiliser pour le fichier courant, car ses propriétés sont  
        | directement accessibles en tant qu'attributs de l'objet dictionnaire. 
        |                                                                       
        | ARGUMENTS :                                                           
        |   'filepath' : chemin du fichier à analyser                           
        |   'proprname' : nom de la propriété (sensible à la casse)             
        |   'rootproprname' : nom de la balise racine de la propriété (option)  
        |                                                                       
        | RETOUR :                                                              
        |   - La valeur de la propriété                                         
        |   - None si le chemin est incorrect ou si la propriété est absente    
        |     du fichier Ling                                                   
        """
        
        # Ouvrir le fichier en lecture texte
        try:
            ff = open(filepath, "rb")
        except:
            return None
        
        txt = ff.read(2000) # lire les 2000 premiers caractères du fichier
        ff.close()
        
        # Extraire tout le contenu de la balise racine éventuelle
        if rootproprname:
            txt = re.search(r"<" + rootproprname + r".*?>(.*?)</" + rootproprname + r">", txt, re.DOTALL)
            if txt:
                txt = txt.group(1).strip()
                if txt == "":
                    return None
            else:
                return None
            
        # Extraire la propriété
        
        propr = re.search(r"<" + proprname + r">(.*?)</" + proprname + r">", txt, re.DOTALL)
        
        if propr:
            propr = propr.group(1).strip()
            
            if propr != "":
                
                return propr
        
        
        return None
    
    
    @staticmethod
    def getPropertyDict(filepath, proprname):
        u"""
        | Retourne la valeur d'une propriété d'un fichier Dict fermé (autre     
        | que le fichier courant).                                              
        |                                                                       
        | !!! Ne pas utiliser pour le fichier courant, car ses propriétés sont  
        | directement accessibles en tant qu'attributs de l'objet dictionnaire. 
        |                                                                       
        | Pour récupérer plusieurs propriétés à la fois,                        
        | utiliser getPropertiesDict()                                          
        |                                                                       
        | ARGUMENTS :                                                           
        |    'filepath' : chemin du fichier à analyser                          
        |    'proprname' : nom de la propriété (sensible à la casse)            
        |                                                                       
        | RETOUR :                                                              
        |   - La valeur de la propriété                                         
        |   - None si le chemin est incorrect ou si la propriété est absente    
        |     du fichier Ling                                                   
        """
        
        # Ouvrir le fichier *.ifo en lecture
        filepath = filepath.replace(".dict.dz", ".ifo")
        filepath = filepath.replace(".dict.gz", ".ifo")
        filepath = filepath.replace(".dict", ".ifo")
        try:
            chps = open(filepath, "rU").readlines()
        except:
            return None
        
        for chp in chps:
            if chp.startswith(proprname):         # Trouvé !
                return chp.split("=")[1].strip("\r\n")
        
        return None
    
    
    @staticmethod
    def getPropertyLing(filepath, proprname):
        u"""
        | Retourne la valeur d'une propriété d'un fichier Ling fermé (autre     
        | que le fichier courant).                                              
        |                                                                       
        | !!! Ne pas utiliser pour le fichier courant, car ses propriétés sont  
        | directement accessibles en tant qu'attributs de l'objet dictionnaire. 
        |                                                                       
        | Pour récupérer plusieurs propriétés à la fois,                        
        | utiliser getPropertiesLing()                                          
        |                                                                       
        | ARGUMENTS :                                                           
        |    'filepath' : chemin du fichier à analyser                          
        |    'proprname' : nom de la propriété (sensible à la casse)            
        |                                                                       
        | RETOUR :                                                              
        |   - La valeur de la propriété                                         
        |   - None si le chemin est incorrect ou si la propriété est absente    
        |     du fichier Ling                                                   
        """
        
        
        # ------------------------------------------------------------
        # --- Ouvrir le fichier et extraire le bloc des propriétés    
        # ------------------------------------------------------------
        
        try:
            ff = open(filepath, "rb")
        except:
            return None
        
        
        # lire les coordonnées du bloc des propriétés
        filemap = ff.read(22)
        hdroffset = str32ToNum(filemap[14:18])
        hdrsize = str32ToNum(filemap[18:22])
        
        ff.seek(hdroffset)                              
        chps = ff.read(hdrsize).split("\0")     # Lire le bloc et le splitter
        ff.close()
        
        # ----------------------------------------------
        # --- Rechercher et retourner la propriété      
        # ----------------------------------------------
        
        for chp in chps:
            if chp.startswith(proprname):         # Trouvé !
                propr = chp.split("=")[1]
                propr = propr.strip("'").strip('"')
                return 
        
        
        return None
    
    
    @staticmethod
    def getPropertiesDict(filepath):
        u"""
        | Retourne un pyDictionnaire des propriétés d'un fichier Dict fermé     
        | (autre que le fichier courant).                                       
        |                                                                       
        | !!! Ne pas utiliser pour le fichier courant, car ses propriétés sont  
        | directement accessibles en tant qu'attributs de l'objet dictionnaire. 
        |                                                                       
        | Pour récupérer une seule propriété à la fois,                         
        | utiliser getPropertyDict()                                            
        |                                                                       
        | ARGUMENTS :                                                           
        |    'filepath' : chemin du fichier à analyser                          
        |                                                                       
        | RETOUR :                                                              
        |   - Le pyDictionnaire  'nom_propriété' : 'valeur_propriété'           
        |   - None si le chemin est incorrect                                   
        """
        
        # Ouvrir le fichier *.ifo en lecture
        if filepath.endswith(".dict"):
            filepath = filepath[:-5] + ".ifo"
        elif filepath.endswith(".dict.dz") or filepath.endswith(".dict.gz") :
            filepath = filepath[:-8] + ".ifo"
        
        try:
            chps = open(filepath, "rU").readlines()
        except:
            return None
        
        propr = {}
        
        for chp in chps:
            t = chp.split("=")
            try:
                propr [t[0]] = t[1].strip("\r\n")
            except:
                pass
            
        return propr
    
    
    
    @staticmethod
    def getPropertiesLing(filepath):
        u"""
        | Retourne un pyDictionnaire des propriétés d'un fichier Ling fermé     
        | (autre que le fichier courant).                                       
        |                                                                       
        | !!! Ne pas utiliser pour le fichier courant, car ses propriétés sont  
        | directement accessibles en tant qu'attributs de l'objet dictionnaire. 
        |                                                                       
        | Pour récupérer une seule propriété à la fois,                         
        | utiliser getPropertyLing()                                            
        |                                                                       
        |                                                                       
        | ARGUMENTS :                                                           
        |    'filepath' : chemin du fichier à analyser                          
        |                                                                       
        | RETOUR :                                                              
        |   - Le pyDictionnaire  'nom_propriété' : 'valeur_propriété'           
        |   - None si le chemin est incorrect                                   
        """
        
        
        # ------------------------------------------------------------
        # --- Ouvrir le fichier et extraire le bloc des propriétés    
        # ------------------------------------------------------------
        
        try:
            ff = open(filepath, "rb")
        except:
            return None
        
        
        # lire les coordonnées du bloc des propriétés
        filemap = ff.read(22)
        hdroffset = str32ToNum(filemap[14:18])
        hdrsize = str32ToNum(filemap[18:22])
        
        ff.seek(hdroffset)                              
        chps = ff.read(hdrsize).split("\0")     # Lire le bloc et le splitter
        ff.close()
        
        # ----------------------------------------------
        # --- Créer et retourner le pyDictionnaire      
        # ----------------------------------------------
        
        propr = {}
        
        for chp in chps:
            t = chp.split("=")
            propr [t[0]] = t[1].strip("'").strip('"')
        
        return propr
    
    
    
    
    
    @staticmethod
    def strPrelingToStrLing(strPreling="", cp="", sep="\t"):
        
        u"""
        | Convertit la chaîne 'strPreling' (chaîne pur texte au format PreLing) 
        | en une chaîne binaire au format Ling et retourne cette chaîne.        
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'strPreling' : chaîne texte Preling.                                
        |                                                                       
        |   'cp' : encodage des données sources PreLing ("" = "utf-8")          
        |          Si un encodage est inscrit en dur en tête de la chaîne       
        |          PreLing, cet encodage a la préséance sur l'encodage          
        |          éventuellement fourni en paramètre.                          
        |                                                                       
        |   'sep' : séparateur des champs dans les lignes de données,           
        |           par défaut : tabulation '\t'. Si un séparateur est inscrit  
        |           en dur en tête de la chaîne Preling, ce séparateur a la     
        |           préséance sur le séparateur éventuellement fourni en        
        |           paramètre.                                                  
        |                                                                       
        | RETOUR :                                                              
        |                                                                       
        |   - En cas de succés : une chaîne binaire Ling.                       
        |                                                                       
        |   - En cas de problème de conversion : un message explicatif préfixé  
        |     par "!" en lieu et place de la chaîne Ling.                       
        |                                                                       
        | ATTENTION ! :                                                         
        |   La résolution des '_include' dans 'strPreling' doit avoir été       
        |   effectuée avant l'appel de cette methode.                           
        |                                                                       
        """
        
        
        
        # ----------------------------------------------
        # --- Convertir en une liste de lignes sources  
        # ----------------------------------------------
        
        lignes = strPreling.splitlines()
        
        # chercher si l'encodage et le séparateur sont inscrits en dur
        # dans la première ligne du fichier Preling
        try:
            
            if lignes[0].startswith("%"):
                try:
                    parts = lignes[0].split("/")
                    cp = parts[1].strip()
                    sep = parts[2].strip()
                    
                    if sep == "{tab}" or sep == "":
                        sep = "\t"
                except:
                    pass
                
                del lignes[0] # On efface ensuite la ligne (économise un test à chaque itération du scannage)
            
        except:
            pass
        
        
        # ----------------------------------------------------------------------------------
        # --- Initaliser les listes/chaînes qui vont constituer les blocs du fichier ling   
        # ----------------------------------------------------------------------------------
        
        propr = {}              # pyDictionnaire temporaire recevant les propriétés
        propr["x_lings"] = {}   # sous-pyDictionnaire recevant les propriétés additionnelles
        
        strhdr = ""
        strwordlist = []
        stridlist = []
        strdatamap = []
        strdata = []
        strgif1 = ""
        strgif2 = ""
        offsetdata = 0
        offsethword = 0
        flaggif1 = False
        flaggif2 = False
        
        
        # ===================================================================
        # === Scanner les lignes sources Preling et compléter les blocs      
        # ===================================================================
        
        i = -1 # initialiser l'index de l'entrée
        
        for ligne in lignes:
            
            ligne = ligne.strip()
            
            if ligne == "":                                 # Sauter les lignes vides
                continue
            elif ligne[0] == "_":                           # Sauter les lignes débutant par "_" (commentaires)
                continue
            
            # -------------------------------------------------------
            # --- Champs de propriété                                
            #     on complète le pyDictionnaire temporaire 'propr'   
            #     que l'on convertira par la suite en bloc Header,   
            #     après la fin du scannage du document               
            # -------------------------------------------------------
            
            
            if ligne[0:2] == "::":
                
                if cp != "":
                    try:
                        ligne = ligne.decode(cp)            # Décodage de l'encodage natif du CSV
                    except:
                        pass
                        #return self.lgget("dic", "msg26") + " " + cp
                    
                    ligne = ligne.encode('utf-8')           # Encodage en utf-8 de la ligne
                
                chp = ligne.split('=', 1)                   # Splitter le champ de propriétés
                
                
                # Gestion des guillemets (les propriétés Preling n'ont pas de 
                # guillemets, sauf les propriétés en liste)
                chp[1] = chp[1].strip(" '\"")
                
                if (chp[1].find('","') < 0) and (chp[1].find('", "') < 0):
                    chp[1] = chp[1].replace('"', "&quot;")
                
                # Propriétés additionnelles
                if ligne[2:9] == "x_ling_":
                    
                    # Compléter le sous-dictionnaire des propriétés additionnelles
                    propr["x_lings"][chp[0][2:]] = chp[1]
                    
                # Propriétés standards
                else:
                    
                    # Compléter le pyDictionnaire temporaire des propriétés
                    propr[chp[0][2:]] = chp[1]
                
                continue
            
            
            # -------------------------------------------------------
            # ---- Lignes des Images (icônes de langue)              
            #                    <format><00><chaîne base64>         
            # -------------------------------------------------------
            
            elif ligne[0:11] == "**img1begin":
                # Initialiser le bloc image avec le format graphique
                try:
                    strgif1 = ligne[12:].strip() + "\0"
                except:
                    strgif1 = "gif\0" # si le format n'est pas précisé, on considère que c'est un gif
                flaggif1 = True
                continue
            
            elif ligne[0:11] == "**img2begin":
                # Initialiser le bloc image avec le format graphique
                try:
                    strgif2 = ligne[12:].strip() + "\0"
                except:
                    strgif2 = "gif\0" # si le format n'est pas précisé, on considère que c'est un gif
                flaggif2 = True
                continue
            
            
            elif ligne[0:9] == "**img1end":
                flaggif1 = False
                continue
            elif ligne[0:9] == "**img2end":
                flaggif2 = False
                continue
                
            elif flaggif1:
                strgif1 += ligne
                continue
            elif flaggif2:
                strgif2 += ligne
                continue
            
            
            # --------------------------------------------------------------------------------------
            # --- Lignes de donnée (lignes sans préfixe)                                            
            #     après splittage du séparateur (tabulation par défaut),                            
            #     on complète la pyListe 'strwordlist' contenant les entrées                        
            #     la pyliste 'strIDlist' contenant les wordIDs                                      
            #     et la pyListe 'strData' contenant les autres données de la ligne séparées par '\0'
            #     la pyListe 'strdatamap' est complétée avec l'offset et la taille des données      
            # --------------------------------------------------------------------------------------
            
            if cp != "":
                try:
                    ligne = ligne.decode(cp)                # Décodage de l'encodage du CSV
                except:
                    try:
                        ligne = ligne.decode('utf-8')
                    except:
                        pass
                        #return self.lgget("dic", "msg26") + " " + cp
                
                try:
                    ligne = ligne.encode('utf-8')           # Encodage en utf-8 de la ligne
                except:
                    pass
            
            i += 1                                          # Incrémenter l'index de l'entrée
            
            chp = ligne.split(sep)                          # Splitter les champs de la ligne de données
            
#            if len(chp) < 2:                                # Avertir si ligne sans traduction (ligne à champ unique)
#                try:
#                    return self.lgget("dic", "msg27") + u", index " + str(i) + ' \n\n"' + ligne + u'"'
#                except:
#                    try:
#                        ligne = ligne.encode('utf-8') 
#                        return self.lgget("dic", "msg27") + u", index " + str(i) + ' \n\n"' + ligne + u'"'
#                    except:
#                        return self.lgget("dic", "msg27") + u", index " + str(i)
            
            
            # --- Libellé de l'entrée
            
            strwordlist.append(chp[0])                      
            
            
            # --- L'entrée a un wordID
            
            id = ""
            try   : id = chp[3].strip()
            except: pass
        
            if id != "":                                    
                # ne conserver que les 8 premiers caractères
                id = id[:8]
                # contrôler la validité du wordID
                ret = DicObject.validateLingWordID(id)
                if ret != "":
                    return "! wordID : '" + id + "'  (index : " + str(i) + ")\n\n" + ret
                # formater le wordID à 8 caractères en complétant avec des espaces
                id = id.rjust(8)
                # ajouter le wordID
                stridlist.append(id)
                # ajouter l'index sur 32 bits
                stridlist.append(numToStr32(i))
                # ajouter l'offset de l'entrée sur 32 bits
                stridlist.append(numToStr32(offsethword))
            
            # Ajouter la taille en octets pour obtenir l'offset de l'entrée suivante
            # pour la mesure en octets, on préajoute le '\0' qui sera ensuite ajouté par 'join()'
            offsethword += len(chp[0]+ "\0")    
            
            
            # --- Chaîne des données de l'entrée :
            
            txt = []
            try:
                txt.append(chp[1] + "\0")                       # Traductions courtes
            except:
                txt.append("\0")
                #Message d'échec d"insertion de la traduction courte
                #return "! Preling > Ling : " + self.lgget("dic", "msg28") + ' \n\n"' + ligne + '"'
            
            try   : txt.append(chp[2] + "\0")                   # Infos
            except: txt.append("\0")
            
            txt.append(id.strip() + "\0")                       # worID
            
            try   : txt.append(chp[4].strip(";") + "\0")        # Racines
            except: txt.append("\0")
            
            try   : txt.append(chp[5].strip(";") + "\0")        # Synonymes
            except: txt.append("\0")
            
            try   : txt.append(chp[6].strip(";") + "\0")        # Voir-aussi
            except: txt.append("\0")
            
            try   : txt.append(chp[7].strip(";") + "\0")        # Tokens
            except: txt.append("\0")
            
            try   : txt.append(chp[8] + "\0")                   # Phonétique
            except: txt.append("\0")
            
            try   : txt.append(chp[9].strip(";"))               # Antonymes
            except: pass
            
            txt = "".join(txt)
            
            
            strdata.append(txt)
            
            strdatamap.append(numToStr32(offsetdata) + numToStr32(len(txt))) # Ajouter l'offset et la taille
            
            offsetdata += len(txt)    # Ajouter la taille pour obtenir l'offset des données suivantes
        
        
        # === (Next ligne // fin du scannage des lignes)
        
        
        
        # ------------------------------------------------------------
        # --- Construire la chaîne du bloc Ling des propriétés        
        # ------------------------------------------------------------
        # Conversion du pyDictionnaire temporaire 'propr'
        
        # Nb : guillemets obligatoires dans le fichier Ling pour encadrer les chaînes de propriétés
        # car les propriétés sont ensuite chargées par 'exec'                                       
        
        strhdr = ""         # Chaîne du Header
        
        
        # Propriétés standards
        
        if propr.has_key('minCompatVersion'): strhdr += 'minCompatVersion="' + propr['minCompatVersion'] + '"\0'
        else: strhdr += 'minCompatVersion="01.01.00"\0'
        
        if propr.has_key('maxCompatVersion'): strhdr += 'maxCompatVersion="' + propr['maxCompatVersion'] + '"\0'
        else: strhdr += 'maxCompatVersion=""\0'
        
        if propr.has_key('dicName'): strhdr += 'dicName="' + propr['dicName'] + '"\0'
        else: strhdr += 'dicName=""\0'
        
        if propr.has_key('langName1'): strhdr += 'langName1="' + propr['langName1'] + '"\0'
        else: strhdr += 'langName1=""\0'
        
        if propr.has_key('langName2'): strhdr += 'langName2="' + propr['langName2'] + '"\0'
        else: strhdr += 'langName2=""\0'
        
        if propr.has_key('langIso1'): strhdr += 'langIso1="' + propr['langIso1'] + '"\0'
        else: strhdr += 'langIso1=""\0'
        
        if propr.has_key('langIso2'): strhdr += 'langIso2="' + propr['langIso2'] + '"\0'
        else: strhdr += 'langIso2=""\0'
        
        if propr.has_key('langNameUser'): strhdr += 'langNameUser="' + propr['langNameUser'] + '"\0'
        else: strhdr += 'langNameUser=""\0'
        
        if propr.has_key('langIsoUser'): strhdr += 'langIsoUser="' + propr['langIsoUser'] + '"\0'
        else: strhdr += 'langIsoUser=""\0'
        
        if propr.has_key('langFamily1'): strhdr += 'langFamily1="' + propr['langFamily1'] + '"\0'
        else: strhdr += 'langFamily1=""\0'
        
        if propr.has_key('langFamily2'): strhdr += 'langFamily2="' + propr['langFamily2'] + '"\0'
        else: strhdr += 'langFamily2=""\0'
        
        if propr.has_key('isReverseDic'): strhdr += 'isReverseDic=' + propr['isReverseDic'] + '\0'
        else: strhdr += 'isReverseDic=False\0'
        
        if propr.has_key('doReverseDic'): strhdr += 'doReverseDic=' + propr['doReverseDic'] + '\0'
        else: strhdr += 'doReverseDic=False\0'
        
        if propr.has_key('reverseDicFileName'): strhdr += 'reverseDicFileName="' + propr['reverseDicFileName'] + '"\0'
        else: strhdr += 'reverseDicFileName=""\0'
        
        if propr.has_key('reverseDicName'): strhdr += 'reverseDicName="' + propr['reverseDicName'] + '"\0'
        else: strhdr += 'reverseDicName=""\0'
        
        if propr.has_key('sortEquPatterns'): strhdr += 'sortEquPatterns="' + propr['sortEquPatterns'] + '"\0'
        else: strhdr += 'sortEquPatterns=""\0'
        
        if propr.has_key('sortEquPatternsRev'): strhdr += 'sortEquPatternsRev="' + propr['sortEquPatternsRev'] + '"\0'
        else: strhdr += 'sortEquPatternsRev=""\0'
        
        strhdr += 'wordcount=' + str(i+1) + '\0'
        
        if propr.has_key('mainAuthors'): strhdr += 'mainAuthors="' + propr['mainAuthors'] + '"\0'
        else: strhdr += 'mainAuthors=""\0'
        
        if propr.has_key('altAuthors'): strhdr += 'altAuthors="' + propr['altAuthors'] + '"\0'
        else: strhdr += 'altAuthors=""\0'
        
        if propr.has_key('contactAuthor'): strhdr += 'contactAuthor="' + propr['contactAuthor'] + '"\0'
        else: strhdr += 'contactAuthor=""\0'
        
        if propr.has_key('shortAuthors'): strhdr += 'shortAuthors="' + propr['shortAuthors'] + '"\0'
        else: strhdr += 'shortAuthors=""\0'
        
        if propr.has_key('dicStatus'): strhdr += 'dicStatus="' + propr['dicStatus'] + '"\0'
        else: strhdr += 'dicStatus=""\0'
        
        if propr.has_key('showDicStatus'): strhdr += 'showDicStatus=' + propr['showDicStatus'] + '\0'
        else: strhdr += 'showDicStatus=False\0'
        
        if propr.has_key('copyright'): strhdr += 'copyright="' + propr['copyright'] + '"\0'
        else: strhdr += 'copyright=""\0'
        
        if propr.has_key('creationDate'): strhdr += 'creationDate="' + propr['creationDate'] + '"\0'
        else: strhdr += 'creationDate=""\0'
        
        if propr.has_key('versionDate'): strhdr += 'versionDate="' + propr['versionDate'] + '"\0'
        else: strhdr += 'versionDate=""\0'
        
        if propr.has_key('localEditDate'): strhdr += 'localEditDate="' + propr['localEditDate'] + '"\0'
        else: strhdr += 'localEditDate=""\0'
        
        if propr.has_key('dicID'): strhdr += 'dicID="' + propr['dicID'] + '"\0'
        else: strhdr += 'dicID=""\0'
        
        if propr.has_key('dicVersionNumber'): strhdr += 'dicVersionNumber="' + propr['dicVersionNumber'] + '"\0'
        else: strhdr += 'dicVersionNumber="1"\0'
        
        if propr.has_key('dicUrl'): strhdr += 'dicUrl="' + propr['dicUrl'] + '"\0'
        else: strhdr += 'dicUrl=""\0'
        
        if propr.has_key('verUrl'): strhdr += 'verUrl="' + propr['verUrl'] + '"\0'
        else: strhdr += 'verUrl=""\0'
        
        if propr.has_key('dicInfo'): strhdr += 'dicInfo="' + propr['dicInfo'] + '"\0'
        else: strhdr += 'dicInfo=""\0'
        
        if propr.has_key('showDicInfo'): strhdr += 'showDicInfo=' + propr['showDicInfo'] + '\0'
        else: strhdr += 'showDicInfo=False\0'
        
        if propr.has_key('protected1') and propr['protected1'] != "":
            flgc1 = True ; strhdr += 'protected1="Linguae"\0'
        else: flgc1 = False ; strhdr += 'protected1=""\0'
        
        if propr.has_key('protected2') and propr['protected2'] != "":
            flgc2 = True ; strhdr += 'protected2="Linguae"\0'
        else: flgc2 = False ; strhdr += 'protected2=""\0'
        
        if propr.has_key('displayFontName1'): strhdr += 'displayFontName1="' + propr['displayFontName1'] + '"\0'
        else: strhdr += 'displayFontName1=""\0'
        
        if propr.has_key('displayFontName2'): strhdr += 'displayFontName2="' + propr['displayFontName2'] + '"\0'
        else: strhdr += 'displayFontName2=""\0'
        
        if propr.has_key('grammarEncoding1'): strhdr += 'grammarEncoding1="' + propr['grammarEncoding1'] + '"\0'
        else: strhdr += 'grammarEncoding1=""\0'
        
        if propr.has_key('compatPlugins'): strhdr += 'compatPlugins="' + propr['compatPlugins'] + '"\0'
        else: strhdr += 'compatPlugins=""\0'
        
        if propr.has_key('noCompatPlugins'): strhdr += 'noCompatPlugins="' + propr['noCompatPlugins'] + '"\0'
        else: strhdr += 'noCompatPlugins=""\0'
        
        if propr.has_key('usePlugins'): strhdr += 'usePlugins="' + propr['usePlugins'] + '"\0'
        else: strhdr += 'usePlugins=""\0'
        
        if propr.has_key('wordGroups'): strhdr += 'wordGroups="' + propr['wordGroups'] + '"\0'
        else: strhdr += 'wordGroups=""\0'
        
        if propr.has_key('biblio'): strhdr += 'biblio="' + propr['biblio'] + '"\0'
        else: strhdr += 'biblio=""\0'
        
        if propr.has_key('showBiblio'): strhdr += 'showBiblio=' + propr['showBiblio'] + '\0'
        else: strhdr += 'showBiblio=False\0'
        
        if propr.has_key('extFieldCount'): strhdr += 'extFieldCount=' + propr['extFieldCount'] + '\0'
        else: strhdr += 'extFieldCount=0\0'
        
        if propr.has_key('extFieldList'): strhdr += 'extFieldList="' + propr['extFieldList'] + '"'
        else: strhdr += 'extFieldList=""'
        
        # Attention : ne pas ajouter de '\0' pour terminer le dernier champ du bloc
        
        # Propriétés additionnelles
        
        for (k,v) in propr["x_lings"].items():
            strhdr += '\0' + k + '="' + v + '"'
        
        
        
        # -------------------------------------------------------------------
        # --- Construire les chaînes des blocs  en concaténant les pyListes  
        # -------------------------------------------------------------------
        
        strwordlist = "\0".join(strwordlist)
        if flgc1: strwordlist = atrifer(strwordlist)
        
        stridlist = "".join(stridlist)
        
        strdatamap = "".join(strdatamap)
        
        if flgc2:
            for i in range(len(strdata)):
                strdata[i] = atrifer (strdata[i])
        strdata = "".join(strdata)
        
        
        
        # --------------------------------------------------------
        # --- Construire le bloc de cartographie du fichier Ling  
        # --------------------------------------------------------
        
        strmap = "%ling/01.01.00"                                   # Identifiant de type de fichier
        
        decal = 70                                                  # offset du bloc hdr
        strmap += numToStr32(decal) + numToStr32(len(strhdr))       # ajouter offset et taille du bloc hdr
        
        decal += len(strhdr)                                        # offset du bloc wordlist
        strmap += numToStr32(decal) + numToStr32(len(strwordlist))  # ajouter offset et taille du bloc wordlist
        
        decal += len(strwordlist)                                   # offset du bloc idlist
        strmap += numToStr32(decal) + numToStr32(len(stridlist))    # ajouter offset et taille du bloc idlist
        
        decal += len(stridlist)                                     # offset du bloc datamap
        strmap += numToStr32(decal) + numToStr32(len(strdatamap))   # ajouter offset et taille du bloc datamap
        
        decal += len(strdatamap)                                    # offset du bloc datam
        strmap += numToStr32(decal) + numToStr32(len(strdata))      # ajouter offset et taille du bloc data
        
        decal += len(strdata)                                       # offset du bloc image1
        if strgif1 != "":
            strmap += numToStr32(decal) + numToStr32(len(strgif1))  # ajouter offset et taille du bloc image1
        else:
            strmap += "\0" * 8                                      # ajouter offset(0) et taille(0) du bloc image1
        
        decal += len(strgif1)                                       # offset du bloc image2
        if strgif2 != "":
            strmap += numToStr32(decal) + numToStr32(len(strgif2))  # ajouter offset et taille du bloc image2
        else:
            strmap += "\0" * 8                                      # ajouter offset(0) et taille(0) du bloc image2
        
        
        
        
        
        # ---------------------------------------------
        # --- Construire la chaîne Ling globale        
        # ---------------------------------------------
        
        # Cet encodage est nécessaire quand les données viennent du presse-papiers
        try   : strgif1 = strgif1.encode("utf-8")
        except: pass
        try   : strgif2 = strgif2.encode("utf-8")
        except: pass
        
        
        #strLing = strmap + strhdr + strwordlist + stridlist + strdatamap + strdata + strgif1 + strgif2
        
        strLing=[]
        strLing.append(strmap)
        strLing.append(strhdr)
        strLing.append(strwordlist)
        strLing.append(stridlist)
        strLing.append(strdatamap)
        strLing.append(strdata)
        strLing.append(strgif1)
        strLing.append(strgif2)
        strLing = "".join(strLing)
        
        
        return strLing




    def toStrPreling(self,
                    progr      = None, 
                    iEdit      = None, contentEdit = None,
                    sortedList = None,
                    protected1 = None, protected2 = None,
                    extract    = None,
                    sep        = "\t",
                    injWIDs    = False    ):
        
        u"""
        | Convertit le dictionnaire courant en une chaîne formattée "PreLing"   
        | encodée en utf-8 et retourne cette chaîne.                             
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'sep' : séparateur des données (tabulation par défaut)              
        |                                                                       
        |   'protected1' et 'protected2' : noms des standards de protection     
        |                                  à inscrire dans la chaîne Ling.      
        |                                                                       
        |   'progr' : référence facultative à une barre de progression          
        |                                                                       
        |                                                                       
        # FONCTIONNALITE DE TRI (facultative):                                  
        |                                                                       
        |   'sortedList' : pyListe facultative. Si cet argument est renseigné,  
        |                  l'ordre des entrées dans la chaîne Preling retournée 
        |                  est le même que celui de 'sortedList', qui doit être 
        |                  formattée ainsi :                                    
        |                       [ 'entrée'  _|index originel , ... ]            
        |                                                                       
        |                                                                       
        # FONCTIONNALITE D'EDITION (facultative) :                              
        |                                                                       
        |   'iEdit' : index des données dont le contenu est à remplacer         
        |             par 'contentEdit' dans la chaîne Preling.                 
        |                                                                       
        |   'contentEdit' : données qui remplaceront l'entrée à éditer.         
        |                                                                       
        |       - si contentEdit == "---" l'entrée d'index 'iEdit' est supprimée
        |                                                                       
        |       - si iEdit == -1, une entrée de contenu 'contentEdit' est       
        |         ajoutée en fin de la chaîne Preling.                          
        |                                                                       
        |       - injWIDs : si True, les wordIDs sont injectés à partir du      
        |         tableau des wordIDS. Si False, ils sont lus du bloc des       
        |         données. L'injection est un processus lent mais permet de     
        |         synchroniser les données avec le tableau des wordIDS après    
        |         son édition en mémoire.                                       
        |                                                                       
        # FONCTIONNALITE D'EXTRACTION (facultative) :                           
        |                                                                       
        |   'extract" : si ce commutateur est renseigné, seules les entrées     
        |               concernées sont intégrées à la chaîne Preling.          
        |                                                                       
        |       - 'extract' == "n"  : extraction des nouvelles entrées          
        |       - 'extract' == "en" : extraction des entrées modifiées ET des   
        |                             nouvelles entrées                         
        |                                                                       
        """
        
        
        # Initialiser une liste recevant les données
        if sep == "\t":
            strPreling = ["%preling/utf-8/{tab}",]
        else:
            strPreling = ["%preling/utf-8/" + sep,]
        
        
        # -----------------------------------------------------
        # --- Propriétés                                       
        # -----------------------------------------------------
        
        strPreling.append("::minCompatVersion=" + self.minCompatVersion)
        strPreling.append("::maxCompatVersion=" + self.maxCompatVersion)
        strPreling.append("::dicName=" + self.dicName)
        strPreling.append("::langName1=" + self.langName1)
        strPreling.append("::langName2=" + self.langName2)
        strPreling.append("::langIso1=" + self.langIso1)
        strPreling.append("::langIso2=" + self.langIso2)
        strPreling.append("::langNameUser=" + self.langNameUser)
        strPreling.append("::langIsoUser=" + self.langIsoUser)
        strPreling.append("::langFamily1=" + self.langFamily1)
        strPreling.append("::langFamily2=" + self.langFamily2)
        strPreling.append("::isReverseDic=" + str(self.isReverseDic))
        strPreling.append("::doReverseDic=" + str(self.doReverseDic))
        strPreling.append("::reverseDicFileName=" + self.reverseDicFileName)
        strPreling.append("::reverseDicName=" + self.reverseDicName)
        strPreling.append('::sortEquPatterns="' + '","'.join(self.sortEquPatterns) + '"')
        strPreling.append('::sortEquPatternsRev="' + '","'.join(self.sortEquPatternsRev) + '"')
        
        if iEdit == -1:             # Ajout d'une nouvelle entrée
            strPreling.append("::wordcount=" + str(self.wordcount + 1))
        elif contentEdit == "---":  # Suppression d'une entrée
            strPreling.append("::wordcount=" + str(self.wordcount - 1))
        else:
            strPreling.append("::wordcount=" + str(self.wordcount))
        
        strPreling.append('::mainAuthors="' + '","'.join(self.mainAuthors) + '"')
        strPreling.append('::altAuthors="' + '","'.join(self.altAuthors) + '"')
        strPreling.append("::contactAuthor=" + self.contactAuthor)
        strPreling.append("::shortAuthors=" + self.shortAuthors)
        strPreling.append("::dicStatus=" + self.dicStatus)
        strPreling.append("::showDicStatus=" + str(self.showDicStatus))
        strPreling.append("::copyright=" + self.copyright)
        strPreling.append("::creationDate=" + self.creationDate)
        strPreling.append("::versionDate=" + self.versionDate)
        strPreling.append("::localEditDate=" + self.localEditDate)
        strPreling.append("::dicID=" + self.dicID)
        strPreling.append("::dicVersionNumber=" + self.dicVersionNumber)
        strPreling.append("::dicUrl=" + self.dicUrl)
        strPreling.append("::verUrl=" + self.verUrl)
        strPreling.append("::dicInfo=" + self.dicInfo)
        strPreling.append("::showDicInfo=" + str(self.showDicInfo))
        
        # infos de protection
        if protected1 is None : protected1= self.protected1
        if protected2 is None : protected2= self.protected2
        strPreling.append("::protected1=" + protected1)
        strPreling.append("::protected2=" + protected2)
        
        strPreling.append("::displayFontName1=" + self.displayFontName1)
        strPreling.append("::displayFontName2=" + self.displayFontName2)
        strPreling.append("::grammarEncoding1=" + self.grammarEncoding1)
        strPreling.append('::compatPlugins="' + '","'.join(self.compatPlugins) + '"')
        strPreling.append('::noCompatPlugins="' + '","'.join(self.noCompatPlugins) + '"')
        strPreling.append('::usePlugins="' + '","'.join(self.usePlugins) + '"')
        strPreling.append('::wordGroups="' + '","'.join(self.wordGroups) + '"')
        strPreling.append('::biblio="' + '","'.join(self.biblio) + '"')
        strPreling.append("::showBiblio=" + str(self.showBiblio))
        strPreling.append("::extFieldCount=" + str(self.extFieldCount))
        strPreling.append('::extFieldList="' + '","'.join(self.extFieldList) + '"')
        
        # propriétés additionnelles
        # on les cherche dans le pyDictionnaire des attributs de l'objet
        for p in self.__dict__:
            if p.startswith("x_ling"):
                strPreling.append("::" + p + "=" + self.__dict__[p])
        
        
        # -----------------------------------------------------
        # --- Bloc des images                                  
        # -----------------------------------------------------
        
        if self.img1b64 != "":
            strPreling.append("**img1begin:" + self.img1type + "\n" + self.img1b64 + "\n**img1end")
        
        if self.img2b64 != "":
            strPreling.append("**img2begin:"+ self.img2type +"\n" + self.img2b64 + "\n**img2end")
        
        
        # -----------------------------------------------------
        # --- Corps des données                                
        # -----------------------------------------------------
        
        if injWIDs:
            wids = self.wordIDs.items()  # tableau des wordIDs utilisé en cas d'injection des wordIds
        
        lignePreL = ""
        
        getdata = self.getdata           # (référence en variable locale pour accélérer la boucle)
        
        for i in range(self.wordcount):
            
            if not progr is None: progr.setValue(i)        # Afficher la progression
            
            # modifier l'index à extraire si tri de la liste
            if not sortedList is None:
                iExtract = int(sortedList[i].split('  _|')[-1]) # lire l'index originel avant le tri
            else:
                iExtract =i
            
            if i != iEdit:          # Entrée standard (c.à.d. non éditée ni ajoutée)
                
                data = getdata(iExtract)                    # Lire les données sur le disque > pyDictionnaire utf-8
                
                word = data['mot']                          # Libellé de l'entrée
                
                if word == "":                              # ne pas incorporer l'entrée si elle est vide
                    continue
                
                chp0 = data['short']                        # Traductions courtes
                chp0 = chp0.replace("\t", "  ")             # poser des balises de sauts de lignes
                chp0 = chp0.replace("\r\n", "<br>")
                chp0 = chp0.replace("\n", "<br>")
                chp0 = chp0.replace("\r", "<br>") 
                
                chp1 = data['long']                         # Traduction longue
                if chp1.startswith("|!|"):                  # (non géré par le format courant)
                    chp1 = ""         
                elif chp1!= "":
                    chp1 = chp1.replace("\t", "  ")         # poser des balises de sauts de lignes
                    chp1 = chp1.replace("\r\n", "<br>")
                    chp1 = chp1.replace("\n", "<br>")
                    chp1 = chp1.replace("\r", "<br>") 
                
                
                if injWIDs:
                    for wid in wids:
                        if wid[1][0] == i:
                            chp2 = wid[0]                   # injection du wordID en mémoire
                            break
                else:
                    chp2 = data['ID']                       # wordID des données de l'entrée
                
                chp3 = data['rac']                          # wordIDs des racines
                if chp3.startswith("|!|"): chp3 = ""        # (non géré par le format courant)
                
                chp4 = data['syn']                          # wordIDs des synonymes
                if chp4.startswith("|!|"): chp4 = ""        # (non géré par le format courant)
                
                chp5 = data['see']                          # wordIDs des voir-aussi
                if chp5.startswith("|!|"): chp5 = ""        # (non géré par le format courant)
                
                chp6 = data['tok']                          # tokens
                if chp6.startswith("|!|"): chp6 = ""        # (non géré par le format courant)
                
                chp7 = data['phon']                         # phonétique
                if chp7.startswith("|!|"): chp7 = ""        # (non géré par le format courant)
                
                chp8 = data['ant']                          # wordIDs des Antonymes
                if chp8.startswith("|!|"): chp8 = ""        # (non géré par le format courant)
                
                
                # Concaténer la ligne de données de l'entrée
                
                lignePreL = word + sep + chp0  + sep + chp1 + sep + chp2 + sep + chp3 + sep + chp4 + sep + chp5 + sep + chp6 + sep + chp7 + sep + chp8
                
                if extract == "en":
                    toks = chp6.split(";")
                    if not "e" in toks and not "n" in toks:
                        lignePreL = ""
                
                elif extract == "n":
                    toks = chp6.split(";")
                    if not "n" in toks:
                        lignePreL = ""
                
            
            elif i == iEdit:   # Editer cette entrée
                
                if contentEdit == "---":        # Supprimer l'entrée (la sauter)
                    word=""
                    continue
                
                else:           # Modifier l'entrée
                    lignePreL = contentEdit
                
            
            # Ajouter la ligne de donnée
            try:
                strPreling.append(lignePreL)
            except:
                print "plouf :"+ligne
            
            lignePreL = ""
        
        # (fin boucle de scannage des données)
        
        # Ajouter éventuellement une nouvelle entrée (indiqué par index == -1)
        
        if iEdit == -1:
            strPreling.append(contentEdit)
        
        
        # -----------------------------------------
        # --- Concaténer la chaîne Preling         
        # -----------------------------------------
        
        try:
            strPreling = "\n".join(strPreling)
        except:
            return self.lgget("dic", "msg29")
        
        
        return strPreling



    def toStrsDict(self, progr=None, iEdit=None, contentEdit=None, sortedList=None):
        
        u"""
        | Convertit le dictionnaire courant                                     
        | en un tupple de 3 chaines :(stridx, strdict, wordcount)               
        | correspondant à un dictionnaire Dict sans son fichier *.ifo           
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'progr' : référence facultative à une barre de progression.         
        |                                                                       
        # FONCTIONNALITE DE TRI (facultative):                                  
        |                                                                       
        |    'sortedList' : pyListe facultative. Si cet argument est renseigné,  
        |                  l'ordre des entrées dans les chaînes Dict retournées 
        |                  est le même que celui de 'sortedList', qui doit être 
        |                  formattée ainsi : [ 'entrée'|index originel , ... ]  
        |                                                                       
        # FONCTIONNALITE D'EDITION (facultative) :                              
        |                                                                       
        |   'iEdit' : index des données dont le contenu est à remplacer         
        |             par 'contentEdit' dans les chaînes Dict.                 
        |                                                                       
        |   'contentEdit' : données qui remplaceront l'entrée à éditer.         
        |                                                                       
        |       - si contentEdit == "---" l'entrée d'index 'iEdit' est supprimée
        |                                                                       
        |       - si iEdit == -1, une entrée de contenu 'contentEdit' est       
        |         ajoutée en fin des chaînes Dict.                              
        |                                                                       
        | RETOUR :                                                              
        |     En cas de succès : un tupple de 3 chaines :                       
        |                        (stridx, strdict, wordcount).                  
        |                                                                       
        |   En cas d'échec : une chaîne simple contenant un message d'erreur.   
        |                                                                       
        """
        
        strifo=[]   # Future chaîne du *.ifo
        stridx=[]   # Future chaîne du *.idx
        strdict=[]  # Future chaîne du *.dict
        
        
        # --------------------------------------
        # --- Scanner la liste des entrées      
        # --------------------------------------
        
        decal = 0
        chp1 = ""
        chp2 = ""
        wordcount = 0
        
        # accélérateurs locaux
        setprogr = self.progr.setValue
        
        
        for i in range(self.wordcount):
            
            if not progr is None: setprogr(i)      # Afficher la progression
            
            # modifier l'index à extraire si tri de la liste
            if not sortedList is None:
                iExtract = int(sortedList[i].split('  _|')[-1])       # lire l'index originel avant le tri
            else:
                iExtract = i
            
            
            decal = decal + len(chp2)               # Décalage (offset) de la traduction
            
            if i != iEdit:          # Entrée standard (c.à.d. non éditée ni ajoutée)
                
                data = self.getdata(iExtract)       # Extraire les données (> pyDictionnaire)
                chp1 = data['mot']                  # Libellé de l'entrée (en utf-8)
                chp2 = data['short']                # Texte de la traduction (en utf-8)
            
            elif i == iEdit:    # Editer cette entrée
                
                if contentEdit == "---": # Supprimer l'entrée (la sauter)
                    decal = decal - len(chp2)       # annuler l'incrémentation précédente
                    continue
                
                else: # Modifier l'entrée
                    chp1 = contentEdit.split("\0")[0]
                    chp2 = contentEdit.split("\0")[1]
            
            
            # --- Compléter les chaînes
            wordcount += 1
            strdict.append(chp2)                    # Ajouter la traduction dans le *.dict
            stridx.append(chp1 + '\0')              # Ajouter l'entrée dans le *.idx
            stridx.append(numToStr32(decal))        # Ajouter le décalage (image chaîne en 32 bits) dans le *.idx
            stridx.append(numToStr32(len(chp2)))    # Ajouter la longueur de la traduction (image chaîne en 32 bits) dans le *.idx
        
        
        # --- Ajouter éventuellement une nouvelle entrée (indiqué par index == -1)
        
        if iEdit == -1:
            decal = decal + len(chp2)
            chp1 = contentEdit.split("\0")[0]
            chp2 = contentEdit.split("\0")[1]
            wordcount += 1
            strdict.append(chp2)
            stridx.append(chp1 + '\0')
            stridx.append(numToStr32(decal))
            stridx.append(numToStr32(len(chp2)))
        
        
        
        # --- Concaténer les chaines
        stridx = "".join(stridx)
        strdict = "".join(strdict)
        wordcount = str(wordcount)
        
        return (stridx, strdict, wordcount)


    def makeWordID(self, txt):
        u"""
        | Confectionne et renvoie un wordID à partir de la chaînete 'txt',      
        | ce wordId est unique dans le dictionnaire                             
        """
        
        id = txt.lower()
        
        # Supprimer les "_"
        id = id.replace("_", "")
        
        # Remplacer les caractères étendus par "z" (ne pas les supprimer car risque d'obtenir une chaîne vide)
        ords = map(ord,id)
        for n in range(len(ords)):
            if ords[n] > 127: ords[n] = ord('z')
        
        id = map(chr, ords)
        id = "".join(id)
        
        # ne garder que les caractères alphanumériques
        id = re.sub("\W", "", id)
        
        # Confectionner le radical de trois lettres
        id = id[0:3]        
        
        # Ajouter le chiffre final
        
        n=1
        while 1:
            testid = id + str(n)
            if not self.wordIDs.has_key(testid):
                id = testid
                break
            n += 1
        
        return id


    def makeWordIDs(self, prgbar=None):
        u"""
        | Ajoute un wordID automatique à toutes les entrées du dictionnaire,    
        | chaque wordId est unique dans le dictionnaire                         
        """
        
        strBlocIDs = '' 
        getdata = self.getdata
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)  # Afficher la progression
            
            # Récupérer les données (> pyDictionnaire utf-8)
            data = getdata(i)                                   
            
            if data['ID'] == "":
                
                # Construire le wordID
                id = self.makeWordID(data['mot'])
                
                self.wordIDs[id] = (i, self.datamap[1][0])
        
        
        # Confectionner la nouvelle chaîne Preling du dictionnaire
        
        strPreling = self.toStrPreling(progr=prgbar, injWIDs=True)
        
        # Confectionner la nouvelle chaîne Ling
        
        strLing = DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        # Enregistre le nouveau fichier
        fichpath = self.path
        self.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strLing)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier trié
        self.__init__(  dicfilepath = fichpath,
                        lgget = self.lgget,
                        lstbox = self.lstbox,
                        prgbar = self.progr,
                        cachedir = self.cachedir)
        
        
        return


    def moveindic(self, isource, icible):
        
        u"""
        | Déplace une entrée dans le dictionnaire.                              
        |                                                                       
        | Pour cela, on réutilise les fonctions de tri propres à chaque format, 
        | en générant une pyListe "triée" dans laquelle le "tri" a simplement   
        | consisté à déplacer l'entrée concernée.                               
        |                                                                       
        | ARGUMENTS :                                                           
        |   'isource' : index actuel de l'entrée à déplacer.                    
        |                                                                       
        |   'icible' : index cible (nouvel index désiré pour l'entrée).         
        |                                                                       
        | RETOUR :                                                              
        |   Le nouvel index réel de l'entrée déplacée.                          
        |   None si échec.                                                      
        """
        
        
        # --------------------------
        # --- Tests préalables      
        # --------------------------
        
        # Déplacement impossible si Dict compressé > avertir et quitter
        if self.type in ("dictdz", "dictgz"): 
            self.hideprogress() # masque la barre de progression, si présente
            self.showMessage(type = "info",
                    title = self.lgget("winsort", "title"),
                    message = self.lgget("dic", "msg30") )
            return
        
        
        # -----------------------------------------------------------
        # --- Confectionner une pyListe temporaire [entrée]|[index]  
        # -----------------------------------------------------------
        
        ltri=[]
        
        # Accélérateur local (moins lourd que self.getdata)
        if not self.lstbox is None:
            wordget = self.lstbox.get
        else:
            wordget = self.innerlst.__getitem__
        
        
        # --- On construit la pyListe
        
        
        for i in range(self.wordcount):
            t = wordget(i).lower().encode('utf-8') # Libellé de l'entrée, mis en minuscule
            ltri.append(t + "  _|" + str(i))
        
        # --- On déplace l'entrée dans la pyListe
        # (supprimer/insérer modifie les index de la pyListe
        #  mais la pyListe contenant les index originaux > pas de correction à effectuer)
        
        machin = ltri.pop(isource)
        
        ltri.insert(icible, machin)  # (icible sera retourné par la procédure)
        
        
        # ----------------------------------------------------------------
        # --- Aiguillage                                                  
        # --- (> rebatir le dico en fonction de l'ordre de la pyListe)    
        # ----------------------------------------------------------------
        
        memoLocalEditDate = self.localEditDate 
        self.localEditDate = str(datetime.date.today())
        
        ret="" # Message de retour des modules de tri
        
        if self.type.startswith("ling"):
            ret = self.__sortdicLing(ltri)
        
        elif self.type.startswith("wb"):
            ret = self.__sortdicWB(ltri)
        
        elif self.type.startswith("dict"):
            ret = self.__sortdicDict(ltri)
        
        elif self.type.startswith("csv"):
            ret = self.__sortdicCSV(ltri)
        
        elif self.type.startswith("xdxf"):
            ret = self.__sortdicXDXF(ltri)
        
        else: # Message : 'Entrée non déplacable'
            self.showMessage(type = "warning",
                title = self.lgget("dic", "msg31"),
                message = self.lgget("dic", "msg32") )
        
        if ret != "":
            self.showMessage(type = "warning",
                    title = self.lgget("dic", "msg31"),
                    message = ret)
            self.localEditDate = memoLocalEditDate
            return
        
        
        return icible




    def sortdic(self, equs=None):
        
        u"""
        | Tri alphabétique du dictionnaire courant.                             
        |                                                                       
        | Aiguillage vers des procédures propres à chaque format de dictionnaire
        | puis affiche, si nécessaire le message de retour de ces procédures :  
        | une chaîne vide si succès, un message d'erreur si échec.              
        |                                                                       
        | ARGUMENTS :                                                           
        |   'equs' : un pyDictionnaire des équivalences de caractères pour le   
        |            tri.                                                       
        |            Si 'equs' n'est pas fourni, l'attribut ".sortEquPatterns"  
        |            du dictionnaire est utilisé (s'il est complété).           
        |            Si 'equs' == 'ascii', le dictionnaire est trié suivant     
        |            l'ordre ascii strict (ordre des codes ascii)               
        |                                                                       
        | RETOUR :                                                              
        |    (aucun)                                                            
        """
        
        # -----------------------------
        # --- Tests préalables         
        # -----------------------------
        
        # Le format INI est non triable > avertir
        if self.type.startswith("ini"):             
            self.hideprogress() # masque la barre de progression, si présente
            self.showMessage(type = "info",
                    title = self.lgget("winsort", "title"),
                    message = self.lgget("dic", "msg33") )
            return
        
        # Le format DICT compressé est non triable > avertir
        elif self.type in ("dictdz", "dictgz"):     
            self.hideprogress() # masque la barre de progression, si présente
            self.showMessage(type = "info",
                    title = self.lgget("winsort", "title"),
                    message = self.lgget("dic", "msg34") )
            return
        
        
        # -----------------------------------------------------------
        # --- Confectionner une pyListe temporaire [entrée]|[index]  
        # --- qui sera ensuite triée                                 
        # -----------------------------------------------------------
        
        ltri=[]
        flagUseSortDefault = True
        
        # Accélérateur local (moins lourd que self.getdata)
        if not self.lstbox is None:
            wordget = self.lstbox.get
        else:
            wordget = self.innerlst.__getitem__
        
        # Déterminer si on va utiliser des équivalences de caractères
        # ou le tri par défaut ou le tri ascii strict
        if equs == 'ascii':                     # tri ascii strict
            pass
        elif not equs is None:                  # un pydic 'equs' est fourni
            flagUseSortDefault = False
        elif len(self.sortEquPatterns) > 0:     # 'equs' n'est pas fourni
            if self.sortEquPatterns[0] != "":
                flagUseSortDefault = False
        
        
        # --- On construit la pyListe en utilisant l'ordre ascii strict
        if equs == 'ascii':
            
            for i in range(self.wordcount):
                
                t = wordget(i)              # Libellé de l'entrée
                try:
                    t = t.encode('utf-8')   # Try car encodage différent si issu de la listbox ou de la pyListe interne 
                except:
                    pass
                
                ltri.append(t + "  _|" + str(i))
        
        
        # --- On construit la pyListe en utilisant des équivalences de caractères
        elif flagUseSortDefault == False: 
            
            # Si le le pyDictionnaire des équivalences de caractères n'est pas fourni à la procédure
            # on le bâtit à partir de la propriété du dictionnaire
            if equs is None:
                equs = {}
                for n in range(len(self.sortEquPatterns)):
                    t = self.sortEquPatterns[n]
                    t = t.replace("$$", " ")            # Symbole "espace"
                    t = t.split(":")
                    if t[1] == "%%":                    # Symbole "absence de caractère"
                        equs[t[0]] = ""
                    else:
                        equs[t[0]] = t[1]
            
            # Construction de la pyListe
            for i in range(self.wordcount):
                
                t = wordget(i).lower()      # Libellé de l'entrée, mis en minuscule
                try:
                    t = t.encode('utf-8')   # Try car encodage différent si issu de la listbox ou de la pyListe interne 
                except:
                    pass
                
                # Appliquer les équivalences de caractères
                for equ in equs:
                    try:
                        t = t.replace(equ, equs[equ])
                        t = t.strip()
                    except:
                        print "! ! ! ERREUR EQUIVALENCE CARACTERES POUR LE TRI ! ! !"
                
                
                # Nb : laisser deux espaces avant le "_|" sinon la liste sera triée
                # telle que "a" soit placé après "abc" et "aa" !
                
                ltri.append(t + "  _|" + str(i))
        
        
        # --- On construit la pyListe avec les critères de tri par défaut (équivalence maj/min)
        else:
            
            for i in range(self.wordcount):
                
                t = wordget(i).lower()      # Libellé de l'entrée, mis en minuscule
                try:
                    t = t.encode('utf-8')   # Try car encodage différent si issu de la listbox ou de la pyListe interne 
                except:
                    pass
                
                
                ltri.append(t + "  _|" + str(i))
        
        
        # ----------------------------------
        # --- Trier la pyListe temporaire   
        # ----------------------------------
        
        # On applique un tri alphabétique standard, mais celui-ci est en fait personnalisé
        # du fait de l'application antérieure des équivalences de caractères
        
        ltri.sort() 
        
        
        # -------------------------------------------------------------------
        # --- Aiguillage                                                     
        # --- (> rebatir le dico en fonction de l'ordre de la pyListe triée) 
        # -------------------------------------------------------------------
        
        memoLocalEditDate = self.localEditDate 
        self.localEditDate = str(datetime.date.today())
        
        ret="" # Message de retour des modules de tri
        
        if self.type.startswith("ling"):
            ret = self.__sortdicLing(ltri)
        
        elif self.type.startswith("wb"):
            ret = self.__sortdicWB(ltri)
        
        elif self.type.startswith("dict"):
            ret = self.__sortdicDict(ltri)
        
        elif self.type.startswith("csv"):
            ret = self.__sortdicCSV(ltri)
        
        elif self.type.startswith("xdxf"):
            ret = self.__sortdicXDXF(ltri)
        
        else: # Type de dictionnaire non triable > avertir
            self.showMessage(type = "warning",
                title = self.lgget("winsort", "title"),
                message = self.lgget("dic", "msg35") )
        
        if ret != "":
            self.showMessage(type = "warning",
                    title = self.lgget("winsort", "title"),
                    message = ret)
            self.localEditDate = memoLocalEditDate
            return
        
        
        return


    def __sortdicLing(self, ltri):
        
        u"""
        | [ appelé par DicObject.sortdic() ]                                    
        |                                                                       
        | Trier un dictionnaire de type Ling en fonction de 'ltri'.             
        |                                                                       
        | ARGUMENTS :                                                           
        |   'ltri' : pyListe [ 'entrée'|index,] déjà triée.                     
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès du tri.                          
        |   - Un message d'erreur si échec.                                     
        |                                                                       
        """
        
        # Créer une chaîne PreLing en fonction du tri antérieur
        strPreling = self.toStrPreling(sortedList=ltri)
        
        # Convertir la chaîne Preling en chaîne Ling
        strLing = DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        # Enregistre le nouveau fichier
        fichpath = self.path
        self.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strLing)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier trié
        self.__init__(  dicfilepath = fichpath,
                        lgget = self.lgget,
                        lstbox = self.lstbox,
                        prgbar = self.progr,
                        cachedir = self.cachedir)
        
        
        return ""


    def __sortdicDict(self, ltri):
        
        u"""
        | [ appelé par DicObject.sortdic() ]                                    
        |                                                                       
        | Trier un dictionnaire de type Dict en fonction de 'ltri'.             
        |                                                                       
        | ARGUMENTS :                                                           
        |   'ltri' : pyListe [ 'entrée'  _|index,] déjà triée.                   
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès du tri.                          
        |   - Un message d'erreur si échec.                                     
        |                                                                       
        """
        
        
        # Créer les chaînes Dict en fonction du tri antérieur
        strs = self.toStrsDict(sortedList=ltri)
        
        
        # si strs est une chaine et non un tupple => problème !
        if type(strs) is type("xxx"):
            return strs
        
        
        # ------------------------------------------------------
        # --- Enregistrer les nouveaux fichiers *.idx et *.dict 
        # ------------------------------------------------------
        
        radicfich = os.path.splitext(self.path)[0]     # Radical des différents fichiers Dict
        
        self.file.close()
        
        ff = open(radicfich + '.idx', 'wb')   # Enregistrer le *idx
        ff.write(strs[0])
        ff.close()
        
        ff = open(radicfich + '.dict', 'wb')  # Enregistrer le *dict
        ff.write(strs[1])
        ff.close()
        
        # (NB : le *ifo reste le même après le tri)
        
        
        # ----------------------------------------------------------------
        # --- Recharger le dictionnaire avec le fichier Dict trié         
        # ----------------------------------------------------------------
        
        self.__init__(  dicfilepath = radicfich + '.dict',
                        lgget = self.lgget,
                        lstbox = self.lstbox,
                        prgbar = self.progr,
                        cachedir = self.cachedir)
        
        
        return ""



    def __sortdicXDXF(self, ltri):
        
        u"""
        | [ appelé par DicObject.sortdic() ]                                    
        |                                                                       
        | Trier un dictionnaire de type XDXF en fonction de 'ltri'              
        |                                                                       
        | ARGUMENTS :                                                           
        |   'ltri' : pyListe [ 'entrée'|index,] déjà triée.                     
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès du tri.                          
        |   - Un message d'erreur si échec.                                     
        |                                                                       
        """
        
        strxdxf = ""
        
        # Accélérateurs locaux
        sk = self.file.seek
        rd = self.file.read
        
        # début du fichier : du début au début du premier article
        sk(0)
        strxdxf = rd(self.datamap[0][0]) 
        
        # ensemble des articles
        for ligne in ltri:
            i = int(ligne.split('  _|')[-1])       # lire l'index originel avant le tri
            sk(self.datamap[i][0])
            strxdxf += rd(self.datamap[i][1]) + "\n"
        
        strxdxf += "</xdxf>\n"
        
        # Enregistre le nouveau fichier
        fichpath = self.path
        self.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strxdxf)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier trié
        lbox = self.lstbox
        prg = self.progr
        self.__init__(  dicfilepath = fichpath,
                        lgget = self.lgget,
                        lstbox = self.lstbox,
                        prgbar = self.progr,
                        cachedir = self.cachedir)
        
        
        return ""


    def __sortdicWB(self, ltri):
        
        u"""
        | [ appelé par DicObject.sortdic() ]                                    
        |                                                                       
        | Trier un dictionnaire de type WB                                      
        |                                                                       
        | ARGUMENTS :                                                           
        |   'ltri' : pyListe [ 'entrée'|index,] déjà triée.                     
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès du tri.                          
        |   - Un message d'erreur si échec.                                     
        |                                                                       
        """
        
        strwb = ""
        
        for ligne in ltri:
            i = int(ligne.split('  _|')[-1])       # lire l'index originel avant le tri
            self.file.seek(84*i)
            strwb += self.file.read(84)
        
        # Enregistre le nouveau fichier
        fichpath = self.path
        self.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strwb)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier trié
        self.__init__(  dicfilepath = fichpath,
                        lgget = self.lgget,
                        lstbox = self.lstbox,
                        prgbar = self.progr,
                        cp1 = self.encoding1,
                        cp2 = self.encoding2,
                        cachedir = self.cachedir)
        
        
        return ""



    def __sortdicCSV(self, ltri):
        
        u"""
        | [ appelé par DicObject.sortdic() ]                                    
        |                                                                       
        | Trier un dictionnaire de type CSV en fonction de 'ltri'.              
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès du tri.                          
        |   - Un message d'erreur si échec.                                     
        |                                                                       
        """
        
        strcsv = ""
        
        
        for ligne in ltri:
            i = int(ligne.split('  _|')[-1])       # lire l'index originel avant le tri
            
            data = self.getdata(i)
            
            chp1 = data['mot'].decode('utf-8')
            chp1 = chp1.encode(self.encoding1)
            
            chp2 = data['short'].decode('utf-8')
            chp2= chp2.encode(self.encoding2)
            
            strcsv += chp1 + self.sep + chp2 + self.br
        
        # Enregistre le nouveau fichier
        fichpath = self.path
        self.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strcsv)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier trié
        self.__init__(  dicfilepath = fichpath,
                        lgget = self.lgget,
                        lstbox = self.lstbox,
                        prgbar = self.progr,
                        cp1 = self.encoding1,
                        cachedir = self.cachedir)
        
        
        return ""
    
    
    @staticmethod
    def importDictd(fileIndexPath, fileTargetPath):
        
        u"""
        | Importe un dictionnaire dictd (*.index + *.dict)                      
        | en le convertissant en preLing puis ling,                             
        | puis enregistre le fichier Ling                                       
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fileIndexPath' : chemin du fichier *.index                          
        |                                                                       
        |   'fileTargetPath' : chemin du fichier cible (*.ling)                  
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        
        def t2num(t):
            # Convertit une chaîne pseudo-Base64 en sa valeur numérique
            
            val64 = {
            'A':0,'B':1,'C':2,'D':3,'E':4,'F':5,'G':6,'H':7,'I':8,'J':9,'K':10,
            'L':11,'M':12,'N':13,'O':14,'P':15,'Q':16,'R':17,'S':18,'T':19,'U':20,
            'V':21,'W':22,'X':23,'Y':24,'Z':25,'a':26,'b':27,'c':28,'d':29,'e':30,
            'f':31,'g':32,'h':33,'i':34,'j':35,'k':36,'l':37,'m':38,'n':39,'o':40,
            'p':41,'q':42,'r':43,'s':44,'t':45,'u':46,'v':47,'w':48,'x':49,'y':50, 
            'z':51,'0':52,'1':53,'2':54,'3':55,'4':56,'5':57,'6':58,'7':59,'8':60, 
            '9':61,'+':62,'/':63}
            
            ret = 0
            i = 0
            for c in range(len(t)-1, -1, -1):
                ret += (64**i) * val64[t[c]]
                #print t, t[c], i, val64[t[c]], ret
                i += 1
            return ret
            
            
        
        # Initialiser une liste recevant les données
        strPreling = ["%preling/utf-8/{tab}",]
        
        
        # -------------------------------------------------
        # --- Lire l' *.index dans une liste de ligne      
        # -------------------------------------------------
        
        # --- Ouvrir l'index en lecture texte
        #   (NB : l'index n'est jamais compressé)
        
        try:
            ffidx = open(fileIndexPath, 'rU')
        except: 
            return  "Can't load\n" + fileIndexPath       # ('impossible de charger l'index')
        
        lignes = ffidx.readlines()                # Charger dans une liste de lignes
        ffidx.close()
        
        
        # -----------------------------------------------------
        # --- Décompresser le fichier de données si besoin     
        # -----------------------------------------------------
        
        flagdz = False
        radic = os.path.splitext(fileIndexPath)[0]
        
        fichdictPath = radic + ".dict"
        if os.path.isfile(fichdictPath):
            pass
        else:
            fichdictPath = radic + ".dict.dz"
            if os.path.isfile(fichdictPath):
                flagdz = True
            else:
                fichdictPath = radic + ".dict.gz"
                if os.path.isfile(fichdictPath):
                    flagdz = True
                else:
                    return "Data file missing!"
        
        
        # Décompresser le dict.*z dans un fichier dict
        if flagdz:
            ffgzip = gzip.GzipFile(fichdictPath, 'rb')
            
            fichdictPath = radic + ".dict"
            
            ff = open(fichdictPath, 'wb')
            
            ff.write(ffgzip.read())          # Enregistrer le contenu décompressé dans le dict
            ff.close()
            ffgzip.close()
        
        # -------------------------------------------------------------
        # ---- Ouvrir le fichier de données (et le laisser ouvert)     
        # -------------------------------------------------------------
        
        try:
            fichdict = open(fichdictPath, 'rU')
        except: 
            return  "Can't open\n" + fichdict       # ('impossible d'ouvrir le fichier dict')
        
        
        # ------------------------------------------------
        # --- Boucle de lecture des lignes de l'index     
        # --- > compléter une liste Preling               
        # ------------------------------------------------
        
        for ligne in lignes:
            
            ligne = ligne.rstrip('\r\n')
            
            if ligne.startswith("00"):  # --- Ligne de propriété
                
                chpidx = ligne.split("\t") # on scinde les champs d'index
                
                
                # on lit la valeur de propriété
                fichdict.seek(t2num(chpidx[1]))             # Décalage dans le fichier de données
                chp0 = fichdict.read(t2num(chpidx[2]))      # Lire le bloc dans une chaîne
                
                chp0 = chp0.replace("\r\n", "<br>")         # poser des balises de sauts de lignes
                chp0 = chp0.replace("\n", "<br>")
                chp0 = chp0.replace("\r", "<br>") 
                
                if chpidx[0] in ("00databaseurl", "00-database-url"):
                    chp0 = chp0.replace("<br>", "")
                    chp0 = chp0.replace("00databaseurl", "")
                    chp0 = chp0.replace("00-database-url", "")
                    strPreling.append("::dicUrl=" + chp0)
                    
                elif chpidx[0] in ("00databaseinfo", "00-database-info"):
                    chp0 = chp0.replace("00databaseinfo", "")
                    chp0 = chp0.replace("00-database-info", "")
                    strPreling.append("::dicInfo=" + chp0)
                    strPreling.append("::showDicInfo=True")
                    
                elif chpidx[0] in ("00databaseshort", "00-database-short"):
                    chp0 = chp0.replace("00databaseshort", "")
                    chp0 = chp0.replace("00-database-short", "")
                    chp0 = chp0.replace("<br>", " ")
                    strPreling.append("::dicName=" + chp0)
                    
                elif chpidx[0] in ("00databaseutf8", "00-database-utf8"):
                    continue
                else:
                    continue
                
                
            elif ligne.startswith(" "):
                continue
                
                
            else: # --- ligne d'index (libellé<lab>offset<tab>longueur)
                
                chpidx = ligne.split("\t") # on scinde les champs d'index
                
                word = chpidx[0] 
                
                # on lit la notice
                fichdict.seek(t2num(chpidx[1]))            # Décalage dans le fichier de données
                chp0 = fichdict.read(t2num(chpidx[2]))     # Lire le bloc notice dans une chaîne
                
                chp0 = chp0.replace("\t", "  ")             
                chp0 = chp0.replace("\r\n", "<br>")         # poser des balises de sauts de lignes
                chp0 = chp0.replace("\n", "<br>")
                chp0 = chp0.replace("\r", "<br>") 
                
                # Concaténer la ligne Preling
                lignePreL = word + "\t" + chp0 
                
                
                # Ajouter la ligne de donnée
                try:
                    strPreling.append(lignePreL)
                except:
                    print "plouf_ligneDictd :"+ligne
        
        
        
        # --------------------------------------------------------------------
        # --- Concaténer la chaîne Preling et la convertir en chaîne Ling     
        # --------------------------------------------------------------------
        
        fichdict.close()
        
        # Concaténer
        try:
            strPreling = "\n".join(strPreling)
        except:
            return self.lgget("dic", "msg29")
        
        # Convertir
        strLing = DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        if strLing[0] == "!":       # Echec de la conversion Preling>Ling
            return strLing
        
        
        # -----------------------------------
        # --- Enregistrer le fichier Ling    
        # -----------------------------------
        
        try:
            ff = open(fileTargetPath, 'wb')
        except:
            return self.lgget("winexp", "msg13") + " Ling"
        
        ff.write(strLing)
        ff.close()
        
        return ""
    
    
    
    def doExportToLing(self, fichpath, protected1="", protected2="", flagcleantags=False, flagcleanaccol=False, prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans le fichier Ling                  
        | de chemin 'fichpath'.                                                 
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath'     : chemin du fichier d'exportation.                    
        |   'protected1'   : (string) protocole de protection langue 1          
        |   'protected2'   : (string) protocole de protection langue 2          
        |   'flagcleantags': (bool) épurer les balises                          
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |   'prgbar'       : une ProgressBar qui suivra la conversion           
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        # -----------------------------------------
        # --- Confectionner la chaîne Preling      
        # -----------------------------------------
        
        strPreling = self.toStrPreling(progr = prgbar,
                                       protected1 = protected1,
                                       protected2 = protected2)
        
        if strPreling[0] == "!":       # Echec de la conversion en Preling
            return strPreling
        
        
        # -------------------------------------
        # --- Epurer les balises (optionnel)   
        # -------------------------------------
        
        if flagcleantags:
            strPreling = re.sub(r"<[^>]+?>", "", strPreling )
        if flagcleanaccol:
            strPreling = strPreling.replace("{{", "")
            strPreling = strPreling.replace("}}", "")
        
        # -------------------------------------------------
        # --- Convertir la chaine préling en chaîne Ling   
        # -------------------------------------------------
        
        strLing = DicObject.strPrelingToStrLing(strPreling=strPreling, cp="")
        
        if strLing[0] == "!":       # Echec de la conversion Preling>Ling
            return strLing
        
        
        
        # -------------------------------------------------
        # --- Enregistrer le fichier Ling                  
        # -------------------------------------------------
        
        try:
            ff = open(fichpath,'wb')
        except:
            return self.lgget("winexp", "msg13") + " Ling"
        
        ff.write(strLing)
        ff.close()
        
        return ""
    
    
    def doExportToPreling(self, fichpath, protected1="", protected2="", flagcleantags=False, flagcleanaccol=False, prgbar=None, br="\r\n"):
        
        u"""
        | Exporte le dictionnaire courant dans le fichier Preling               
        | de chemin 'fichpath'.                                                 
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath'     : chemin du fichier d'exportation.                   
        |   'protected1'   : (string) protocole de protection langue 1          
        |   'protected2'   : (string) protocole de protection langue 2          
        |   'flagcleantags': (bool) épurer les balises.                         
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |   'prgbar'       : une ProgressBar qui suivra la conversion.          
        |   'br'           : saut de ligne à utiliser dans le fichier Preling.  
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        # -----------------------------------------
        # --- Confectionner la chaîne Preling      
        # -----------------------------------------
        
        strPreling = self.toStrPreling(progr = prgbar,
                                       protected1 = protected1,
                                       protected2 = protected2)
        
        if strPreling[0] == "!":       # Echec de la conversion en Preling
            return strPreling
        
        # ------------------------------------------------
        # --- Conversion des sauts de lignes              
        # ------------------------------------------------
        
        if br != "\n" :
            strPreling = strPreling.replace('\n', br)
            
        
        # -------------------------------------------------
        # --- Enregistrer le fichier Preling               
        # -------------------------------------------------
        
        # Epurer les balises (optionnel)
        if flagcleantags:
            strPreling = re.sub(r"<[^>]+?>", "", strPreling )
        if flagcleanaccol:
            strPreling = strPreling.replace("{{", "")
            strPreling = strPreling.replace("}}", "")
        
        
        try:
            ff = open(fichpath,'wb')
        except:
            return self.lgget("winexp", "msg13") + " Preling"
        
        ff.write(strPreling)
        ff.close()
        
        
        return ""
    
    
    def doExportToSQLite(self, fichpath, flagcleantags=False, flagcleanaccol=False, prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans une base de donnée SQLite 3       
        | de chemin 'fichpath'.                                                 
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath'     : chemin du fichier d'exportation.                    
        |   'flagcleantags': (bool) épurer les balises                          
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |   'prgbar'       : une ProgressBar qui suivra la conversion           
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        # ------------------------------------------------
        # --- Créer la base de données et s'y connecter   
        # ------------------------------------------------
        
        # Effacer le fichier antérieur éventuel
        try   : os.chmod(fichpath, 0777)      
        except: pass
        try   : os.remove(fichpath)
        except: pass
        
        
        db = sqlite3.connect(fichpath)      # ouverture de la base
        db.row_factory = sqlite3.Row        # permet l'adressage des colonnes par leur nom plutôt que par leur index
        db.text_factory = sqlite3.OptimizedUnicode
        
        c = db.cursor()                     # obtention d'un "curseur" d'accès à la base
        
        
        # ===================================
        # === Créer la table des propriétés  
        # ===================================
        
        c.execute('''
                CREATE TABLE [properties] (
                    [minCompatVersion] TEXT, 
                    [maxCompatVersion] TEXT, 
                    [dicName] TEXT, 
                    [langName1] TEXT, 
                    [langName2] TEXT, 
                    [langIso1] TEXT, 
                    [langIso2] TEXT, 
                    [langNameUser] TEXT, 
                    [langIsoUser] TEXT,
                    [langFamily1] TEXT, 
                    [langFamily2] TEXT, 
                    [isReverseDic] BOOLEAN,
                    [doReverseDic] BOOLEAN,
                    [reverseDicFileName] TEXT, 
                    [reverseDicName] TEXT, 
                    [sortEquPatterns] TEXT, 
                    [sortEquPatternsRev] TEXT, 
                    [wordcount] INTEGER,
                    [mainAuthors] TEXT, 
                    [altAuthors] TEXT, 
                    [contactAuthor] TEXT, 
                    [shortAuthors] TEXT, 
                    [dicStatus] TEXT, 
                    [showDicStatus] BOOLEAN,
                    [copyright] TEXT, 
                    [creationDate] TEXT, 
                    [versionDate] TEXT, 
                    [localEditDate] TEXT, 
                    [dicID] TEXT, 
                    [dicVersionNumber] TEXT, 
                    [dicUrl] TEXT, 
                    [verUrl] TEXT, 
                    [dicInfo] TEXT, 
                    [showDicInfo] BOOLEAN,
                    [protec1] TEXT, 
                    [protec2] TEXT, 
                    [displayFontName1] TEXT, 
                    [displayFontName2] TEXT, 
                    [grammarEncoding1] TEXT, 
                    [compatPlugins] TEXT, 
                    [noCompatPlugins] TEXT, 
                    [usePlugins] TEXT, 
                    [wordGroups] TEXT, 
                    [biblio] TEXT, 
                    [showBiblio] BOOLEAN
                )''')
        
        # ========================================
        # === Compléter la table des propriétés   
        # ========================================
        
        sortEquPatterns = '","'.join(self.sortEquPatterns)
        if len(sortEquPatterns):
            sortEquPatterns = '"' +  sortEquPatterns + '"'
        
        sortEquPatternsRev = '","'.join(self.sortEquPatternsRev)
        if len(sortEquPatternsRev):
            sortEquPatternsRev = '"' +  sortEquPatternsRev + '"'
        
        mainAuthors = '","'.join(self.mainAuthors)
        if len(mainAuthors):
            mainAuthors = '"' +  mainAuthors + '"'
        
        altAuthors = '","'.join(self.altAuthors)
        if len(altAuthors):
            altAuthors = '"' +  altAuthors + '"'
        
        compatPlugins = '","'.join(self.compatPlugins)
        if len(compatPlugins):
            compatPlugins = '"' +  compatPlugins + '"'
        
        noCompatPlugins = '","'.join(self.noCompatPlugins)
        if len(noCompatPlugins):
            noCompatPlugins = '"' +  noCompatPlugins + '"'
        
        usePlugins = '","'.join(self.usePlugins)
        if len(usePlugins):
            usePlugins = '"' +  usePlugins + '"'
        
        wordGroups = '","'.join(self.wordGroups)
        if len(wordGroups):
            wordGroups = '"' +  wordGroups + '"'
        
        biblio = '","'.join(self.biblio)
        if len(biblio):
            biblio = '"' +  biblio + '"'
        
        
        
        c.execute('INSERT INTO properties VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                            (   self.minCompatVersion, 
                                self.maxCompatVersion, 
                                self.dicName, 
                                self.langName1, 
                                self.langName2, 
                                self.langIso1, 
                                self.langIso2, 
                                self.langNameUser, 
                                self.langIsoUser,
                                self.langFamily1, 
                                self.langFamily2, 
                                self.isReverseDic,
                                self.doReverseDic,
                                self.reverseDicFileName, 
                                self.reverseDicName, 
                                sortEquPatterns, 
                                sortEquPatternsRev, 
                                self.wordcount,
                                mainAuthors, 
                                altAuthors, 
                                self.contactAuthor, 
                                self.shortAuthors, 
                                self.dicStatus, 
                                self.showDicStatus,
                                self.copyright, 
                                self.creationDate, 
                                self.versionDate, 
                                self.localEditDate, 
                                self.dicID, 
                                self.dicVersionNumber, 
                                self.dicUrl, 
                                self.verUrl, 
                                self.dicInfo, 
                                self.showDicInfo,
                                self.protected1, 
                                self.protected2, 
                                self.displayFontName1, 
                                self.displayFontName2, 
                                self.grammarEncoding1, 
                                compatPlugins, 
                                noCompatPlugins, 
                                usePlugins, 
                                wordGroups, 
                                biblio, 
                                self.showBiblio
                            )
                    )
        
        
        # ===================================
        # === Créer la table des données     
        # ===================================
        
        c.execute('''
                CREATE TABLE [data] (
                    [idx] INTEGER NOT NULL PRIMARY KEY, 
                    [word] TEXT,         
                    [short] TEXT,           
                    [long] TEXT,   
                    [wordid] TEXT,                
                    [roots] TEXT,           
                    [syn] TEXT,         
                    [see] TEXT,        
                    [tok] TEXT,                        
                    [phon] TEXT,                    
                    [ant] TEXT
                )''')
        
        
        # ====================================
        # === Compléter la table des données  
        # ====================================
        
        getdata = self.getdata # accélérateur local
        
        
        if flagcleantags:
            cleantags = re.compile(r"<[^>]+?>")     # Motif regex pour extraire toutes les balises
        
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)  # Afficher la progression
            
            # Récupérer les données (> pyDictionnaire utf-8)
            data = getdata(i)                                   
            
            # Epurer les balises (optionnel)
            if flagcleantags:                                   
                dshort = re.sub(cleantags, "", data['short'] )
                dlong = re.sub(cleantags, "", data['long'] )
            else:
                dshort = data['short']
                dlong = data['long']
                
            if flagcleanaccol:
                dshort = dshort.replace("{{", "")
                dshort = dshort.replace("}}", "")
                dlong = dlong.replace("{{", "")
                dlong = dlong.replace("}}", "")
            
            if dlong.startswith('|!|'): dlong = ''
            
            did = data['ID']
            if did.startswith('|!|'): did = ''
            
            drac = data['rac']
            if drac.startswith('|!|'): drac = ''
            
            dsyn = data['syn']
            if dsyn.startswith('|!|'): dsyn = ''
            
            dsee = data['see']
            if dsee.startswith('|!|'): dsee = ''
            
            dtok = data['tok']
            if dtok.startswith('|!|'): dtok = ''
            
            dphon = data['phon']
            if dphon.startswith('|!|'): dphon = '' 
            
            dant = data['ant']
            if dant.startswith('|!|'): dant = ''
            
            c.execute('INSERT INTO data VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                            (   str(i),
                                data['mot'],
                                dshort,
                                dlong,
                                did,
                                drac,
                                dsyn,
                                dsee,
                                dtok,
                                dphon,
                                dant
                            )
                        )
        
        db.commit()
        
        db.close()
        
        return ""
    
    
    def doExportToTEI(self, fichpath, flagcleantags=False, flagcleanaccol=False, prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans le fichier TEI                  
        | de chemin 'fichpath'.                                                 
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'fichpath'       : chemin du fichier d'exportation ('.../dict.xdxf')
        |                                                                       
        |   'flagcleantags'  : (bool) épurer les balises                        
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |                                                                       
        |   'prgbar'         : une ProgressBar qui suivra la conversion         
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        
        # --------------------------------------------
        # --- Initialiser la chaîne du fichier TEI    
        # --------------------------------------------
        
        strfich = ['<?xml version="1.0" encoding="UTF-8" ?>',]
        strfich.append('<TEI xmlns="http://www.tei-c.org/ns/1.0" version="5.0">')
        strfich.append('<teiHeader type="text">')
        strfich.append('<fileDesc>')
        strfich.append('<titleStmt>')
        
        # Nom du dico
        t = self.dicName
        if t == "": t = self.lgget("winexp", "s29") #(dictionnaire sans nom)
        strfich.append('<title>' + t + '</title>')
        
        # Auteurs
        if len(self.mainAuthors) > 0:
            auth = ", ".join(self.mainAuthors)
            strfich.append('<respStmt>')
            strfich.append('<resp>compiled by</resp>')
            strfich.append('<name>' + auth + '</name>')
            strfich.append('</respStmt>')
            strfich.append('<!-- for the freedict database -->')
            strfich.append('<respStmt>')
            strfich.append('<resp>Maintainer</resp>')
            strfich.append('<name>' + auth + '</name>')
            strfich.append('</respStmt>')
        
        # ...
        strfich.append('</titleStmt>')
        
        # N° de version
        if len(self.dicVersionNumber) > 0:
            strfich.append('<editionStmt>')
            strfich.append('<!-- description of this particular edition; paste the old one at the bottom of the change log entry for that version  -->')
            strfich.append('<edition>' + self.dicVersionNumber + '</edition>')
            strfich.append('</editionStmt>')
        
        # Nb d'entrées
        strfich.append('<extent>' + str(self.wordcount) + '</extent>')
        
        # ...
        strfich.append('<publicationStmt>')
        strfich.append('<publisher>FreeDict</publisher>')
        strfich.append('<availability>')
        strfich.append('<p>Available under the terms of the GNU General Public License, version 2.0 or later.</p>')
        strfich.append('</availability>')
        
        # Date de version
        if len(self.versionDate) > 0:
            strfich.append('<date>' + self.versionDate + '</date>')
        
        # ...
        strfich.append('<pubPlace>http://freedict.org/</pubPlace>')
        strfich.append('</publicationStmt>')
        
        # Infos, statut et copyright (cumuler dans "description")
        strfich.append('<sourceDesc>')
        
        t = ""
        
        if self.dicInfo != "":
            t += self.dicInfo + "\n"
        
        if self.dicStatus != "":
            t += self.dicStatus + "\n"
        
        if self.copyright != "":
            t += self.copyright
        
        if t == "":
            t = self.lgget("winexp", "s30")  #(dictionnaire sans description)
        else:
            t = t.replace("<br>", "\n") # Utiliser des vrais sauts de lignes
        
        strfich.append('<p>' + t + '</p>')
        strfich.append('</sourceDesc>')
        
        # ...
        strfich.append('</fileDesc>')
        strfich.append('</teiHeader>')
        strfich.append('<text>')
        strfich.append('<body>')
        
        
        # ----------------------------------------------
        # --- Scanner la liste des entrées              
        # ----------------------------------------------
        
        if flagcleantags:
            cleantags = re.compile(r"<[^>]+?>")     # Motif regex pour extraire toutes les balises
            
        getdata = self.getdata # accélérateur local
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)  # Afficher la progression
            
            # Récupérer les données (> pyDictionnaire utf-8)
            data = getdata(i)                                   
            
            if data['ID'] != "":
                strfich.append('<entry xml:id="' + data['ID'] + '">')
            else:
                strfich.append('<entry>') 
            
            strfich.append('<form>')
            strfich.append('<orth>' + data['mot'] + '</orth>')
            strfich.append('</form>')
            
            # Ajouter les relations
            t = self.__convReltoTEI(data['rac'], data['syn'], data['ant'], data['see'])
            if t != "":
                strfich.append(t)
            
            # Ajouter les traductions courtes
            chp2 = data['short'].strip()
            
            # Ajouter les traductions longues
            t = data['long'].strip() 
            if t != "" and t[0:3] != "|!|":
                chp2 += '\n' + t
            
            # Convertir les <br> en vrais sauts de lignes
                chp2 = chp2.replace("<br>", "\n")
            
            # Epurer les balises (optionnel)
            if flagcleantags:                                   
                chp2 = re.sub(cleantags, "", chp2 )
            if flagcleanaccol:
                chp2 = chp2.replace("{{", "")
                chp2 = chp2.replace("}}", "")
            
            # ...
            strfich.append('<sense>')
            strfich.append('<def>' + chp2 + '</def>')
            strfich.append('</sense>')
            strfich.append('</entry>')
        
        # Clore le TEI
        strfich.append('</body>')
        strfich.append('</text>')
        strfich.append('</TEI>\n')
        
        # Concaténer la chaîne du fichier
        strfich = "\n".join(strfich)
        
        # Coder les '&' qui ne sont pas déjà dans des entités
        strfich = convToAmp(strfich)
        
        
        # -------------------------------------
        # --- Enregistrer le fichier           
        # -------------------------------------
        
        try:
            ff = open(fichpath,'w')
        except:
            return self.lgget("winexp", "msg13") + " XDXF"
        
        ff.write(strfich)
        ff.close()
        
        
        return ""

    
    
    def doExportToBinIniCsv(self, fichpath, fmt, flagfusion=False, flagcleantags=False, flagcleanaccol=False, br="\r\n", sp="\t", cp='utf-8', prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans le fichier 'fichpath'            
        | au format 'binaire', INI, CSV ou 'liste des entrées'.                 
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath'     : chemin du fichier d'exportation.                   
        |                                                                       
        |   'fmt'          : (string) format d'exportation.                     
        |                                                                       
        |   'flagfusion    : (bool) fusion des traductions courtes + longues    
        |                    dans le cas d'une source au format Ling.           
        |                                                                       
        |   'flagcleantags': (bool) épurer les balises.                         
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)   
        |                                                                       
        |   'br'           : terminateur de ligne à utiliser dans le fichier.   
        |                                                                       
        |   'sp'           : séparateur des données dans la ligne.              
        |                                                                       
        |   'cp'           : encodage du fichier de sortie.                     
        |                                                                       
        |   'prgbar'       : une ProgressBar qui suivra la conversion.          
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        
        flagEncodeError=False
        strfile = []
        
        
        # ----------------------------------------------
        # --- Scanner la liste des entrées              
        # ----------------------------------------------
        
        
        getdata = self.getdata # accélérateur local
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)      # Afficher la progression
            
            data = getdata(i)           # Données (pyDictionnaire Utf-8)
            
            # --- Entrée de dico
            
            chp1 = data['mot'].strip().decode('utf-8')
            
            try :
                chp1 = chp1.encode(cp)
            except:
                flagEncodeError = True
            
            if fmt == "INI" and chp1[0] == '[': # Titre de section
                strfile.append(chp1 + br)       # on concatène et on passe à la ligne suivante
                continue
            
            
            # --- Traductions
            if fmt == "LST":
                chp2 = ""
            else:
                
                chp2 = data['short'].strip().decode('utf-8')
                
                if flagfusion:
                    t = data['long'].strip()
                    if t != "":
                        t = t.decode('utf-8') 
                        chp2 += "@@@" + t # Protection d'un séparateur de fusion
                
                try:
                    chp2 = chp2.encode(cp)
                except:
                    flagEncodeError = True
            
            # Avertir et quitter si encodage impossible avec l'encodage choisi
            if flagEncodeError:
                return "'" + cp + "' " + self.lgget("winexp", "msg14")
            
            
            # --- Epurer les champs de leurs caractères séparateurs parasites
            if fmt in ("CSV", "INI"):
                chp2 = chp2.replace("\r\n","<br>")
                chp2 = chp2.replace("\n","<br>")
                chp2 = chp2.replace("\r","<br>")
            
            if fmt == "CSV":
                if sp == "\t":
                    chp1 = chp1.replace('\t', '  ')
                    chp2 = chp2.replace('\t', '  ')
                elif sp == ";":
                    chp1 = chp1.replace(';', ',')
                    chp2 = chp2.replace(';', ',')
                elif sp == ",":
                    chp1 = chp1.replace(',', ';')
                    chp2 = chp2.replace(',', ';')
            elif fmt == "INI":
                chp1 = chp1.replace('=', ':')
                chp2 = chp2.replace('=', ':')
            
            # --- Restaurer le séparateur de fusion
            if flagfusion :
                chp2 = chp2.replace("@@@", " ; --- ")
            
            # --- Concaténer champs, séparateur et terminateur
            strfile.append(chp1 + sp + chp2 + br)
        
        
        # -------------------------------------
        # --- Enregistrer le fichier           
        # -------------------------------------
        
        # ouvrir le nouveau fichier d'exportation
        try:
            ff = open(fichpath,'wb')
        except:
            return self.lgget("winexp", "msg13")
        
        strfile = "".join(strfile)
        
        # Epurer les balises (optionnel)
        if flagcleantags:
            strfile = re.sub(r"<[^>]+?>", "", strfile )
        if flagcleanaccol:
            strfile = strfile.replace("{{", "")
            strfile = strfile.replace("}}", "")
        
        # enregistrer
        ff.write(strfile)
        ff.close()
        
        return ""
    
    
    
    def doExportToDict(self, fichpath, flagfusion=False, flagcleanbr=False, flagcleantags=False, flagcleanaccol=False, flagtransgram=False, sortascii = False, subdict="m", prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans les fichiers DICT                
        | de chemin 'fichpath'.                                                 
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'fichpath' : chemin du fichier d'exportation.                       
        |                                                                       
        |   'flagfusion     : (bool) fusion des traductions courtes + longues   
        |                     dans le cas d'une source au format Ling.          
        |                                                                       
        |   'flagcleanbr' : (bool) convertir <br> en saut de ligne réel.        
        |                                                                       
        |   'flagcleantags' : (bool) épurer les balises.                        
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |                                                                       
        |   'flagtransgram' : (booléen) tranfert de la grammaire entre crochet  
        |                     du champ "entrée" vers le champ "traduction".     
        |                                                                       
        |   'subdict'      : type des données (champ sametypesequence de l'ifo)
        |                                                                       
        |   'sortascii'    : trier le dico en ordre ascii strict, pour          
        |                    compatibilité avec Stardict                        
        |                                                                       
        |   'prgbar'       : une ProgressBar qui suivra la conversion.          
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        |                                                                       
        """
        
        strifo=[]   # Future chaîne du *.ifo
        stridx=[]   # Future chaîne du *.idx
        strdict=[]  # Future chaîne du *.dict
        #strsyn=[]  # Future chaîne du *.syn (désactivé, voir plus bas)
        
        
        # --------------------------------------
        # --- Scanner la liste des entrées      
        # --------------------------------------
        
        decal = 0
        chp2 = ""
        gram = []
        
        getdata = self.getdata                      # Accélérateur local
        
        exGram = re.compile(r"\[.*\]")              # Motif regex pour extraire la grammaire entre crochets
        
        if flagcleantags:
            cleantags = re.compile(r"<[^>]+?>")     # Motif regex pour extraire toutes les balises
        
        if flagcleanbr:
            cleanbr = re.compile(r"<br ?/?>", re.IGNORECASE) # Motif regex pour extraire tous les <br> et variantes
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)                  # Afficher la progression
            
            data = getdata(i)                       # Récupérer les données (> pyDictionnaire utf-8)
            
            # --- Transfert optionnel de la grammaire
            if flagtransgram:
                
                try:
                    gram = re.findall(exGram, data['mot'])[0]
                
                except: # grammaire absente
                    pass
                
                else:   # grammaire présente
                    
                    data['mot'] = data['mot'].replace(gram, "").strip()
                    data['short'] = gram + "\n\n" + data['short'] 
                    
            
            
            
            # --- Données du *Dict
            
            decal = decal + len(chp2)               # Décalage (offset) de la traduction
            
            chp2 = data['short'].strip()
            
            if flagfusion:
                t = data['long'].strip()
                if t != "":
                    if subdict == "x":  
                        chp2 += "<co>" + t + "</co>" 
                    else:
                        chp2 += " ; --- " + t 
            
            if flagcleanbr:                         # Convertir <br> en saut de ligne (optionnel)
                chp2 = re.sub(cleanbr, "\n", chp2 )
            if flagcleantags:                       # Epurer les balises (optionnel)
                chp2 = re.sub(cleantags, "", chp2 )
            if flagcleanaccol:
                chp2 = chp2.replace("{{", "")
                chp2 = chp2.replace("}}", "")
            
            
            if subdict == "x":                      # sous-type xdxf
                
                # Ajouter les relations
                t = self.__convReltoXdxf(data['rac'], data['syn'], data['ant'], data['see'])
                if t != "":
                    chp2 += "\n" + t
                
                chp2 = "<def>" + chp2 + "</def>"
            
            
            strdict.append(chp2)                    # Ajouter la traduction dans le *.dict
            
            # --- Données du *Idx
            
            stridx.append(data['mot'] + '\0')       # Ajouter l'entrée dans le *.idx
            stridx.append(numToStr32(decal))        # Ajouter le décalage (image chaîne en 32 bits) dans le *.idx
            stridx.append(numToStr32(len(chp2)))    # Ajouter la longueur de la traduction (image chaîne en 32 bits) dans le *.idx
            
            #print data['mot'], len(chp2)
            #print map(ord,numToStr32(decal))
            #print map(ord,numToStr32(len(chp2)))
            
            # --- Données du *Syn
            
            #if data['syn'] != "":
            #    if not data['syn'].startswith("|!|"):
            #        
            #        chps = data['syn'].split(";")   # Chaîne des wordIDs des synonymes
            #        
            #        for chp in chps:
            #            try:
            #                idx = self.wordIDs[chp][0]                     # wordID > Index
            #                strsyn.append(self.lstbox.get(idx).encode('utf8') + "\0" + numToStr32(i)) 
            #            except KeyError: # l'index pointe sur du vide > on le saute
            #                pass               
        
        
        # ------------------------------------------------------
        # --- Enregistrer les fichiers *.idx, *.dict et *.syn   
        # ------------------------------------------------------
        
        radicfich = os.path.splitext(fichpath)[0]   # Radical des différents fichiers Dict
        
        # --- Enregistrer le fichier *.idx
        ff = open(radicfich + ".idx", 'wb')         
        ff.write("".join(stridx))
        ff.close()
        
        # --- Enregistrer le fichier *.dict
        ff = open(radicfich + ".dict", 'wb')        
        ff.write("".join(strdict))
        ff.close()
        
        
        # NB : partie  désactivée car les synonymes Dict ne correpondent pas aux synonymes Ling
        # les synonymes ling sont uniquement des synonymes externes (= qui ne sont pas eux-mêmes des entrées du dico)
        # qui pointent sur des entrées du dico
        #
        #if len (strsyn) > 0:
        #    strsyn.sort()                           # Trier le fichier *.syn
        #    ff = open(radicfich + ".syn", 'wb')     # Enregistrer le fichier *.syn
        #    ff.write("".join(strsyn))
        #    ff.close()
        
        
        # ------------------------------------------------
        # --- Construire et enregistrer le fichier *.ifo  
        # ------------------------------------------------
        
        lignes = []
        
        ligne = "StarDict's dict ifo file".encode ('utf-8')
        lignes.append(ligne)
        
        ligne = "version=2.4.2".encode ('utf-8')
        lignes.append(ligne)
        
        ligne = "bookname=" + os.path.basename(radicfich)
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne = "wordcount=" + str(self.wordcount)
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne = "idxfilesize=" + str(os.path.getsize(radicfich + ".idx"))
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne ="synwordcount=".encode ('utf-8')
        lignes.append(ligne)
        
        ligne = "sametypesequence=" + subdict
        ligne = ligne.encode ('utf-8')
        lignes.append(ligne)
        
        ligne = "idxoffsetbits=32".encode ('utf-8')
        lignes.append(ligne)
        
        ligne = "author=" + ", ".join(self.mainAuthors)
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne = "email=" + self.contactAuthor
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne = "website=" + self.dicUrl
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne = "description=" + self.dicInfo
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        ligne = "date=" + self.versionDate
        try   : ligne = ligne.encode ('utf-8')
        except: pass
        lignes.append(ligne)
        
        t = "\n".join(lignes)
        t += "\n"
        
        # --- Enregistrer
        
        ff = open(radicfich + ".ifo", 'wb')
        ff.write(t)
        ff.close()
        
        # ------------------------------------------------
        # --- Tri optionnel en Ascii strict               
        # ------------------------------------------------
        
        if sortascii:
            
            # Charger le dico dans un objet dictionnaire temporaire
            dictmp = DicObject(dicfilepath = radicfich + ".idx",
                                lgget = self.lgget,
                                prgbar = prgbar,
                                cachedir = self.cachedir )
            
            # Trier le dico
            dictmp.sortdic(equs='ascii')
            
        
        return ""
    
    
    def doExportToWB(self, fichpath, flagcleantags=False, flagcleanaccol=False, wbsize='31/53', cp1='cp1252', cp2='cp1252', prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans le fichier WB                    
        | de chemin 'fichpath'.                                                 
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath' : chemin du fichier d'exportation.                       
        |                                                                       
        |   'flagcleantags' : (bool) épurer les balises.                        
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |                                                                       
        |   'wbsize' : type wb, strict ("30/50") ou étendu ("31/53")            
        |                                                                       
        |   'prgbar'   : une ProgressBar qui suivra la conversion.              
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        flagEncode1Error = False
        flagEncode2Error = False
        flagCut = False   # flag mis à True si des mots ont été tronqués durant la conversion
        
        strfile = []
        
        if flagcleantags:
            cleantags = re.compile(r"<[^>]+?>")
        
        # -----------------------------------------
        # --- Scannage de la liste des entrées     
        # -----------------------------------------
        
        getdata = self.getdata   # accélérateur local
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)  # Afficher la progression
            
            data = getdata(i)       # Extraire les données (pyDictionnaire Utf-8)
            
            # --- Entrée de dico
            
            chp1 = data['mot'].decode('utf-8')
            try :
                chp1 = chp1.encode(cp1)
            except:
                flagEncode1Error = True
            
            # --- Traduction
            chp2 = data['short']
            
            try:
                chp2 = chp2.decode('utf-8')
            except:
                pass
            
            
            if flagcleantags:                       # Epurer les balises (optionnel)   
                chp2 = re.sub(cleantags, "", chp2 )
            if flagcleanaccol:
                chp2 = chp2.replace("{{", "")
                chp2 = chp2.replace("}}", "")
            
            
            try:
                chp2 = chp2.decode('utf-8')
            except:
                pass
            
            try:
                chp2 = chp2.encode(cp2)
            except:
                flagEncode2Error = True
            
           
            
            
            # --- Si echec de l'encodage : retourner un message et quitter
            
            terr = u""
            if flagEncode1Error:
                terr += self.lgget("winexp", "msg15") + " '" + cp1 + "'\n\n"
            if flagEncode2Error:
                terr += self.lgget("winexp", "msg16") + " '" + cp2 + "'\n\n"
            if terr != "":
                terr += self.lgget("winexp", "msg17")
                return self.lgget("winexp", "msg18") + "\n\n" + terr
            
            
            # --- Epurer le champ1 de ses virgules (car virgule = séparateur WB)
            
            chp1 = chp1.replace(",", ";")
            
            # --- Formater les champs en longueur fixe WB (31 + 53)
            
            # rognage strict (30/50) ou étendu (31/53)
            sizes = wbsize.split("/")
            size1 = int(sizes[0])
            size2 = int(sizes[1])
            
            if len(chp1) > size1: flagCut = True
            if len(chp2) > size2: flagCut = True
            chp1 = chp1[:size1]
            chp2 = chp2[:size2]
            
            # on vérifie que le rognage n'a pas coupé un caractère codé sur deux octets,
            # si oui le décodage génère une erreur > on supprime le demi-caractère de queue
            try:
                test = chp1.decode(cp1) 
            except:
                chp1 = chp1[:-1]
            try:
                test = chp2.decode(cp2) 
            except:
                chp2 = chp2[:-1]
            
            
            # ajuster en complétant les champs avec des zéros binaires
            chp1 = chp1.ljust(31,'\0')
            chp2 = chp2.ljust(53,'\0')
            
            # Convertir les champs en leurs valeurs d'octets, puis reconvertir en caractères
            # pour éviter les messages d'erreurs d'encodage de Python                       
            # lors de la concaténation de champs d'encodages différents                     
            # (c'est chronophage et stupide mais je n'ai pas trouvé de meilleure combine...)
            
            chp1 = map(ord, chp1)
            chp1 = map(chr, chp1)
            chp1 = "".join(chp1)
            
            chp2 = map(ord, chp2)
            chp2 = map(chr, chp2)
            chp2 = "".join(chp2)
            
            strfile.append(chp1 + chp2)
        
        # -----------------------------------
        # --- Enregistrer le fichier WB      
        # -----------------------------------
        
        try:
            ff = open(fichpath,'wb')
        except:
            return self.lgget("winexp", "msg13") + " WB"
        
        ff.write("".join(strfile))
        ff.close()
        
        # Avertir si des données ont été tronquées par la conversion en WB
        if flagCut:
            t = self.lgget("winexp", "msg19")
        else:
            t = ""
        
        return t

    
    
    def doExportToXDXF(self, fichpath, flagcleantags=False, flagcleanaccol=False, prgbar=None):
        
        u"""
        | Exporte le dictionnaire courant dans le fichier XDXF                  
        | de chemin 'fichpath'.                                                 
        | Les relations sont exportés en littéral dans des balises xdxf.        
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'fichpath'       : chemin du fichier d'exportation ('.../dict.xdxf')
        |                                                                       
        |   'flagcleantags'  : (bool) épurer les balises                        
        |                                                                       
        |   'flagcleanaccol' : (bool) épurer les double accolades (liens clés)  
        |                                                                       
        |   'prgbar'         : une ProgressBar qui suivra la conversion         
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide si succès.                                        
        |   - Une chaîne contenant un message d'erreur si échec.                
        """
        
        
        if flagcleantags:
            cleantags = re.compile(r"<[^>]+?>")
        
        # attribut lang_user (utilisé dans diverses balises)
        lguser = self.langIsoUser.split(":")[-1]
        if lguser != "":
            lguser = ' lang_user="' + lguser + '"'
        
        
        # --------------------------------------------
        # --- Initialiser la chaîne du fichier XDXF   
        # --------------------------------------------
        
        strfich = ['<?xml version="1.0" encoding="UTF-8" ?>',]
        
        
        # Langues (attributs de <xdxf>)
        lg1 = self.langIso1.split(":")[-1]
        lg2 = self.langIso2.split(":")[-1]
        
        strfich.append('<xdxf lang_from="' + lg1 + '" lang_to="' + lg2 +'" format="visual">')
        
        # Nom du dico ( = <full_name>)
        t = self.dicName
        if t == "": t = self.lgget("winexp", "s29") #(dictionnaire sans nom)
        strfich.append("<full_name" + lguser + ">" + t + "</full_name>")
        
        
        # Infos et statut, date, auteur (cumuler dans <description>)
        t = ""
        
        if len(self.mainAuthors) > 0:
            auth = ", ".join(self.mainAuthors)
            t += "<author>" + auth + "</author>\n"
        
        if self.versionDate != "":
            t += "<date>" + self.versionDate + "</date>\n"
        
        if self.dicInfo != "":
            t += self.dicInfo + "\n"
        
        if self.dicStatus != "":
            t += self.dicStatus + "\n"
        
        if self.copyright != "":
            t += self.copyright
        
        if t == "":
            t = self.lgget("winexp", "s30")  #(dictionnaire sans description)
        else:
            t = t.replace("<br>", "\n") # Utiliser des vrais sauts de lignes
        
        strfich.append("<description" + lguser + ">" + t + "</description>")
        
        
        # --------------------------------------
        # --- Scanner la liste des entrées      
        # --------------------------------------
        
        getdata = self.getdata # accélérateur
        
        for i in range(self.wordcount):
            
            if prgbar:
                prgbar.setValue(i)  # Afficher la progression
            
            # Récupérer les données (> pyDictionnaire utf-8)
            data = getdata(i)                                   
            
            # Ajouter les traductions courtes
            chp2 = data['short'].strip()
            
            # Ajouter les traductions longues (dans <co>)
            t = data['long'].strip()
            if t != "" and t[0:3] != "|!|":
                chp2 += "<co" + lguser + ">" + t +"</co>" 
            
            # Convertir les <br> en vrais sauts de lignes
            chp2 = chp2.replace("<br>", "\n")
            
            # Epurer les balises (optionnel)
            if flagcleantags:                                   
                chp2 = chp2.replace("<co", "%@@@%")
                chp2 = chp2.replace("</co>", "!@@@!")
                chp2 = re.sub(cleantags, "", chp2 )
                chp2 = chp2.replace("%@@@%", "<co")
                chp2 = chp2.replace("!@@@!", "</co>")
            if flagcleanaccol:
                chp2 = chp2.replace("{{", "")
                chp2 = chp2.replace("}}", "")
            
            # Ajouter les relations
            t = self.__convReltoXdxf(data['rac'], data['syn'], data['ant'], data['see'])
            if t != "":
                chp2 += "\n" + t
            
            # Concaténer l'entrée et la notice dans un élément xdxf
            strfich.append("<ar><head><k>" + data['mot'] + "</k></head><def>" + chp2 + "</def></ar>")
        
        # Clore le xdxf
        strfich.append('</xdxf>\n')
        
        # Concaténer la chaîne du fichier
        strfich = "\n".join(strfich)
        
        # Coder les '&' qui ne sont pas déjà dans des entités
        strfich = convToAmp(strfich)
        
        
        # -------------------------------------
        # --- Enregistrer le fichier           
        # -------------------------------------
        
        try:
            ff = open(fichpath,'w')
        except:
            return self.lgget("winexp", "msg13") + " XDXF"
        
        ff.write(strfich)
        ff.close()
        
        
        return ""
    
    
    def __convReltoXdxf(self, rac, syn, anto, see):
        
        u"""
        | Convertit les chaînes de wordIDs des relations d'une entrée en        
        | un bloc xdxf qui est retourné.                                        
        |                                                                       
        | ARGUMENTS :                                                           
        |   'rac'   : liste des wordIDs des racines                             
        |   'syn'   : liste des wordIDs des synonymes                           
        |   'anto'  : liste des wordIDs des antonymes                           
        |   'see'   : liste des wordIDs des "voir aussi"                        
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne xdxf de type :                                           
        |       <etym>...</etym>                                                
        |       <synonym>...</synonym>                                          
        |       <antonym>...</antonym>                                          
        |       <kref>...</kref>                                                
        |       <kref>...</kref>                                                
        |       ...                                                             
        | Les balises vides ne sont pas écrites.                                
        """
        
        fullBloc = []
        n = 0
        for rel in (rac, syn, anto, see):
            n += 1
            if rel == "":
                continue
            
            bloc = []
            
            wIDs = rel.split(";")       # Splitter la chaîne des wordIDs
            
            for wID in wIDs:
                wID = wID.strip()
                try:
                    word = self.getdata(self.wordIDs[wID][0])['mot']
                except KeyError:        # lien mort, on le saute
                    continue
                bloc.append("{{" + word + "}}")
            
            if len(bloc) < 1 :
                continue
            
            if n == 1:          # rac
                bloc = "<etym>" + "\n".join(bloc) + "\n</etym>"
            elif n == 2:        # syn
                bloc = "<synonym>" + "\n".join(bloc) + "\n</synonym>"
            elif n == 3:        # anto
                bloc = "<antonym>" + "\n".join(bloc) + "\n</antonym>"
            elif n == 4:        # see
                bloc = "<kref>" + "</kref>\n<kref>".join(bloc) + "</kref>"
            
            fullBloc.append(bloc)
           
        return "\n".join(fullBloc)
    
    
    def __convReltoTEI(self, rac, syn, anto, see):
        
        u"""
        | Convertit les chaînes de wordIDs des relations d'une entrée en        
        | un bloc TEI qui est retourné.                                         
        |                                                                       
        | ARGUMENTS :                                                           
        |   'rac'   : liste des wordIDs des racines                             
        |   'syn'   : liste des wordIDs des synonymes                           
        |   'anto'  : liste des wordIDs des antonymes                           
        |   'see'   : liste des wordIDs des "voir aussi"                        
        |                                                                       
        | RETOUR :                                                              
        |   Une chaîne TEI de type :                                            
        |       <xr type="etym">                                                
        |           <ref target="#wordID>...</ref>                              
        |           <ref target="#wordID>...</ref>                              
        |       </xr>                                                           
        |       <xr type="synonym">                                             
        |           <ref target="#wordID>...</ref>                              
        |           <ref target="#wordID>...</ref>                              
        |       </xr>                                                           
        |       <xr type="antonym">                                             
        |           <ref target="#wordID>...</ref>                              
        |           <ref target="#wordID>...</ref>                              
        |       </xr>                                                           
        |       <xr type="else">                                                
        |           <ref target="#wordID>...</ref>                              
        |           <ref target="#wordID>...</ref>                              
        |       </xr>                                                           
        |       ...                                                             
        | Les balises vides ne sont pas écrites.                                
        """
        
        fullBloc = []
        n = 0
        for rel in (rac, syn, anto, see):
            n += 1
            if rel == "":
                continue
            
            bloc = []
            
            wIDs = rel.split(";")       # Splitter la chaîne des wordIDs
            
            for wID in wIDs:
                wID = wID.strip()
                try:
                    cibledata = self.getdata(self.wordIDs[wID][0])
                except KeyError:        # lien mort, on le saute
                    continue
                
                bloc.append('<ref target="' + cibledata['ID'] + '">' + cibledata['mot'] + '</ref>')
            
            
            if len(bloc) < 1 :
                continue
            
            if n == 1:          # rac
                bloc = '<xr type="etym">ETYM.\n' + "\n".join(bloc) + "\n</xr>"
            elif n == 2:        # syn
                bloc = '<xr type="syn">SYN.\n' + "\n".join(bloc) + "\n</xr>"
            elif n == 3:        # anto
                bloc = '<xr type="cf">ANTON.\n' + "\n".join(bloc) + "\n</xr>"
            elif n == 4:        # see
                bloc = '<xr type="cf">SEE\n' + "\n".join(bloc) + "\n</xr>"
            
            fullBloc.append(bloc)
        
        
        fullBloc = "\n".join(fullBloc)
        
        return fullBloc
    
    
    
    def __showMessageWin(self, type="warning", title="Linguae", message = "", initialvalue=""):
        
        u"""
        | Affichage des messages en mode graphique                              
        |                                                                       
        | ARGUMENTS :                                                           
        |                                                                       
        |   'type' : type de boîte de message...                                
        |       - "warning" (défaut) : message d'avertissement                  
        |       - "info" : message d'information                                
        |       - "askyesno" : question à réponse par oui ou non                
        |       - "askstring" : InputBox préremplie par 'initialvalue'          
        |                                                                       
        | RETOUR :                                                              
        |    celui propre à chaque type de boîte                                
        """
        
        
        if type == "info":
            import tkMessageBox
            tkMessageBox.showinfo(
                    parent = self.winparent,
                    title = title,
                    message = message)
            return
        
        elif type == "askyesno":
            import tkMessageBox
            r = tkMessageBox.askyesno(
                    parent = self.winparent,
                    title = title,
                    message = message )
            return r
        
        elif type == "askstring":
            import tkSimpleDialog
            r = tkSimpleDialog.askstring(
                    parent = self.winparent,
                    title = title,
                    prompt = message,
                    initialvalue = initialvalue)
            return r
        
        else:   # 'warning' par défaut
            import tkMessageBox
            tkMessageBox.showwarning(
                    parent = self.winparent,
                    title = title,
                    message = message)
            return
    
    
    def __showMessageCons(self, type="warning", title="", message = "", initialvalue=""):
        
        u"""
        | Affichage des messages en mode console.                               
        """
        
        # Adapter l'encodage à la plate-forme
        try:
            message = message.decode('utf-8')
        except:
            pass
        
        if app.pf == "win":
            try:
                message = message.encode('cp850')
            except:
                pass
        else:
            try:
                message = message.encode('utf-8')
            except:
                pass
        
        
        # Formater en fonction du type de message
        
        if type == "info":
            print "*** " + message + " ***"
            
        elif type == "askyesno":
            r = raw_input(message + " (Yes or No?):")
            if r.lower().startswith("y"):
                return True
            else:
                return False
            
        elif type == "askstring":
            r = raw_input(message + " >:")
            return r
            
        else:   # 'warning' par défaut
            print "!!! " + message + " !!!"
