#!/usr/bin/env python
# -*- coding:utf-8 -*-

from Tkinter import*

class ImgList():
    u"""
    Ensemble de Gifs (encodés base64) pour l'interface, l'instanciation crée les ojets PhotoImage
    """

    def __init__(self):

        # gif 16x16x16 : ouverture d'un dossier/fichier
        self.open = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAAgALAAAAAAQABAAAAQ4EMlJq6Ug3wpm7xsHZqBFIsDyLGTLrbCqllIaxzSKt3wm
        A4OgUPhZAYfDEQuZ9ByZA1qPF6paLxEAOw==""")
        
        # gif 16x16x16 : coller
        self.paste = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgMDAwP8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAA0ALAAAAAAQABAAAARRsEkJKpi42brWvtRwDIBXAuMBoirivigZql91qFQq7vrK
        D4SgkLDSHQiPZDI42yGVDyRBY5QGo0LA7wldxlLWYVSz4XanmbBwnO4q0ZihnBABADs=""")
        
        # gif 16x16x16 : édition/éditer (feuille + crayon)
        self.edit = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAgP//AICAgP/A/+zp2P///9E7S9FbQAAAANHGxBLrlBQAAPQX5gAA
        BhQHqCH5BAEAAAQALAAAAAAQABAAAARAEMhJKwEm663BwJNRUR9nAkEgieGIrmYnfOXqzh4Wi4Ii
        1a0JLrcD9EBAmwQnKsVCTZCyEi1uci7XgDDoer/gCAA7""")
        
        # gif 16x16x16 : édition/supprimer
        self.suppr =PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A//H/
        /////yH5BAEAAAgALAAAAAAQABAAAARUEMlzpKX2hoDR2ZUEAFvCUYF5IsDzJeYbY62bmvAJVG0r
        z48d60H8nYK84m1JEfqYTNqjdHqBkp+jrTp0HYhgCnI4Co7ORCd4zXae33Chh0Kv1xERADs=""")
        
        # gif 16x16x16 : édition/ajouter
        self.add =PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A//H/
        /////yH5BAEAAAgALAAAAAAQABAAAARUEMmJhKUS6A2EEseWPWTpgSRwIMDTas8ZumtbkrLjqGxs
        /Z/fpeVRGI9IEFF4Ys4eh+hBJo3abrJUzfWKfWa8q+mr7XF8SlrvRpKWOXD4ClGt1xERADs=""")
        
        # gif 16x16x16 : phylactère d'info
        self.info = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgMDAwICAgP8AAAD/AP//wAAA//8A/wD/
        /////yH5BAEAAA0ALAAAAAAQABAAAARJsMlJaz0g62MxOE/4eJyEgSHDhMfZnOKjjuP5xTjYZmg6
        67tbTKWr8XC/mq13ICo/r09LRdyVotKWFnrR8EBci+kYFmMx5i4gAgA7""")
        
        # gif 16x16x16 : download
        self.dwnld = PhotoImage(data="""R0lGODlhEAAQALMAAP//wH9/f8DAwAAAAP///4AAAP8AAAD/AACAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAACH5BAEAAAAALAAAAAAQABAAQARDEMgJShl0BsG75wFGWYUxnNQWrGwrrGJWxpls1tvnIQfc
        /j/a6FarzYo2AzEDHAABAYJ0SpX6dLprtfoKAU7gcFgSAQA7""")
        
        # gif 16x16x16 : deux drapeaux en superposition
        self.setic = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgMDAwICAgP8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAA0ALAAAAAAQABAAAARFsMlJawM4ay1B+skiLkqpAB0YjuaZgiNpopcat7S37VoC
        MEDGY/hQYXxBIdGYSRKLoJxzGe1Mh0Zr8Jm9XKGfHG9nKU8iADs=""")
        
        # gif 16x16x16 : web
        self.web = PhotoImage(data="""R0lGODlhEAAQALMAAGprbmiJsqSnqr2/rzmK5ymy+myu46e72/boVOPYnszQ2N/h5Ojr8f/A//f3
        /////yH5BAEAAA0ALAAAAAAQABAAAAR7sMlJq13qiDGUlYpRHINgDlZYjJmSmNRyiIWCJHgSHNO8
        FrkE4hZgNEqlQO0mHO4UgsbjMQgYroYhYidYdB5e5erg1DwEAAWj+ssOCNAzIA0l/KrFDjpdshP+
        BDwLJxhVgH8BEmsCCgpJgDsUDFAmGQeXCx8MC0YfEhEAADs=""")
        
        # gif 16x16x16 : propriétés d'un dictionnaire
        self.propr = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAAAAhCEhITExMTkAAEBAAFY5OXNzc//A/5xjY4CAAMDAwP///+/v7/fv
        7wDAACH5BAEAAAgALAAAAAAQABAAAARUEMmJgL0oBCoB+yCgcZ4HfuNUMiaYVmzciht8yVZWW8Tz
        lJxOz+cDBBGDAnFp5BQSS6KiOelBo48CVWJdKgyCY/e7WBi21YehfBigKQRD+x3MHRERADs=
        """)
        
        # gif 16x16x16 : outils
        self.tools = PhotoImage(data="""R0lGODlhEAAQALMAAFFeeHCCmp0fL69weJmhtaKvxc6ws8LH0tPY4eHe2+fn3v+A/+fn7+vr6/f3
        9////yH5BAEAAAsALAAAAAAQABAAAARfcMlJq10n50uITAeBbFbhTYTTFGiTFAFFMAhyEkUeS+EY
        JpIAAPBgLUSBZPJACRQNAwAzEWDsJAhnQUA5BIATKNF4WRgEaOLJckYbFmo2WvCWxCnz+uQucV8A
        V2VlEQAAOw==""")
        
        # gif 16x16x16 : déplacer une entrée
        self.wmove = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAgP//AICAgP/A/+zp2P////8AANFbQAAAANHGxADAABQAAPQX5gAA
        BhQHqCH5BAEAAA0ALAAAAAAQABAAAARBEMhJawMm67w2GFhlLKT2YdtIlsbZSupaumndgsah7/xx
        Y73gz1ZzTWKyYUrWGYpWJpytmaERo5UsZdAYeL/gcAQAOw==""")
        
        # gif 16x16x16 : ok (coche au-dessus d'un carnet)
        self.ok = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgMDAwP8AAAD/AP//AP/A//8A/wD/
        /////yH5BAEAAAwALAAAAAAQABAAAARIkEl5ap1STAAe+ggHMIIidWL6POW2vnDrwm85znT53KRC
        s75dRqCrBYXDIvHIIy2XsCaACI1iOtTjSroqWnE/5Cn8ajJSaF4EADs=""")
        
        # gif 16x16x16 : aide (logo aide style Xp)
        self.hlp = PhotoImage(data="""R0lGODlhEAAQALMAAEA/PUJBPldWVAExvRlOuShfy095zWqT4YB+eaKgnZis1K3M68C9tf/A/+Dj
        6BQHqCH5BAEAAA0ALAAAAAAQABAAAAR1sMnmqp2Y2l0Z5ku4WMlkHcp5kJpzrM7oGEWVMNVRrMaw
        6qsFolIoFgkjWs0hIBoLqQOhWAk4iwaHYkp1WB3PlZGQXXy3Rt1xlBBoDARCNJ7yIiQVtKIgrwgE
        Hg04eQoyDggCJRIMCYYdf4oYbQEAlQGJExEAADs=""")
        
        # gif 16x16x16 : rechercher une nouvelle version
        self.chknewver = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A//H/
        /////yH5BAEAAAgALAAAAAAQABAAAARBEMhJKwIv663B5WAGHNjDcEkqkhlzZokWj6X7bjNr2vha
        26+Yr8WDdXRFEI2IOtZAwscyxJlSnZXs5IA4eL/gcAQAOw==""")
        
        # gif 16x16x16 : quitter (porte entrebaillée et flèche)
        self.exit = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAGZRAAAA/5pnMa98HKVyJ7iFE8iVA/7MBf3UL/3bU/zdYfvkifrqrPnw
        z//A/yH5BAEAAA8ALAAAAAAQABAAAARb8MkX6ry3ngOqxcG2AU4JPEImcqUDCOkUimQJx9JsGEDT
        3EDKbgdgAIOBHYEAWCiOMMrSUQAkrrdMYVtFeF84ynYwAHgRp3CATDZ/MRR22ePBAABtuP5+0vv/
        EQA7""")
        
        # gif 16x16x16 : exporter (carnet et flèche)
        self.export = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAIAAAICAgP/A/9TQyP///////9E7S9FbQAAAANHGxBLrlBQAAPQX5gAA
        BhQHqCH5BAEAAAMALAAAAAAQABAAAARNcMghap2YClCUV8A1CUUBnChnjmXrlgD7HkgbS+Qc0Cte
        IkDEIUCkyYjI5A5BKSmfxBw0eWgWDlgsVeYa7nrW7sHGfZF9ZtdNkmqfMBEAOw==""")
        
        # gif 16x16x16 : importer (carnet et flèche)
        self.imprt = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAED/QICAgP/A/9TQyP///////9E7S8D/wAAAANHGxA2lYxQAAPQX5gAA
        BhQHqCH5BAEAAAMALAAAAAAQABAAAARMcMghap2YClCUV8A1CUUBnChnjmXrlgD7FggSrBL52ssd
        5y7eolerUUrCoVJ5XDqXx0Lg6YyWpsqAVmttYX2y1xbXnZF1ZhgmxT5hIgA7""")
        
        # gif 16x16x16 : chercher (jumelles noires)
        self.find = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAAgALAAAAAAQABAAAAQ1EMlJKwV4YmAReJz0hdWmZeXGqaQIZiMqsnSIvWts3rsO
        +zyVhzZkeXAlpC7ZM12Enag0GgEAOw==""")
        
        # gif 16x16x16 : enveloppe
        self.mail = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAMbGxv//wP//////////////////////////////////////////////
        //+A/yH5BAEAAA8ALAAAAAAQABAAAAQ08MlJq70U6M37FmAogh8wjkCgkSermiwKviIcCzQLm3Bu
        r66VrZXaBI7I5NHD7GCe0Cg0AgA7""")
        
        # gif 16x16x16 : dictionnaire Ling
        self.dicling = PhotoImage(data= """R0lGODlhEAAQALMAAIprUMR+Pt6cYOete5iYmK2trcW1p/HJqMbGxs7OzuLe2u/v7/fn1vfv5/f3
        9////ywAAAAAEAAQAAAEYvDJSat9qKB0KSnOsmxdsYQJknVAUXwnd5lFChasmIAL0SGEhcZBUFgO
        jAcgtfFRGgcKYApAVKCHQUAbmGof2wd20BgIpoEHQzsQH7LlM2DATooD2zh+GziEr3gJDh2EFREAADs=""")
        
        # gif 16x16x16 : dictionnaire xdxf
        self.dicxdxf = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAAAAhAAAnAAA/wCEhDFjnDFj/zGcADGc/zHO/zH//4SEhKXO98bGxv8A
        /////yH5BAEAAA4ALAAAAAAQABAAAARdcMlJpbtuvc17W5jWjc0DZuMIrAD6MBtBGBv8tBojPMSj
        IIGHAIbTxRSJQ1DIwL12BsRhEBzeXLaAtrZxplLOXUGwE5OvorJwvUNv1PBd+DFWj7uub6fF6vtZ
        DhEAADs=""")
        
        # gif 16x16x16 : caractères spéciaux
        self.carspec = PhotoImage(data= """R0lGODlhEAAQALMAAAAAgICAgP/A/xLsgNPtv9ZPcP///9E7S9FbQAAAANHGxBLrlBQAAPQX5gAA
        BhQHqCH5BAEAAAIALAAAAAAQABAAAAQ3UMhJq70Y6J11+AFXeQHlmcBnaWi5ptP5uhI7pnSdC/gF
        mCpT7TesxTYwHtKFTDZpoKAgusNQIgA7""")
        
        # gif 16x16x16 : construire le dico inverse
        self.reverse = PhotoImage(data= """R0lGODlhEAAQALMAAIQAAP/A//8AAP//////////////////////////////////////////////
        /////yH5BAEAAAEALAAAAAAQABAAAAQrMMhJq63iapEt/2BHhSFQAWgKcKY2tu4Eb/EoxiR45p+1
        CqrUZVWjzIquCAA7""")
        
        # gif 16x16x16 : voir le dico inverse
        self.seerev = PhotoImage(data= """R0lGODlhEAAQALMAAIQAAP/A//8AAADAAP//////////////////////////////////////////
        /////yH5BAEAAAEALAAAAAAQABAAAAQrMMhJq63j6pEt/2BHhSFQAWgKcKY2tu4Eb/EoxiR45p+1
        DqrUZVWjzIquCAA7""")
        
        # gif 16x16x16 : dictionnaire Dict
        self.dicdict = PhotoImage(data= """R0lGODlhEAAQALMAAE5WIHBgOG94QXubTpCMTLCVUoy1TqLBWP8A/4R7a5B/a5qQcbK0fdizbsC3
        o8zJuiH5BAEAAAgALAAAAAAQABAAAAR+EMkpHXs0o+fWEIOTOVZBDOgnMNTSNEZspAKIOUFx7HL6
        hY9AQMA7xHwEkQIAEBh2xtmg0Lg1mcXYq8FCAAgF5vP5KlwkiUCDIDa8CIEFBoGjsgE5QkKQmNcb
        JkwEg0NzCAo5WwUmQyITDnhbcAIOhhMBX3oKlhkcCZUaCBEAADs=""")
        
        # gif 16x16x16 : dictionnaire WB
        self.dicwb = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAP8AAISEhMDAwP//////////////////////////////////////////
        ///A/yH5BAEAAA8ALAAAAAAQABAAAARC8MlJq5UA3JpD0FvneSAljmP5AAPqfhMQtG+KeXQNy7j+
        nbNXRnAb5YYEYhE3HBAGmVhK8HxGTaTq1SIDCLYh8CQCADs=""")
        
        # gif 16x16x16 : dictionnaire CSV
        self.diccsv = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgMDAwP8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAA0ALAAAAAAQABAAAAQ+sMlJq70W6K0xeGDYZQ9hgh9AhuhWfeYpHtTHsgA9wbGc
        1zecTsLrER6/XXAGNJ6SxCVq2OBYNdTGYcvt6iIAOw==""")
        
        # gif 16x16x16 : dictionnaire INI
        self.dicini = PhotoImage(data= """R0lGODlhEAAQALMAAItfJ2diZs+eJdW0WoeIlq6uuNvNocXJzqnS887m9OHl6Nr3/Pfv3uvz8/8A
        //v//yH5BAEAAA4ALAAAAAAQABAAAASB0DnDhrEjy+1UEAQ4FBlxcEcyJMbBGI9SEGiz3MujN4G5
        HblHQ/ciBCw/3O2RKXwEBQlQp7uMnoITMIFILACZgWAMoAERaIRVPA4EHGd04gAA1wE9+CLB7wLr
        bgFae15BOkYEUXp8hoc+UkqNBDQ/Cg0KBzNGbooSMoE9kwUnGxEAADs=""")
        
        # gif 16x16x16 : dictionnaire format non précisé
        self.dicx = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAP//gISEhMDAwP//////////////////////////////////////////
        ///A/yH5BAEAAA8ALAAAAAAQABAAAARC8MlJq5UA3JpD0FvneSAljmP5AAPqfhMQtG+KeXQNy7j+
        nbNXRnAb5YYEYhE3HBAGmVhK8HxGTaTq1SIDCLYh8CQCADs=""")
        
        # gif 16x16x16 : tri croissant
        self.sortcr = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgICAgP/A//8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAAgALAAAAAAQABAAAAQ7EEkEpiVWHnAywhkgeuC0Ud0ViqNqVhLnxiM7e6TF2jdM
        +ZKSDkgoFoeZgzH1wxknLYpFydxFg7isJQIAOw==""")
        
        # gif 16x16x16 : haut-parleur
        self.audio = PhotoImage(data= """R0lGODlhEAAQALMAADk5OUpKSlJSUlpaWmNjY29vb4ODg6CgoL29vdbW1t7e3ufn5+/v7/f39//G
        /////yH5BAEAAA4ALAAAAAAQABAAAART0MlJq6Us36pOYZvUFWTjFNSiLkTbmqezJEPNugSMLkY9
        ML5aA7UT+BiCZHIYUxSOgWiUQXQoEFBpABQTZRiAcJiLshwEYlD50gkAuCEvPE6vRwAAOw==""")
        
        # gif 16x16x16 : dossier
        self.folder = PhotoImage(data= """R0lGODlhEAAQALMAAHVYIm9vZ613EL2EIcGMJcuWLuy5T//heK2ppP/vhP/3kP//nL21rf/A/9bW
        zv///yH5BAEAAA0ALAAAAAAQABAAAARvsMlJ6yy4MEvL+w+BcI23nEs4rIOwlUosg58QbEWSZBnB
        rozCwUOjJR42YQF1AqAMi+SQuXCeoDbCNAbodhXYgHap0wHKYS1hcWgfAO7w4DBgu+9LG2Ml6Pv/
        AgABDQgBhoeIhyMNDAiOj5AIGxEAADs=""")
        
        # gif 16x16x16 : enregistrer (micro)
        self.rec = PhotoImage(data= """R0lGODlhEAAQALMAADk7OVRWVG5sboiIiJaZlqmpqbm5ucPDw9LO0v/A/9be1t7e3ufn5+/n7+/v
        7/f39yH5BAEAAAkALAAAAAAQABAAAARuMMkpFUKK6okYsxt1OEPgXGGCOEQgDAyRHgxgFIMhpAYT
        DKPFbtO5FQSIgExDOwQei+QgQykKFgOAcmPRKQg2qgZxIAzAB/GY3Dqko5uD9GBY4BgY0cLAPxS0
        LwgiAgSFLgYJCmqJBoUEBYsSEQAAOw==""")
        
        # gif 16x16x16 : stop enregistreur
        self.stop = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAIAAAACAAICAAAAAgIAAgACAgMDAwICAgP8AAAD/AP//AEBAQP8A/wD/
        /////yH5BAEAAA0ALAAAAAAQABAAAAQ4sMlJq70W6M01BUwoisfzMUiqpuW5ru0EvmoszTRiNzi9
        968fKifM6Uyyg3LJREoe0KgUiqlaLxEAOw==""")
        
        # gif 16x16x16 : image photo
        self.photo = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAACEAAD/AAD/////AP//////////////////////////////////////
        /////ywAAAAAEAAQAAAERBDISascOGt9NwdY5w0AQYCiV54kOIZu+sKbTGeAIKBui+uAQE54GwoC
        QCSPBDzmdsrJUemk7p7OXVIraeqO3qtlLIkAADs=""")
        
        # gif 16x16x16 : image séparateur de barre d'outils
        self.toolsep = PhotoImage(data= """R0lGODlhEAAQALMAAISEhP/A////////////////////////////////////////////////////
        /////yH5BAEAAAEALAAAAAAQABAAAAQhMMgZgKAY28zr7doHTttIimZpequkpuj4yjE423V363kE
        ADs=""")
        
        # gif 16x16x16 : traduction
        self.traduc = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAAAAgAAA/4AAAP//AMDAwP///9E7S4CAgAAAAOnp6RLrlBQAAP/A/wAA
        BhQHqCH5BAEAAA0ALAAAAAAQABAAAAQvsMlJqxVC4mwb517nbZoYhmD3jakpAnAsy27dHIeE5x3P
        36KdzzT89XQ3nG1ZiwAAOw==""")
        
        # gif 16x16x16 : héritage
        self.herit = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAIAAAAbYpICAAAAAgAJQTwCAgICAgP/A//8AAAD/AP//AAAA//8A/wD/
        /////yH5BAEAAAgALAAAAAAQABAAAARdEEkEKrVz1rJ2SkB2LR3wnaEEBEbHnqgUkEXwFfAXAmQH
        VjkLr1QQCEyJQaCgqRifq8fhkFoZntBDIYUIGIvYowjwBEO5qrJRyRRRnoGAlOp+y6fbuqqgResx
        IhEAADs=""")
        
        # gif 16x16x16 : enregistrer (disquette)
        self.save = PhotoImage(data= """R0lGODlhEAAQALMAAAAAAISEAMbGxtbWzv//////////////////////////////////////////
        //8A/yH5BAEAAA8ALAAAAAAQABAAAAQ88MlJqwQ4a30DEGAIfkD3iWFmoqm3sgLgPvLJ1u89y96G
        BTugcCgs0YC+TLCnGS19TiMPGpvRkhuLlhIBADs=""")
        
        # gif 16x16x16 : puce de lien vers une relation
        self.torel = PhotoImage(data= """R0lGODlhEAAQALMAACkA5zEI5zkQ5zkY70IY70Yh71Ix72JB73Za8Z2K98O1/NfN/+/n//Tx///3
        /////ywAAAAAEAAQAAAEcvDJ19hSajE3e0tHEQQFojTdwyAC4L4lKi3HGwwvECDoF8CKQq6gcCwMw4ai9UIwlsOHA+oqXH4wyZQpwGCrWiphsRBmty8DY5Wk6hKNqRlAnAMMC0kDgb3lAnATe3YuAjwp
        SggFBAQlJylaFhgaHBMRAAA7""")
        
        
        # --- Images non 16x16x16
        
        # gif 11x11x2 : icône "plus"
        self.plus = PhotoImage(data= """R0lGODlhCwALAIAAAAAAAP///ywAAAAACwALAAACF4SPFsus3t4CkUJHk5LBTt9VkdhUGlIAADs=""")
        
        # gif 11x11x2 : icône "moins"
        self.moins = PhotoImage(data= """R0lGODlhCwALAIAAAAAAAP///ywAAAAACwALAAACFISPFsus3R5ccqp0wXR6hwqBEZYUADs=""")
        
        # gif 16x16x2 : aucun plugin
        self.plugnone = PhotoImage(data= """R0lGODlhEAAQAIAAAAAAAP/A/yH5BAEAAAEALAAAAAAQABAAAAIdjI+pmxAOn3SsSkvtyoxr5Cnh
        d1Xjdx4pNrURiRQAOw==""")
        
        # gif 16x16x2 : rien (image transparente)
        self.rien = PhotoImage(data= """R0lGODlhEAAQAIAAAP9A/////yH5BAEAAAAALAAAAAAQABAAAAIOhI+py+0Po5y02ouzPgUAOw==""")
        
        # gif 12x12x16 : poignée de redimensonnement de coin de fenêtre
        self.poign = PhotoImage(data= """R0lGODlhDAAMALMAAISEhNbWzv//////////////////////////////////////////////////
        //+A/yH5BAEAAA8ALAAAAAAMAAwAAAQi8MlJn6hVADz15l4AAoCIhc/XkSJJoexaprMEz9vdAjod
        RAA7""")
        
        # gif puce sud
        self.puceS = PhotoImage(data= """R0lGODlhBwAEAIAAAAAAAP///yH5BAEAAAEALAAAAAAHAAQAAAIIhA+BGWoNWSgAOw==""")
        
        # gif puce rien
        self.puceX = PhotoImage(data="""R0lGODlhBwAEAIAAAOXl5f///yH5BAEAAAAALAAAAAAHAAQAAAIEhI+pWwA7""")
        
        # gif 10x14x16 :cadenas
        self.caden1 = PhotoImage(data="""R0lGODlhCgAOALMAAKqHJsCZMcacKcqlNdKrL9q1NN63SOnGT9m9b/DRac67iu3UitbOsvfnpf8A
        /9bWziH5BAEAAA4ALAAAAAAKAA4AAARM0EmGgpJYAYTAxZ6kYc7ATAFpkKk4KLCGOMZiJEuSDAci
        NI1FQ3c4CASGQuFQIBCOAmKieDAcDVgDYQCN6hJK55FqPAIEpYEawAY4IgA7""")
        
        # gif 10x14x16 :cadenas masqué
        self.caden0 = PhotoImage(data="""R0lGODlhCgAOAIAAAAAAAP8A/yH5BAEAAAEALAAAAAAKAA4AAAIKjI+py+0Po5wUFQA7""")


if __name__ == '__main__':
    # Afficher les images Photoimage avec leur nom dans l'objet ImgList
    root = Tk()
    imglst = ImgList()
    n = 0
    for k, img in imglst.__dict__.items():
        Label(root, compound="top", text="." + k, image=img, pady=5, padx=2).grid(row=n/10, column=n%10)
        n +=1
    root.mainloop()
    