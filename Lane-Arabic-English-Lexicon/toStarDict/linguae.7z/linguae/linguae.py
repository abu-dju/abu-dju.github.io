#!/usr/bin/env python
# -*- coding:utf-8 -*-


# ////////////////////////////////////////////////////////////////
#                                                                 
#   LINGUAE                                                       
#   Gestionnaire de dictionnaire multiformat multiplateforme      
#                                                                 
#   sous licence CeCILL : http://www.cecill.info/                 
#                                                                 
#   Auteur   : Billig - 2008-2010                                 
#   Contact  : linguae@stalikez.info                              
#   Site Web : http://linguae.stalikez.info                       
#                                                                 
# ////////////////////////////////////////////////////////////////



import sys
import os.path

#print sys.executable           # chemin de l'executable de l'interpréteur Python


# -------------------------------------------------------------------
# Déterminer si démarrage en mode graphique ou mode console          
# -------------------------------------------------------------------

if ("-i" in sys.argv) or ("help" in sys.argv) or ("?" in sys.argv):    # mode console
    
    import cmdling
    
else:# mode graphique
    


    # ------------------------------------------------------------------------------
    # Vérifier la présence de Tkinter                                               
    # en effet, certaines distributions Linux ont Python préinstallé sans tkinter   
    # en cas d'absence, on affiche un message sur la console et on quitte           
    # ------------------------------------------------------------------------------

    try:
        import Tkinter
        import tkMessageBox
    except:
        print "-"*60 + "\n !!!! AVERTISSEMENT !!!\n Le module Tkinter (bibliotheque graphique de Python)\n est absent de cette machine ou est incomplet.\n Vous devez d'abord l'installer pour pouvoir lancer ce programme.\n" + "-"*60
        sys.exit()



    # -------------------------------------------------------------
    # Vérifier le n° de version de Python                          
    # on avertit et on quitte si différent de 2.05 à 2.07          
    # -------------------------------------------------------------

    pyver = str(hex(sys.hexversion))[2:]

    if not pyver[:3] in ("205", "206", "207") :
        tkMessageBox.showinfo(
                title = "Linguae",
                message = "- ATTENTION ! Vous utilisez la version suivante de Python :\n- CAUTION! You are using the following version of Python:\n\n\tPython " + pyver + "\n\n- Linguae nécessite l'une des versions suivantes :\n- Linguae needs one of the following versions:\n\n\t2.5 (205...)\n\t2.6 (206...)\n\t2.7 (207...)\n\n- Installez-la à partir de...\n- Install it from...\n\n\thttp://www.python.org/")
        sys.exit()



    # ---------------------------------------------------------------
    # Vérifier si plateforme Linux et python 2.06                    
    # Tkinter est dans ce cas bogué, on prévient et on continue      
    # ---------------------------------------------------------------
    
    
    if sys.platform.lower()[:5] == 'linux' and pyver[:5] == "20602":
        root = Tkinter.Tk()
        root.title('Linguae')
        Tkinter.Label(root,text="LINGUAE vérifie la plateforme et la version de Python\Tkinter...").pack(padx=10, pady=10)
        tkMessageBox.showinfo(
                title = "Linguae",
                message = u"ATTENTION ! Vous utilisez Python/Tkinter 2.6.02 sur une plateforme Linux.\n\n\
    Cette version 2.6.02 pour Linux de Tkinter (bibliothèque graphique de Python) présente des bogues aléatoires \
    de ses boîtes de message (si dans celles-ci vous cliquez 'oui' et que le programme réagit comme si vous aviez cliqué 'non', \
    il vous faudra fermer et relancer Linguae).") 
        root.destroy()
    
    
    # ----------------------------------------------------------------------------
    # Vérifier que le script est installé avec un chemin sans caractères spéciaux 
    # Prévenir et quitter                                                         
    # ----------------------------------------------------------------------------
    chemin = os.path.realpath(sys.argv[0])
    cars = map(ord, chemin)
    for c in cars:
        if c > 127:
            msg = u"ATTENTION ! Linguae ne peut fonctionner avec un chemin d'installation qui contient des caractères étendus.\nVeuillez modifier le chemin d'installation...\n\nCAUTION! Linguae can't run if the installation path contains some extended characters.\nPlease modify the installation path..."
            
            msg = msg.encode('utf-8')
            
            try:
                tkMessageBox.showwarning(
                    title = "Linguae",
                    message = msg + "\n\n----------\n\n'" + chemin + "'")
            except:
                tkMessageBox.showwarning(
                    title = "Linguae",
                    message = msg)
            
            sys.exit()
    
    
    # ------------------------------------------------
    # Lancement de l'application graphique            
    # ------------------------------------------------
    
    
    # lancement de l'application proprement dite
    
    import corpus 
