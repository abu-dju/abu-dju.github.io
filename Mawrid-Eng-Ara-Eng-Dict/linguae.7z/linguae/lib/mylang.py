#!/usr/bin/env python
# -*- coding:utf-8 -*-


import lang     # Répertoire contenant les fichiers de langues de l'interface

class MultiLanguage():
    
    u"""
    | Classe de gestion du multilingisme de l'interface                         
    |                                                                           
    | On instancie l'objet avec le code de la langue ('fr', 'en', etc...) puis  
    | on récupère les chaînes pour afficher dans l'interface par la             
    | méthode 'get(section, clef)'                                              
    |                                                                           
    | Utilise des fichiers de langues dont le nom  de base correspond au code   
    | de langue (fr.py, en.py, etc...). Ces fichiers de langue sont placés dans 
    | le répertoire '/lang' de l'application.                                   
    |                                                                           
    | Les fichiers de langues contiennent des pyDictionnaires dant le nom       
    | correspond à une "section".                                               
    """
    
    
    
    def __init__(self, lgcode=None):
        
        u"""
        | Instancie la langue à utiliser pour l'interface (français par défaut) 
        """
        
        # Importer le module .py contenant la langue d'interface
        exec("import lang."+ lgcode)        
        
        # Garder une référence à ce module .py dans une chaîne
        self.strlgmodule = "lang." + lgcode
        
        # Garder une référence au code de la langue dans une chaîne
        self.lgcode = lgcode
        
        return
    
    
    def get(self, section, clef):
        u"""
        | Renvoie la chaine correspondant à la 'section' et à la 'clef'         
        """
        
        
        try:
            return eval(self.strlgmodule + "." + section +"['" + clef + "']")
        except:
            print "!!! LACKING TRANSLATION STRING:", self.strlgmodule, section, clef 
            import lang.fr      
            return eval("lang.fr." + section +"['" + clef + "']")   # français par défaut

    
    def getlgcode(self):
        u"""
        | Renvoie le code de langue courant                                     
        """
        
        return self.lgcode
    
    
